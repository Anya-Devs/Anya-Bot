from discord.ext import commands
import random
import asyncio
import aiohttp
import logging
import json
import io
import os
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
from bot.utils.cogs.game import *
from bot.utils.cogs.game.images import *
from bot.utils.cogs.game.const import *
from bot.utils.cogs.game.draw.cover_art import *
from bot.utils.cogs.game.draw.cover_gallery_view import CoverGalleryView, CoverCollectionView, DeleteConfirmationView
from bot.utils.cogs.game.view import *
from bot.cogs.quest import Quest_Data
from bot.utils.cogs.fun import Memo_Data, Memo, MemoEmbeds, Reaction_Data, Reaction
from data.local.const import primary_color
import discord

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# 🐟 COMPREHENSIVE FISH DATABASE - Unique characteristics, rarities, and mechanics
# ═══════════════════════════════════════════════════════════════════════════════

FISH_DATABASE = {
    # ═══ COMMON FISH (40% total) ═══
    "anchovy": {"name": "Anchovy", "emoji": "🐟", "rarity": "common", "min_value": 5, "max_value": 15, "weight_range": (0.1, 0.5), "catch_style": "quick", "difficulty": 1, "description": "A tiny silver fish.", "rod_damage": 1, "spawn_rate": 0.12},
    "sardine": {"name": "Sardine", "emoji": "🐟", "rarity": "common", "min_value": 8, "max_value": 20, "weight_range": (0.2, 0.8), "catch_style": "quick", "difficulty": 1, "description": "Small but nutritious.", "rod_damage": 1, "spawn_rate": 0.10},
    "carp": {"name": "Carp", "emoji": "🐟", "rarity": "common", "min_value": 10, "max_value": 30, "weight_range": (1.0, 5.0), "catch_style": "steady", "difficulty": 2, "description": "A hardy freshwater fish.", "rod_damage": 2, "spawn_rate": 0.10},
    "perch": {"name": "Perch", "emoji": "🐟", "rarity": "common", "min_value": 12, "max_value": 35, "weight_range": (0.5, 2.0), "catch_style": "steady", "difficulty": 2, "description": "A striped fish.", "rod_damage": 2, "spawn_rate": 0.08},
    # ═══ UNCOMMON FISH (30% total) ═══
    "bass": {"name": "Sea Bass", "emoji": "🐠", "rarity": "uncommon", "min_value": 25, "max_value": 60, "weight_range": (2.0, 8.0), "catch_style": "fight", "difficulty": 3, "description": "A popular sport fish.", "rod_damage": 5, "spawn_rate": 0.08},
    "trout": {"name": "Rainbow Trout", "emoji": "🐠", "rarity": "uncommon", "min_value": 30, "max_value": 70, "weight_range": (1.5, 6.0), "catch_style": "quick", "difficulty": 3, "description": "Beautiful iridescent scales.", "rod_damage": 4, "spawn_rate": 0.07},
    "salmon": {"name": "Salmon", "emoji": "🐠", "rarity": "uncommon", "min_value": 40, "max_value": 90, "weight_range": (3.0, 12.0), "catch_style": "fight", "difficulty": 4, "description": "A powerful swimmer.", "rod_damage": 6, "spawn_rate": 0.06},
    "catfish": {"name": "Catfish", "emoji": "🐠", "rarity": "uncommon", "min_value": 35, "max_value": 80, "weight_range": (2.0, 15.0), "catch_style": "steady", "difficulty": 3, "description": "A bottom-dweller.", "rod_damage": 5, "spawn_rate": 0.05},
    "flounder": {"name": "Flounder", "emoji": "🐠", "rarity": "uncommon", "min_value": 30, "max_value": 75, "weight_range": (1.0, 5.0), "catch_style": "patience", "difficulty": 3, "description": "A flat camouflaged fish.", "rod_damage": 4, "spawn_rate": 0.04},
    # ═══ RARE FISH (18% total) ═══
    "tuna": {"name": "Bluefin Tuna", "emoji": "🐡", "rarity": "rare", "min_value": 80, "max_value": 180, "weight_range": (20.0, 100.0), "catch_style": "fight", "difficulty": 5, "description": "A massive powerful fish.", "rod_damage": 12, "spawn_rate": 0.05},
    "swordfish": {"name": "Swordfish", "emoji": "🐡", "rarity": "rare", "min_value": 100, "max_value": 220, "weight_range": (50.0, 200.0), "catch_style": "fight", "difficulty": 6, "description": "A fierce predator.", "rod_damage": 15, "spawn_rate": 0.04},
    "pufferfish": {"name": "Pufferfish", "emoji": "🐡", "rarity": "rare", "min_value": 60, "max_value": 150, "weight_range": (0.5, 3.0), "catch_style": "careful", "difficulty": 4, "description": "Handle with care!", "rod_damage": 8, "spawn_rate": 0.04},
    "electric_eel": {"name": "Electric Eel", "emoji": "⚡", "rarity": "rare", "min_value": 90, "max_value": 200, "weight_range": (5.0, 20.0), "catch_style": "careful", "difficulty": 5, "description": "Shocking! 600 volts.", "rod_damage": 10, "spawn_rate": 0.03},
    "anglerfish": {"name": "Anglerfish", "emoji": "🐡", "rarity": "rare", "min_value": 70, "max_value": 160, "weight_range": (1.0, 8.0), "catch_style": "patience", "difficulty": 5, "description": "A deep-sea horror.", "rod_damage": 10, "spawn_rate": 0.02},
    # ═══ EPIC FISH (9% total) ═══
    "shark": {"name": "Great White Shark", "emoji": "🦈", "rarity": "epic", "min_value": 200, "max_value": 450, "weight_range": (500.0, 2000.0), "catch_style": "battle", "difficulty": 8, "description": "The apex predator!", "rod_damage": 25, "spawn_rate": 0.03},
    "manta_ray": {"name": "Manta Ray", "emoji": "🦈", "rarity": "epic", "min_value": 180, "max_value": 400, "weight_range": (100.0, 500.0), "catch_style": "gentle", "difficulty": 6, "description": "A graceful giant.", "rod_damage": 18, "spawn_rate": 0.02},
    "marlin": {"name": "Blue Marlin", "emoji": "🐟", "rarity": "epic", "min_value": 250, "max_value": 500, "weight_range": (100.0, 400.0), "catch_style": "battle", "difficulty": 7, "description": "Ultimate sport fish!", "rod_damage": 22, "spawn_rate": 0.02},
    "giant_squid": {"name": "Giant Squid", "emoji": "🦑", "rarity": "epic", "min_value": 220, "max_value": 480, "weight_range": (50.0, 300.0), "catch_style": "battle", "difficulty": 7, "description": "Legendary deep creature.", "rod_damage": 20, "spawn_rate": 0.02},
    # ═══ LEGENDARY FISH (3% total) ═══
    "golden_koi": {"name": "Golden Koi", "emoji": "👑", "rarity": "legendary", "min_value": 500, "max_value": 1000, "weight_range": (5.0, 15.0), "catch_style": "zen", "difficulty": 8, "description": "Brings fortune!", "rod_damage": 30, "spawn_rate": 0.01},
    "whale": {"name": "Blue Whale", "emoji": "🐋", "rarity": "legendary", "min_value": 800, "max_value": 1500, "weight_range": (50000.0, 150000.0), "catch_style": "epic", "difficulty": 10, "description": "The largest creature!", "rod_damage": 50, "spawn_rate": 0.008},
    "dragon_fish": {"name": "Dragon Fish", "emoji": "🐉", "rarity": "legendary", "min_value": 1000, "max_value": 2000, "weight_range": (10.0, 50.0), "catch_style": "mythic", "difficulty": 10, "description": "Mythical flames!", "rod_damage": 40, "spawn_rate": 0.005},
    "kraken": {"name": "Kraken", "emoji": "🦑", "rarity": "legendary", "min_value": 1500, "max_value": 3000, "weight_range": (1000.0, 5000.0), "catch_style": "mythic", "difficulty": 10, "description": "THE sea monster!", "rod_damage": 60, "spawn_rate": 0.002},
}

CATCH_STYLES = {
    "quick": {"name": "Quick Catch", "window": 2.0}, "steady": {"name": "Steady Reel", "window": 3.0},
    "fight": {"name": "Fighting Fish", "window": 2.5}, "patience": {"name": "Patient Wait", "window": 4.0},
    "careful": {"name": "Careful Handling", "window": 3.5}, "battle": {"name": "Epic Battle", "window": 2.0},
    "gentle": {"name": "Gentle Touch", "window": 3.5}, "zen": {"name": "Zen Focus", "window": 5.0},
    "epic": {"name": "Epic Struggle", "window": 1.5}, "mythic": {"name": "Mythic Encounter", "window": 1.0},
}

FISH_RARITY_COLORS = {
    "common": discord.Color.light_gray(), "uncommon": discord.Color.green(),
    "rare": discord.Color.blue(), "epic": discord.Color.purple(), "legendary": discord.Color.gold(),
}

FISHING_SHOP = {
    # Bait (Consumable)
    "worms": {
        "name": "Worms", "emoji": "🪱", "type": "bait", "price": 10,
        "description": "Basic bait. Works for common fish.",
        "rarity_bonus": {"common": 1.2, "uncommon": 1.0}
    },
    "shrimp": {
        "name": "Shrimp", "emoji": "🦐", "type": "bait", "price": 25,
        "description": "Quality bait. Attracts uncommon fish.",
        "rarity_bonus": {"common": 1.0, "uncommon": 1.3, "rare": 1.1}
    },
    "squid": {
        "name": "Squid", "emoji": "🦑", "type": "bait", "price": 50,
        "description": "Premium bait. Attracts rare fish.",
        "rarity_bonus": {"uncommon": 1.2, "rare": 1.4, "epic": 1.1}
    },
    "golden_lure": {
        "name": "Golden Lure", "emoji": "✨", "type": "bait", "price": 150,
        "description": "Legendary bait. Attracts epic and legendary fish!",
        "rarity_bonus": {"rare": 1.3, "epic": 1.5, "legendary": 1.3}
    },
    # Fishing Rods (Permanent)
    "basic_rod": {
        "name": "Basic Rod", "emoji": "🎣", "type": "rod", "price": 50,
        "description": "A simple wooden rod for beginners.",
        "catch_bonus": 0, "weight_bonus": 0, "max_durability": 100
    },
    "steel_rod": {
        "name": "Steel Rod", "emoji": "🎣", "type": "rod", "price": 200,
        "description": "+5% rewards, +10% weight",
        "catch_bonus": 5, "weight_bonus": 10, "max_durability": 200
    },
    "carbon_rod": {
        "name": "Carbon Fiber Rod", "emoji": "🎣", "type": "rod", "price": 500,
        "description": "+10% rewards, +25% weight",
        "catch_bonus": 10, "weight_bonus": 25, "max_durability": 350
    },
    "master_rod": {
        "name": "Master's Rod", "emoji": "🎣", "type": "rod", "price": 1500,
        "description": "+20% rewards, +50% weight",
        "catch_bonus": 20, "weight_bonus": 50, "max_durability": 500
    },
    "legendary_rod": {
        "name": "Legendary Rod", "emoji": "🎣", "type": "rod", "price": 5000,
        "description": "+35% rewards, +100% weight",
        "catch_bonus": 35, "weight_bonus": 100, "max_durability": 1000
    },
    # Hooks (Permanent)
    "rusty_hook": {
        "name": "Rusty Hook", "emoji": "🪝", "type": "hook", "price": 0,
        "description": "Basic hook. No bonuses.",
        "window_bonus": 0
    },
    "iron_hook": {
        "name": "Iron Hook", "emoji": "🪝", "type": "hook", "price": 100,
        "description": "+0.5s catch window",
        "window_bonus": 0.5
    },
    "barbed_hook": {
        "name": "Barbed Hook", "emoji": "🪝", "type": "hook", "price": 300,
        "description": "+1.0s catch window",
        "window_bonus": 1.0
    },
    "diamond_hook": {
        "name": "Diamond Hook", "emoji": "🪝", "type": "hook", "price": 1000,
        "description": "+2.0s catch window",
        "window_bonus": 2.0
    },
}

class Games(commands.Cog):
    """ Mini-games that use stella points - Gamble, Classic Games & Grounded Economy!"""
   
    def __init__(self, bot):
        self.bot = bot
        self.quest_data = Quest_Data(bot)
        self.session: Optional[aiohttp.ClientSession] = None
        self.active_games: Dict[str, Dict] = {}
        self.user_cooldowns: Dict[str, Dict[str, datetime]] = {}
        self.cover_art_system = CoverArtSystem(self.quest_data)
        self.cover_queue: Dict[str, asyncio.Lock] = {}
        self.active_searches: Dict[str, bool] = {}
   
    async def get_session(self) -> aiohttp.ClientSession:
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))
        return self.session
   
    def cog_unload(self):
        if self.session and not self.session.closed:
            asyncio.create_task(self.session.close())
   
    async def fetch_enhanced_character_description(self, character_name: str, anime_name: str = None) -> str:
        """Enhanced character description fetching with multiple search strategies"""
        session = await self.get_session()
        
        try:
            # Strategy 1: Direct character search by name
            description = await self._search_character_by_name(session, character_name, anime_name)
            if description and description != f"A character from {anime_name or 'Unknown'}.":
                return description
            
            # Strategy 2: Try alternative name variations (common nicknames, romanized names)
            alt_names = self._get_name_variations(character_name)
            for alt_name in alt_names:
                description = await self._search_character_by_name(session, alt_name, anime_name)
                if description and description != f"A character from {anime_name or 'Unknown'}.":
                    return description
            
            # Strategy 3: Search by anime series and find main characters
            if anime_name:
                description = await self._search_by_anime_series(session, character_name, anime_name)
                if description and description != f"A character from {anime_name or 'Unknown'}.":
                    return description
            
            # Strategy 4: Fallback to generic but informative description
            return f"A character from {anime_name or 'Unknown'}."
                    
        except Exception as e:
            logger.debug(f"Error in enhanced character description fetch for {character_name}: {e}")
        
        return f"A character from {anime_name or 'Unknown'}."
    
    async def _search_character_by_name(self, session, character_name: str, anime_name: str = None) -> str:
     """Search for character by name with Jikan API"""
     try:
        search_url = "https://api.jikan.moe/v4/characters"
        params = {
            "q": character_name,
            "limit": 15
        }

        print(f"Searching for character: '{character_name}' from anime: '{anime_name}'")

        async with session.get(
            search_url,
            params=params,
            timeout=aiohttp.ClientTimeout(total=3)
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                characters = data.get("data", [])

                print(f"Found {len(characters)} characters for '{character_name}'")
                
                # Debug: Print the first character structure
                if characters:
                    print(f"First character structure: {json.dumps(characters[0], indent=2)}")

                if not characters:
                    return f"A character from {anime_name or 'Unknown'}."

                best_match = None
                best_score = 0
                char_name_lower = character_name.lower()

                for i, char in enumerate(characters):
                    # Handle different API response structures
                    char_data = char.get("character", char)  # Use char itself if no nested character object
                    char_name_api = char_data.get("name", "").lower()
                    score = 0

                    if char_name_api == char_name_lower:
                        score += 100
                        print(f"Exact match found: '{char_name_api}' (score: {score})")
                    elif char_name_lower in char_name_api or char_name_api in char_name_lower:
                        score += 50
                        print(f"Partial match: '{char_name_api}' (score: {score})")

                    if anime_name and char.get("anime"):
                        for anime in char.get("anime", []):
                            anime_title = anime.get("title", "").lower()
                            if anime_name.lower() in anime_title or anime_title in anime_name.lower():
                                score += 30
                                print(f"Anime match: '{anime_title}' (score: {score})")
                                break

                    for nickname in char_data.get("nicknames", []):
                        if char_name_lower in nickname.lower() or nickname.lower() in char_name_lower:
                            score += 25
                            print(f"Nickname match: '{nickname}' (score: {score})")
                            break

                    print(f"Character {i}: '{char_name_api}' - Final score: {score}")

                    if score > best_score:
                        best_score = score
                        best_match = char_data
                        print(f"New best match: '{char_name_api}' with score {score}")

                if best_match:
                    print(f"Best match: '{best_match.get('name', 'Unknown')}' with score {best_score}")

                if best_match and best_score >= 25:
                    about = best_match.get("about", "")
                    if about:
                        about = about.replace("\n\n", " ").replace("\n", " ")
                        about = about[:300]
                        if len(about) == 300:
                            about = about.rsplit(" ", 1)[0] + "..."
                        print(f"Returning description for '{best_match.get('name')}'")
                        return about

                    nicknames = best_match.get("nicknames", [])
                    if nicknames:
                        anime_title = anime_name or "Unknown"
                        return f"Also known as: {', '.join(nicknames[:3])}. A character from {anime_title}"

                print(f"No good match found (best score: {best_score})")

     except Exception as e:
        print(f"Error in character name search: {e}")

     return f"A character from {anime_name or 'Unknown'}."

    async def _search_by_anime_series(self, session, character_name: str, anime_name: str) -> str:
        """Search for character within a specific anime series"""
        try:
            # First search for the anime
            anime_search_url = f"https://api.jikan.moe/v4/anime"
            params = {
                "q": anime_name,
                "limit": 5
            }
            
            async with session.get(anime_search_url, params=params, timeout=aiohttp.ClientTimeout(total=3)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    animes = data.get("data", [])
                    
                    if animes:
                        # Get the first matching anime
                        anime = animes[0]
                        anime_id = anime.get("mal_id")
                        
                        if anime_id:
                            # Get characters for this anime
                            characters_url = f"https://api.jikan.moe/v4/anime/{anime_id}/characters"
                            
                            async with session.get(characters_url, timeout=aiohttp.ClientTimeout(total=3)) as char_resp:
                                if char_resp.status == 200:
                                    char_data = await char_resp.json()
                                    characters = char_data.get("data", [])
                                    
                                    # Find matching character
                                    char_name_lower = character_name.lower()
                                    for char_info in characters:
                                        char = char_info.get("character", {})
                                        char_name_api = char.get("name", "").lower()
                                        
                                        # Check for name match
                                        if (char_name_api == char_name_lower or 
                                            char_name_lower in char_name_api or 
                                            char_name_api in char_name_lower):
                                            
                                            about = char.get("about", "")
                                            if about:
                                                about = about.replace("\n\n", " ").replace("\n", " ")
                                                about = about[:300]
                                                if len(about) == 300:
                                                    about = about.rsplit(" ", 1)[0] + "..."
                                                return about
                                            
                                            # Fallback to role information
                                            role = char_info.get("role", "Character")
                                            return f"A {role.lower()} from {anime.get('title', anime_name)}."
        
        except Exception as e:
            logger.debug(f"Error in anime series search: {e}")
        
        return f"A character from {anime_name or 'Unknown'}."
    
    def _get_name_variations(self, character_name: str) -> list:
        """Generate common name variations for better search results"""
        variations = []
        name_lower = character_name.lower()
        
        # Common patterns
        if " " in character_name:
            # Split names - try first and last name separately
            parts = character_name.split()
            if len(parts) >= 2:
                variations.append(parts[0])  # First name
                variations.append(parts[-1])  # Last name
                variations.append(parts[0] + " " + parts[-1])  # First + Last
        
        # Common Japanese name patterns
        if "-" in character_name:
            parts = character_name.split("-")
            variations.extend(parts)
        
        # Remove common honorifics
        honorifics = ["-san", "-chan", "-kun", "-sama", "-sensei", "-senpai"]
        for honorific in honorifics:
            if name_lower.endswith(honorific):
                variations.append(character_name[:-len(honorific)])
        
        # Special case variations for common character names
        special_variations = {
            "megumin": ["Megumin"],  # Already capitalized correctly
            "anya": ["Anya", "Anya Forger"],
            "eren": ["Eren", "Eren Yeager"],
            "mikasa": ["Mikasa", "Mikasa Ackerman"],
            "emilia": ["Emilia"],
            "rem": ["Rem"],
            "ram": ["Ram"],
            "zero two": ["Zero Two", "02", "002"],
            "darling": ["Zero Two", "02", "002"],
        }
        
        # Add special variations if character name matches
        for key, vars_list in special_variations.items():
            if key in name_lower or name_lower in key:
                variations.extend(vars_list)
        
        # Add original name
        variations.append(character_name)
        
        # Remove duplicates while preserving order
        seen = set()
        return [x for x in variations if not (x in seen or seen.add(x))]
   
    async def get_user_character(self, user_id: str, guild_id: str) -> Optional[str]:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.inventory.selected_character": 1}
            )
            if result:
                return result.get("members", {}).get(user_id, {}).get("inventory", {}).get("selected_character")
        except Exception as e:
            logger.error(f"Error getting character: {e}")
        return None
   
    async def check_cooldown(self, user_id: str, action: str, cooldown_seconds: int, guild_id: str = None) -> Optional[timedelta]:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            # Use guild-specific cooldowns for claim, gacha, and work commands
            # Use global cooldowns for other actions
            if guild_id and action in ["claim", "gacha_main", "work", "rob"]:
                collection_key = guild_id
                query_field = f"members.{user_id}.cooldowns.{action}"
            else:
                collection_key = "global_cooldowns"
                query_field = f"cooldowns.{user_id}.{action}"
            
            result = await server_col.find_one(
                {"guild_id": collection_key},
                {query_field: 1}
            )
            
            if result:
                if guild_id and action in ["claim", "gacha_main", "work", "rob"]:
                    last_time_str = result.get("members", {}).get(user_id, {}).get("cooldowns", {}).get(action)
                else:
                    last_time_str = result.get("cooldowns", {}).get(user_id, {}).get(action)
                    
                if last_time_str:
                    last_time = datetime.fromisoformat(last_time_str)
                    elapsed = datetime.now(timezone.utc) - last_time
                    if elapsed.total_seconds() < cooldown_seconds:
                        return timedelta(seconds=cooldown_seconds) - elapsed
        except Exception as e:
            logger.error(f"Cooldown check error: {e}")
        return None
   
    async def set_cooldown(self, user_id: str, action: str, guild_id: str = None):
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            # Use guild-specific cooldowns for claim, gacha, and work commands
            # Use global cooldowns for other actions
            if guild_id and action in ["claim", "gacha_main", "work", "rob"]:
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$set": {f"members.{user_id}.cooldowns.{action}": datetime.now(timezone.utc).isoformat()}},
                    upsert=True
                )
            else:
                await server_col.update_one(
                    {"guild_id": "global_cooldowns"},
                    {"$set": {f"cooldowns.{user_id}.{action}": datetime.now(timezone.utc).isoformat()}},
                    upsert=True
                )
        except Exception as e:
            logger.error(f"Set cooldown error: {e}")
   
    async def check_timer(self, ctx, command: str) -> Optional[str]:
        user_id = str(ctx.author.id)
        guild_id = str(ctx.guild.id)
        config = get_timer_config(command)
       
        command_cooldown = config.get("command_cooldown", 5)
        remaining = await self.check_cooldown(user_id, f"{command}_command", command_cooldown, guild_id)
        if remaining:
            return format_cooldown_message(remaining, command)
       
        if not uses_daily_reset(command):
            current_uses = await self.get_current_uses(user_id, guild_id, command)
            if current_uses >= config["max_uses"]:
                main_remaining = await self.check_cooldown(user_id, f"{command}_main", config["cooldown"], guild_id)
                if main_remaining:
                    return format_cooldown_message(main_remaining, command)
                else:
                    await self.reset_uses(user_id, guild_id, command)
                    return None
        else:
            daily_plays = await self.get_daily_plays(user_id, guild_id, command)
            if daily_plays >= config["max_uses"]:
                return f"⏰ {command.replace('_', ' ').title()} is limited to {config['max_uses']} uses per day. You've used all {config['max_uses']} uses today."
       
        return None
   
    def get_user_lock(self, user_id: str) -> asyncio.Lock:
        if user_id not in self.cover_queue:
            self.cover_queue[user_id] = asyncio.Lock()
        return self.cover_queue[user_id]
   
    async def check_cover_command_cooldown(self, ctx) -> bool:
        user_id = str(ctx.author.id)
        if self.active_searches.get(user_id, False):
            await ctx.reply("⏳ You're already running a cover art command! Please wait for it to complete.", mention_author=False)
            return False
        return True
   
    async def set_cover_command_status(self, user_id: str, active: bool):
        self.active_searches[user_id] = active
   
    async def get_daily_streak(self, user_id: str, guild_id: str) -> tuple[int, Optional[datetime]]:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.daily_streak": 1, f"members.{user_id}.last_claim_date": 1}
            )
            if result:
                member_data = result.get("members", {}).get(user_id, {})
                streak = member_data.get("daily_streak", 0)
                last_claim_str = member_data.get("last_claim_date")
                last_claim_date = datetime.fromisoformat(last_claim_str) if last_claim_str else None
                return streak, last_claim_date
        except Exception as e:
            logger.error(f"Error getting streak: {e}")
        return 0, None
   
    async def update_daily_streak(self, user_id: str, guild_id: str, streak: int):
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$set": {f"members.{user_id}.daily_streak": streak, 
                          f"members.{user_id}.last_claim_date": datetime.now(timezone.utc).isoformat()}},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error updating streak: {e}")
   
    def format_time(self, td: timedelta) -> str:
        total_seconds = int(td.total_seconds())
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        if hours > 0:
            return f"{hours}h {minutes}m"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
   
    async def get_daily_plays(self, user_id: str, guild_id: str, game: str) -> int:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_collection = db["Servers"]
            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            result = await server_collection.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.games.{game}.{today}": 1}
            )
            if result:
                return result.get("members", {}).get(user_id, {}).get("games", {}).get(game, {}).get(today, 0)
            return 0
        except Exception as e:
            logger.error(f"Error getting daily plays: {e}")
            return 0
   
    async def increment_daily_plays(self, user_id: str, guild_id: str, game: str):
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_collection = db["Servers"]
            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            await server_collection.update_one(
                {"guild_id": guild_id},
                {"$inc": {f"members.{user_id}.games.{game}.{today}": 1}},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error incrementing daily plays: {e}")
   
    async def increment_plays(self, user_id: str, guild_id: str, command: str):
        config = get_timer_config(command)
        if uses_daily_reset(command):
            await self.increment_daily_plays(user_id, guild_id, command)
        else:
            await self.increment_current_uses(user_id, guild_id, command)
            current_uses = await self.get_current_uses(user_id, guild_id, command)
            if current_uses >= config["max_uses"]:
                await self.set_cooldown(user_id, f"{command}_main", guild_id)
   
    async def get_current_uses(self, user_id: str, guild_id: str, command: str) -> int:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.game_uses.{command}": 1}
            )
            if result:
                return result.get("members", {}).get(user_id, {}).get("game_uses", {}).get(command, 0)
        except Exception as e:
            logger.error(f"Error getting current uses: {e}")
        return 0
   
    async def increment_current_uses(self, user_id: str, guild_id: str, command: str):
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$inc": {f"members.{user_id}.game_uses.{command}": 1}},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error incrementing current uses: {e}")
   
    async def reset_uses(self, user_id: str, guild_id: str, command: str):
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$set": {f"members.{user_id}.game_uses.{command}": 0}},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error resetting uses: {e}")
    
    async def get_session_claims(self, user_id: str, guild_id: str) -> int:
        """Get the number of claims made in the current gacha session."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_session_claims": 1, f"members.{user_id}.gacha_session_start": 1}
            )
            if result:
                member_data = result.get("members", {}).get(user_id, {})
                session_start = member_data.get("gacha_session_start")
                claims = member_data.get("gacha_session_claims", 0)
                
                # Check if session is still valid (within cooldown period)
                if session_start:
                    from datetime import datetime, timezone, timedelta
                    gacha_config = get_timer_config("gacha")
                    cooldown_seconds = gacha_config["cooldown"]
                    
                    # Ensure session_start is timezone-aware
                    if session_start.tzinfo is None:
                        session_start = session_start.replace(tzinfo=timezone.utc)
                    
                    session_expiry = session_start + timedelta(seconds=cooldown_seconds)
                    
                    if datetime.now(timezone.utc) > session_expiry:
                        # Session expired, reset claims
                        await self.reset_session_claims(user_id, guild_id)
                        return 0
                
                return claims
        except Exception as e:
            logger.error(f"Error getting session claims: {e}")
        return 0
    
    async def increment_session_claims(self, user_id: str, guild_id: str):
        """Increment the number of claims in the current gacha session."""
        try:
            from datetime import datetime, timezone
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            # Check if session exists
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_session_start": 1}
            )
            
            session_start = result.get("members", {}).get(user_id, {}).get("gacha_session_start") if result else None
            
            if not session_start:
                # Start new session
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {
                        "$set": {
                            f"members.{user_id}.gacha_session_start": datetime.now(timezone.utc),
                            f"members.{user_id}.gacha_session_claims": 1
                        }
                    },
                    upsert=True
                )
            else:
                # Increment existing session
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$inc": {f"members.{user_id}.gacha_session_claims": 1}},
                    upsert=True
                )
        except Exception as e:
            logger.error(f"Error incrementing session claims: {e}")
    
    async def reset_session_claims(self, user_id: str, guild_id: str):
        """Reset gacha session claims."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {
                    "$unset": {
                        f"members.{user_id}.gacha_session_claims": "",
                        f"members.{user_id}.gacha_session_start": ""
                    }
                },
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error resetting session claims: {e}")

    # ===================================================================
    # FISHING SESSION TRACKING (Similar to Gacha)
    # ===================================================================
    
    async def get_fish_session_uses(self, user_id: str, guild_id: str) -> int:
        """Get the number of fish attempts in the current fishing session."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.fish_session_uses": 1, f"members.{user_id}.fish_session_start": 1}
            )
            if result:
                member_data = result.get("members", {}).get(user_id, {})
                session_start = member_data.get("fish_session_start")
                uses = member_data.get("fish_session_uses", 0)
                
                # Check if session is still valid (within cooldown period)
                if session_start:
                    from datetime import datetime, timezone, timedelta
                    fish_config = get_timer_config("fish")
                    cooldown_seconds = fish_config["cooldown"]
                    
                    # Ensure session_start is timezone-aware
                    if session_start.tzinfo is None:
                        session_start = session_start.replace(tzinfo=timezone.utc)
                    
                    session_expiry = session_start + timedelta(seconds=cooldown_seconds)
                    
                    if datetime.now(timezone.utc) > session_expiry:
                        # Session expired, reset uses
                        await self.reset_fish_session(user_id, guild_id)
                        return 0
                
                return uses
        except Exception as e:
            logger.error(f"Error getting fish session uses: {e}")
        return 0
    
    async def increment_fish_session(self, user_id: str, guild_id: str):
        """Increment the number of fish attempts in the current session."""
        try:
            from datetime import datetime, timezone
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            # Check if session exists
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.fish_session_start": 1}
            )
            
            session_start = result.get("members", {}).get(user_id, {}).get("fish_session_start") if result else None
            
            if not session_start:
                # Start new session
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {
                        "$set": {
                            f"members.{user_id}.fish_session_start": datetime.now(timezone.utc),
                            f"members.{user_id}.fish_session_uses": 1
                        }
                    },
                    upsert=True
                )
            else:
                # Increment existing session
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$inc": {f"members.{user_id}.fish_session_uses": 1}},
                    upsert=True
                )
        except Exception as e:
            logger.error(f"Error incrementing fish session: {e}")
    
    async def reset_fish_session(self, user_id: str, guild_id: str):
        """Reset fishing session uses."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {
                    "$unset": {
                        f"members.{user_id}.fish_session_uses": "",
                        f"members.{user_id}.fish_session_start": ""
                    }
                },
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error resetting fish session: {e}")

    # ===================================================================
    # GACHA SYSTEM - EXTREMELY RARE (Shiny Pokemon level)
    # ===================================================================
    
    async def fetch_character_by_rarity(self, target_rarity: str) -> Optional[Dict]:
        """Fetch a character matching the target rarity tier - uses fast custom API first."""
        session = await self.get_session()
        
        # Try fast custom API first (instant response from pre-cached characters)
        try:
            char = await fetch_from_gacha_api(session, target_rarity)
            if char and char.get("image_url") and char.get("anime"):
                return char
        except Exception as e:
            logger.debug(f"Fast Gacha API failed: {e}")
        
        # Fallback to external APIs if custom API unavailable
        apis = [
            (fetch_jikan_character, "jikan"),
            (fetch_anilist_character, "anilist"),
        ]
        random.shuffle(apis)

        for api_func, api_name in apis:
            try:
                char = await api_func(session, target_rarity)
                if char:
                    anime_pop = char.get("anime_popularity", 0)
                    char_favs = char.get("favorites", 0)
                    char["rarity"] = get_combined_rarity(anime_pop, char_favs)
                    return char
            except Exception as e:
                logger.debug(f"Gacha API error ({api_name}): {e}")
        return None
   
    async def fetch_character_by_name(self, name: str) -> Optional[Dict]:
        """Fetch a specific character by name using multiple API sources with failover."""
        session = await self.get_session()
        
        try:
            # Clean the character name for search
            clean_name = name.strip().lower()
            
      
            
            # Try API sources in order of preference
            api_sources = [
                ("Jikan", fetch_jikan_character_by_name),
                ("AniList", fetch_anilist_character_by_name),
                ("Kitsu", fetch_kitsu_character_by_name)
            ]
            
            for api_name, fetch_func in api_sources:
                try:
                    logger.debug(f"Trying {api_name} API for '{name}'")
                    char = await fetch_func(session, clean_name)
                    
                    if char and char.get("image_url") and char.get("anime"):
                        # Ensure proper rarity assignment
                        if not char.get("rarity"):
                            anime_pop = char.get("anime_popularity", 0)
                            char_favs = char.get("favorites", 0)
                            char["rarity"] = get_combined_rarity(anime_pop, char_favs)
                        
                        logger.info(f"[{api_name}] Found character: {name} -> {char.get('name', 'Unknown')}")
                        return char
                    else:
                        logger.debug(f"[{api_name}] No valid character found for '{name}'")
                        
                except Exception as e:
                    logger.debug(f"[{api_name}] API failed for '{name}': {e}")
                    continue  # Move to next API source
            
            # If all APIs failed, try enhanced fuzzy search as last resort
            logger.info(f"All APIs failed for '{name}', trying enhanced fuzzy search")
            return await self._enhanced_fuzzy_character_search(clean_name)
            
        except Exception as e:
            logger.error(f"Error fetching character by name '{name}': {e}")
            return None
    
    async def _get_full_character_details(self, char_id: int) -> Optional[Dict]:
        """Get full character details from MAL API."""
        session = await self.get_session()
        
        try:
            async with session.get(f"https://api.jikan.moe/v4/characters/{char_id}/full", timeout=aiohttp.ClientTimeout(total=3)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    char_data = data.get("data", {})
                    return self._format_character_data(char_data)
        except Exception as e:
            logger.debug(f"Failed to get full character details for ID {char_id}: {e}")
        
        return None
    
    async def _enhanced_fuzzy_character_search(self, name: str) -> Optional[Dict]:
        """Enhanced fuzzy search using all available APIs."""
        session = await self.get_session()
        
        try:
           
            # Try fuzzy search with each API
            api_sources = [
                ("Jikan", fetch_jikan_character_by_name),
                ("AniList", fetch_anilist_character_by_name),
                ("Kitsu", fetch_kitsu_character_by_name)
            ]
            
            for api_name, fetch_func in api_sources:
                try:
                    # For short names, try more aggressive search
                    if len(name) <= 3:
                        # Try partial matches
                        char = await fetch_func(session, name[:2] if len(name) > 2 else name)
                        if char and char.get("image_url") and char.get("anime"):
                            logger.info(f"[{api_name}] Fuzzy found: {name} -> {char.get('name', 'Unknown')}")
                            return char
                    else:
                        # For longer names, try word parts
                        name_parts = name.split()
                        for part in name_parts:
                            if len(part) >= 2:
                                char = await fetch_func(session, part)
                                if char and char.get("image_url") and char.get("anime"):
                                    # Check if this result contains our original search terms
                                    char_name = char.get("name", "").lower()
                                    if any(p in char_name for p in name_parts if len(p) > 1):
                                        logger.info(f"[{api_name}] Fuzzy found: {name} -> {char.get('name', 'Unknown')}")
                                        return char
                except Exception as e:
                    logger.debug(f"[{api_name}] Fuzzy search failed for '{name}': {e}")
                    continue
            
            return None
        except Exception as e:
            logger.debug(f"Enhanced fuzzy search failed for '{name}': {e}")
        
        return None

    async def _fuzzy_character_search(self, name: str) -> Optional[Dict]:
        """Try fuzzy search for character name."""
        session = await self.get_session()
        
        try:
            # Try with partial name matching
            name_parts = name.split()
            
            # For short names (like "rem", "Ram"), try more aggressive search
            if len(name) <= 3:
                # Search for names that start with our short name
                async with session.get(f"https://api.jikan.moe/v4/characters?q={name}&limit=10", timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        results = data.get("data", [])
                        
                        for char_data in results:
                            char_name = char_data.get("name", "").lower()
                            # For short names, check if result starts with our search term
                            if char_name.startswith(name):
                                return self._format_character_data(char_data)
            
            # For longer names, try partial matching
            for part in name_parts:
                if len(part) < 2:  # Reduced threshold for better matching
                    continue
                    
                async with session.get(f"https://api.jikan.moe/v4/characters?q={part}&limit=8", timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        results = data.get("data", [])
                        
                        for char_data in results:
                            char_name = char_data.get("name", "").lower()
                            # Check if this result contains our search terms
                            if len(name_parts) == 1:
                                # Single word search - be more lenient
                                if part in char_name or char_name.startswith(part):
                                    return self._format_character_data(char_data)
                            else:
                                # Multi-word search - require all parts to match
                                if all(p in char_name for p in name_parts if len(p) > 1):
                                    return self._format_character_data(char_data)
        except Exception as e:
            logger.debug(f"Fuzzy search failed for '{name}': {e}")
        
        return None
    
    def _format_character_data(self, char_data: Dict) -> Dict:
        """Format character data from API into standard format."""
        # Get anime information - handle different API response formats
        anime_name = "Unknown"
        anime_popularity = 0
        
        # Try different anime data structures
        anime_info = char_data.get("anime", [])
        if anime_info and isinstance(anime_info, list) and len(anime_info) > 0:
            # Format: [{"anime": {"name": "...", "popularity": ...}}] or [{"anime": {...}}]
            first_anime = anime_info[0]
            if isinstance(first_anime, dict):
                # Check if it's nested: {"anime": {...}} or direct: {"name": "..."}
                if "anime" in first_anime:
                    anime_data = first_anime.get("anime", {})
                    anime_name = anime_data.get("title", anime_data.get("name", "Unknown"))
                    anime_popularity = anime_data.get("popularity", 0)
                else:
                    # Direct format
                    anime_name = first_anime.get("title", first_anime.get("name", "Unknown"))
                    anime_popularity = first_anime.get("popularity", 0)
        elif isinstance(anime_info, dict):
            # Format: {"name": "...", "popularity": ...} or {"title": "..."}
            anime_name = anime_info.get("title", anime_info.get("name", "Unknown"))
            anime_popularity = anime_info.get("popularity", 0)
        
        # Alternative: check for direct anime field
        if anime_name == "Unknown" and "anime" in char_data:
            direct_anime = char_data.get("anime")
            if isinstance(direct_anime, str):
                anime_name = direct_anime
            elif isinstance(direct_anime, dict):
                anime_name = direct_anime.get("title", direct_anime.get("name", "Unknown"))
        
        # Get character image
        image_url = char_data.get("images", {}).get("jpg", {}).get("image_url")
        if not image_url:
            image_url = char_data.get("image_url")  # Fallback
        
        # Determine gender (basic detection)
        name = char_data.get("name", "")
        gender = "Unknown"
        
        # Simple gender detection based on name and other info
        if any(indicator in name.lower() for indicator in ["-chan", "-ko", "mi", "ka", "na"]):
            gender = "Female"
        elif any(indicator in name.lower() for indicator in ["-kun", "-shi", "ro", "ki", "ta"]):
            gender = "Male"
        
        # Get favorites count
        favorites = char_data.get("favorites", 0)
        
        return {
            "id": char_data.get("mal_id", random.randint(1, 999999)),
            "name": char_data.get("name", "Unknown"),
            "anime": anime_name,
            "anime_popularity": anime_popularity,
            "image_url": image_url,
            "gender": gender,
            "favorites": favorites,
            "nicknames": char_data.get("nicknames", []),
            "about": char_data.get("about", "")
        }

    async def pull_gacha_cards(self, num_cards: int = 3, gender_filter: Optional[str] = None, guild_id: str = None) -> List[Dict]:
        """Pull gacha cards using pure RNG - extremely rare drops.
        
        This system rolls rarity first, then fetches characters from the API
        that match that rarity tier based on their popularity/favorites.
        
        All characters in the same draw are guaranteed to be unique.
        """
        cards = []
        drawn_character_ids = set()  # Track already drawn characters in this session
        global_character_pool = set()  # Track characters seen recently across all draws
        
        for i in range(num_cards):
            # Roll rarity using pure RNG (no pity)
            rolled_rarity = roll_gacha_rarity()
            
            # Fetch character matching that rarity from API
            # The API functions now properly filter by popularity ranges
            char = None
            attempts = 0
            max_attempts = 1  # Single attempt for maximum speed
            
            while char is None and attempts < 1:  # Only 1 attempt for maximum speed
                char = await self.fetch_character_by_rarity(rolled_rarity)
                attempts += 1
                
                # Validate character has required fields
                if char:
                    if not char.get("image_url") or not char.get("anime") or char.get("anime") == "Unknown":
                        char = None
                        continue
                
                # Apply gender filter if specified
                if char and gender_filter:
                    char_gender = char.get("gender", "").lower()
                    if gender_filter == "Female" and char_gender not in ["female", "f"]:
                        char = None
                        continue
                    elif gender_filter == "Male" and char_gender not in ["male", "m"]:
                        char = None
                        continue
                
                # Fast rarity validation using consolidated function
                if char:
                    anime_pop = char.get("anime_popularity", 0)
                    char_favs = char.get("favorites", 0)
                    actual_rarity = get_combined_rarity(anime_pop, char_favs)
                    
                    # Single function call for all rarity matching
                    if not matches_target_rarity(actual_rarity, rolled_rarity):
                        char = None
                        continue
                
                # UNIQUENESS CHECK: Ensure character hasn't been drawn in this session
                if char:
                    char_id = char.get("id")
                    char_name = char.get("name", "").lower()
                    # Create unique identifier using both ID and name
                    unique_id = f"{char_id}_{char_name}"
                    
                    if unique_id in drawn_character_ids:
                        # Character already drawn in this session, reroll
                        char = None
                        continue
            
            if char:
                cards.append(char)
                drawn_character_ids.add(f"{char.get('id')}_{char.get('name', '').lower()}")
            else:
                # Fallback: Try one more time with any rarity if original rarity failed
                logger.warning(f"Failed to fetch {rolled_rarity} character after {max_attempts} attempts, trying fallback")
                fallback_attempts = 2  # Reduced fallback attempts
                for _ in range(fallback_attempts):
                    fallback_char = await self.fetch_character_by_rarity("common")  # Try common as fallback
                    if fallback_char and fallback_char.get("image_url") and fallback_char.get("anime"):
                        # Check uniqueness for fallback too
                        fallback_id = f"{fallback_char.get('id')}_{fallback_char.get('name', '').lower()}"
                        if fallback_id not in drawn_character_ids:
                            fallback_char["rarity"] = rolled_rarity  # Override rarity to match roll
                            cards.append(fallback_char)
                            drawn_character_ids.add(fallback_id)
                            logger.info(f"Used fallback common character for {rolled_rarity} roll")
                            break
                else:
                    # Last resort: Use a well-known character with guaranteed data
                    logger.error(f"All attempts failed, using emergency fallback")
                    emergency_char = {
                        "id": 40 + i,  # Spike Spiegel + variation
                        "name": f"Character {i+1}",
                        "anime": "Fallback Anime",
                        "favorites": 50000,
                        "gender": "Unknown",
                        "image_url": "https://cdn.myanimelist.net/images/characters/4/50197.jpg",
                        "rarity": rolled_rarity,
                        "api_source": "Emergency Fallback"
                    }
                    cards.append(emergency_char)
        
        return cards

    async def pull_three_cards_real(self, gender_filter: Optional[str] = None, **kwargs) -> List[Dict]:
        """Pull 3 gacha cards - pure RNG, no pity."""
        guild_id = kwargs.get("guild_id")
        return await self.pull_gacha_cards(3, gender_filter, guild_id)

    def get_random_rarity(self) -> str:
        """Get random rarity using the brutal drop rates."""
        return roll_gacha_rarity()
   
    def get_slot_symbol(self) -> str:
        symbols = list(SLOT_SYMBOLS.keys())
        weights = [SLOT_SYMBOLS[s]["weight"] for s in symbols]
        return random.choices(symbols, weights=weights, k=1)[0]
   
    async def fetch_pokemon_info(self, pokemon_id: int) -> Optional[Dict[str, Any]]:
        session = await self.get_session()
        try:
            async with session.get(f"https://pokeapi.co/api/v2/pokemon/{pokemon_id}") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return {
                        "name": data["name"].replace("-", " ").title(),
                        "id": data["id"],
                        "sprite": data["sprites"]["other"]["official-artwork"]["front_default"]
                                  or data["sprites"]["front_default"],
                        "types": [t["type"]["name"].title() for t in data.get("types", [])],
                    }
        except Exception as e:
            logger.debug(f"Pokemon API error (using fallback): {e}")
        return None

    async def add_character_to_inventory(self, user_id: str, guild_id: str, character: dict) -> str:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
           
            uid = generate_uid()
            favorites = character.get("favorites", 0)
           
            char_data = {
                "uid": uid,
                "id": character.get("id", random.randint(1, 999999)),
                "name": character.get("name"),
                "anime": character.get("anime"),
                "image_url": character.get("image_url"),
                "rarity": character.get("rarity", "common"),
                "gender": character.get("gender", "Unknown"),
                "favorites": favorites,
                "claimed_at": datetime.now(timezone.utc).isoformat(),
                "cover_unlocked": False,
                "cover_progress": 0,
            }
           
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$push": {f"members.{user_id}.gacha_inventory": char_data}},
                upsert=True
            )
            return uid
        except Exception as e:
            logger.error(f"Error adding character to inventory: {e}")
            return None
   
    async def is_character_owned_in_server(self, guild_id: str, char_name: str, char_id: int = None) -> tuple:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
           
            server_data = await server_col.find_one({"guild_id": guild_id})
            if not server_data or "members" not in server_data:
                return (False, None)
           
            char_name_lower = char_name.lower() if char_name else ""
           
            for user_id, member_data in server_data.get("members", {}).items():
                inventory = member_data.get("gacha_inventory", [])
                for owned_char in inventory:
                    if (owned_char.get("id") == char_id or
                        (owned_char.get("name", "").lower() == char_name_lower)):
                        return (True, user_id)
           
            return (False, None)
        except Exception as e:
            logger.error(f"Error checking character ownership: {e}")
            return (False, None)
   
    async def get_characters_from_same_anime(self, guild_id: str, anime_name: str, exclude_uid: str = None) -> list:
        """Get other characters from the same anime in the server."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            server_data = await server_col.find_one({"guild_id": guild_id})
            if not server_data or "members" not in server_data:
                return []
            
            same_anime_chars = []
            members = server_data.get("members", {})
            
            for member_id, member_data in members.items():
                inventory = member_data.get("gacha_inventory", [])
                for char in inventory:
                    if char.get("anime") == anime_name:
                        # Exclude the current character if specified
                        if exclude_uid and char.get("uid", "").upper() == exclude_uid.upper():
                            continue
                        # Add owner info
                        char_copy = char.copy()
                        char_copy["owner_id"] = member_id
                        same_anime_chars.append(char_copy)
            
            return same_anime_chars
        except Exception as e:
            logger.error(f"Error getting characters from same anime: {e}")
            return []

    async def get_character_by_uid(self, guild_id: str, uid: str) -> tuple:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
           
            server_data = await server_col.find_one({"guild_id": guild_id})
            if not server_data or "members" not in server_data:
                return (None, None)
           
            for user_id, member_data in server_data.get("members", {}).items():
                inventory = member_data.get("gacha_inventory", [])
                for char in inventory:
                    if char.get("uid", "").upper() == uid.upper():
                        return (user_id, char)
           
            return (None, None)
        except Exception as e:
            logger.error(f"Error getting character by UID: {e}")
            return (None, None)
   
    async def remove_character_from_inventory(self, user_id: str, guild_id: str, uid: str) -> dict:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
           
            server_data = await server_col.find_one({"guild_id": guild_id})
            if not server_data:
                return None
           
            member_data = server_data.get("members", {}).get(user_id, {})
            inventory = member_data.get("gacha_inventory", [])
           
            char_to_remove = None
            for char in inventory:
                if char.get("uid", "").upper() == uid.upper():
                    char_to_remove = char
                    break
           
            if not char_to_remove:
                return None
           
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$pull": {f"members.{user_id}.gacha_inventory": {"uid": char_to_remove["uid"]}}}
            )
            
            return char_to_remove
           
        except Exception as e:
            logger.error(f"Error removing character: {e}")
            return None
   
    async def get_user_inventory(self, user_id: str, guild_id: str) -> list:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            server_data = await server_col.find_one({"guild_id": guild_id})
            if server_data and "members" in server_data:
                member_data = server_data["members"].get(user_id, {})
                inventory = member_data.get("gacha_inventory", [])
                
                # Clean up characters with invalid UIDs (???)
                cleaned_inventory = []
                removed_count = 0
                
                for char in inventory:
                    uid = char.get("uid", "")
                    if uid and uid != "???":
                        cleaned_inventory.append(char)
                    else:
                        removed_count += 1
                
                # Update database if we removed invalid characters
                if removed_count > 0:
                    await server_col.update_one(
                        {"guild_id": guild_id, f"members.{user_id}": {"$exists": True}},
                        {"$set": {f"members.{user_id}.gacha_inventory": cleaned_inventory}}
                    )
                    logger.info(f"Cleaned up {removed_count} invalid characters from user {user_id}")
                
                return cleaned_inventory
        except Exception as e:
            logger.error(f"Error fetching inventory: {e}")
        return []
    
    async def analyze_character_rarity(self, guild_id: str) -> dict:
        """Analyze actual rarity based on ownership counts across all players"""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            server_data = await server_col.find_one({"guild_id": guild_id})
            if not server_data or "members" not in server_data:
                return {}
            
            # Count ownership for each character
            character_ownership = {}
            total_players = 0
            
            for user_id, member_data in server_data.get("members", {}).items():
                inventory = member_data.get("gacha_inventory", [])
                if inventory:  # Only count users with inventory
                    total_players += 1
                    
                for char in inventory:
                    char_id = char.get("id", char.get("name", "").lower())
                    if char_id:
                        if char_id not in character_ownership:
                            character_ownership[char_id] = {
                                "count": 0,
                                "owners": set(),
                                "rarity": "unknown",
                                "name": char.get("name", "Unknown")
                            }
                        character_ownership[char_id]["count"] += 1
                        character_ownership[char_id]["owners"].add(user_id)
            
            # Determine rarity based on ownership patterns
            for char_id, data in character_ownership.items():
                ownership_count = data["count"]
                unique_owners = len(data["owners"])
                
                # Rarity tiers based on actual scarcity
                if unique_owners == 1:
                    data["rarity"] = "legendary"  # Only owned by 1 person
                elif unique_owners <= 3:
                    data["rarity"] = "epic"       # Owned by 2-3 people
                elif ownership_count <= 5:
                    data["rarity"] = "rare"       # 5 or fewer copies total
                elif unique_owners <= total_players * 0.1:  # Owned by <= 10% of players
                    data["rarity"] = "uncommon"
                else:
                    data["rarity"] = "common"     # Widely owned
            
            return character_ownership
            
        except Exception as e:
            logger.error(f"Error analyzing character rarity: {e}")
            return {}
   
    async def check_character_ownership(self, guild: discord.Guild, characters: list) -> dict:
        ownership = {}
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            guild_id = str(guild.id)
           
            # Build list of character IDs and names to search for
            char_ids = [char.get("id") for char in characters if char.get("id")]
            char_names_lower = [char.get("name", "").lower() for char in characters]
            
            # Use aggregation to efficiently find owners
            pipeline = [
                {"$match": {"guild_id": guild_id}},
                {"$project": {
                    "members": {"$objectToArray": "$members"}
                }},
                {"$unwind": "$members"},
                {"$project": {
                    "user_id": "$members.k",
                    "inventory": "$members.v.gacha_inventory"
                }},
                {"$unwind": "$inventory"},
                {"$match": {
                    "$or": [
                        {"inventory.id": {"$in": char_ids}},
                        {"inventory.name": {"$in": char_names_lower}}
                    ]
                }},
                {"$limit": len(characters)}
            ]
            
            cursor = server_col.aggregate(pipeline)
            results = await cursor.to_list(length=len(characters))
            
            # Map results back to character indices
            for i, char in enumerate(characters):
                char_id = char.get("id")
                char_name = char.get("name", "").lower()
                
                for result in results:
                    owned_char = result.get("inventory", {})
                    if (owned_char.get("id") == char_id or 
                        owned_char.get("name", "").lower() == char_name):
                        
                        user_id = result.get("user_id")
                        try:
                            member = guild.get_member(int(user_id))
                            if member:
                                ownership[i] = {
                                    "user_id": user_id,
                                    "username": member.display_name,
                                    "avatar_url": member.display_avatar.url if member.display_avatar else None
                                }
                                break
                        except:
                            pass
                       
        except Exception as e:
            logger.debug(f"Error checking ownership: {e}")
       
        return ownership
    
    @commands.group(name="game", aliases=["games"], invoke_without_command=True)
    async def game(self, ctx):
        """🎮 Play mini-games to win stella points!"""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Get user character for bonus display
        character = await self.get_user_character(user_id, guild_id)
        balance = await self.quest_data.get_balance(user_id, guild_id)
        
        embed = discord.Embed(
            title="🎮 Anya's Game Corner",
            description=f"*Waku waku!* Play games to win stella points!\n\n"
                        f"💰 **Balance:** {balance:,} stella points",
            color=discord.Color.from_rgb(255, 182, 193)
        )
        
        if character:
            embed.description += f"\n🌟 **Character:** {character}"
        
        # Gambling Games
        embed.add_field(
            name="🎰 **GAMBLING**",
            value=f"`{ctx.prefix}slots <bet>` - Slot Machine\n"
                  f"`{ctx.prefix}coinflip <bet> <h/t>` - Flip a Coin\n"
                  f"`{ctx.prefix}guess <bet>` - Number Guess",
            inline=False
        )
        
        # Card Games
        embed.add_field(
            name="🃏 **CARD DRAWS**",
            value=f"`{ctx.prefix}game pokemon` - 100 pts\n"
                  f"`{ctx.prefix}game anime` - 100 pts",
            inline=True
        )
        
        # Classic Games
        embed.add_field(
            name="**CLASSIC**",
            value=f"`{ctx.prefix}hangman` - Word Game\n"
                  f"`{ctx.prefix}wordle` - 5-Letter Puzzle",
            inline=True
        )
        
        embed.add_field(name="\u200b", value="\u200b", inline=True)
        
        # Grounded/Economy Games
        embed.add_field(
            name="💼 **GROUNDED** (Spy x Family)",
            value=f"`{ctx.prefix}work` - Earn points\n"
                  f"`{ctx.prefix}job` - Risky mission\n"
                  f"`{ctx.prefix}rob @user` - Steal points\n"
                  f"`{ctx.prefix}claim` - Daily reward",
            inline=False
        )
        
        embed.set_footer(text="💡 Get a character from .shop for bonuses!")
        await ctx.reply(embed=embed, mention_author=False)
    
    # ═══════════════════════════════════════════════════════════════
    # GAMBLING GAMES (slots command moved to gamble.py cog)
    # ═══════════════════════════════════════════════════════════════
    
    def _generate_slot_gif(self, results: list) -> io.BytesIO:
        """Generate hyper-realistic slot machine GIF with physics-based animation"""
        import math
        
        frames = []
        durations = []
        all_symbols = list(SLOT_SYMBOLS.keys())
        num_symbols = len(all_symbols)
        
        # Determine result type for outline colors
        is_jackpot = results[0] == results[1] == results[2]
        is_two_match = (results[0] == results[1] or results[1] == results[2] or results[0] == results[2]) and not is_jackpot
        
        # Dimensions
        width, height = 360, 140
        reel_width = 80
        reel_height = 90
        symbol_height = 45  # Height per symbol in the reel strip
        reel_y = 25
        reel_positions = [40, 140, 240]
        
        # Colors
        bg_dark = (15, 12, 20)
        frame_gold = (200, 170, 60)
        frame_shadow = (90, 75, 35)
        reel_bg = (5, 5, 10)
        
        # Result colors
        if is_jackpot:
            result_color = (255, 215, 0)
            result_glow = (255, 255, 120)
        elif is_two_match:
            result_color = (50, 220, 50)
            result_glow = (120, 255, 120)
        else:
            result_color = (200, 50, 50)
            result_glow = (255, 100, 100)
        
        # Load font with emoji support
        try:
            font = _load_emoji_font(28)
        except:
            font = ImageFont.load_default()
        
        # Physics: each reel has its own spin state
        # Reel positions are in "symbol units" (0 = first symbol at center)
        # We'll track continuous position and velocity for each reel
        
        # Find the index of each result symbol
        result_indices = []
        for r in results:
            result_indices.append(all_symbols.index(r))
        
        # Animation parameters - smoother physics
        initial_velocity = 18.0  # symbols per second at start
        
        # Each reel stops at different times
        reel_stop_times = [1.6, 2.6, 3.8]  # seconds
        
        # Higher fps for smoother animation
        fps = 30
        total_duration = 5.0  # seconds
        total_frames = int(total_duration * fps)
        
        # Initialize reel states - track target position for smooth landing
        reel_positions_anim = [0.0, 0.0, 0.0]  # Current position in symbol units
        reel_velocities = [initial_velocity, initial_velocity, initial_velocity]
        reel_stopped = [False, False, False]
        reel_landing = [False, False, False]  # True when easing into final position
        
        for frame_idx in range(total_frames):
            current_time = frame_idx / fps
            
            img = Image.new('RGB', (width, height), bg_dark)
            draw = ImageDraw.Draw(img)
            
            # Draw machine frame with 3D effect
            # Outer shadow
            draw.rounded_rectangle([3, 3, width-1, height-1], radius=15, fill=frame_shadow)
            # Main frame
            draw.rounded_rectangle([0, 0, width-4, height-4], radius=15, fill=bg_dark, outline=frame_gold, width=4)
            # Inner highlight
            draw.rounded_rectangle([8, 8, width-12, height-12], radius=12, outline=(40, 35, 50), width=1)
            
            # Update physics for each reel
            for reel_idx in range(3):
                stop_time = reel_stop_times[reel_idx]
                target_pos = result_indices[reel_idx]
                
                if reel_stopped[reel_idx]:
                    # Already stopped - stay at target
                    reel_positions_anim[reel_idx] = target_pos
                    reel_velocities[reel_idx] = 0
                elif current_time >= stop_time - 0.4 and not reel_landing[reel_idx]:
                    # Start landing phase - smooth ease to target
                    reel_landing[reel_idx] = True
                
                if reel_landing[reel_idx] and not reel_stopped[reel_idx]:
                    # Smooth interpolation to target position
                    landing_progress = (current_time - (stop_time - 0.4)) / 0.4
                    landing_progress = min(1.0, max(0.0, landing_progress))
                    
                    # Smooth step function (ease in-out)
                    smooth = landing_progress * landing_progress * (3 - 2 * landing_progress)
                    
                    # Get current spinning position
                    spin_pos = reel_positions_anim[reel_idx]
                    
                    # Interpolate toward target
                    # Make sure we approach from the right direction (wrapping)
                    diff = target_pos - (spin_pos % num_symbols)
                    if diff < -num_symbols / 2:
                        diff += num_symbols
                    elif diff > num_symbols / 2:
                        diff -= num_symbols
                    
                    reel_positions_anim[reel_idx] = spin_pos + diff * smooth * 0.15
                    reel_velocities[reel_idx] = initial_velocity * (1 - smooth) * 0.3
                    
                    if landing_progress >= 1.0:
                        reel_stopped[reel_idx] = True
                        reel_positions_anim[reel_idx] = target_pos
                        reel_velocities[reel_idx] = 0
                        
                elif not reel_landing[reel_idx]:
                    # Normal spinning with gradual slowdown
                    time_to_landing = (stop_time - 0.4) - current_time
                    if time_to_landing < 0.8:
                        # Gradual slowdown before landing
                        ease = time_to_landing / 0.8
                        ease = 0.4 + ease * 0.6  # Never go below 40% speed
                        current_vel = initial_velocity * ease
                    else:
                        current_vel = initial_velocity
                    
                    reel_velocities[reel_idx] = current_vel
                    reel_positions_anim[reel_idx] += current_vel / fps
                    
                    # Wrap position
                    reel_positions_anim[reel_idx] = reel_positions_anim[reel_idx] % num_symbols
            
            # Draw each reel
            for reel_idx, x in enumerate(reel_positions):
                # Reel background with depth
                draw.rounded_rectangle([x-3, reel_y-3, x + reel_width+3, reel_y + reel_height+3], 
                                       radius=8, fill=(3, 3, 6))
                draw.rounded_rectangle([x, reel_y, x + reel_width, reel_y + reel_height], 
                                       radius=6, fill=reel_bg)
                
                # Create a clipping region for the reel
                reel_center_y = reel_y + reel_height // 2
                
                # Get current position
                pos = reel_positions_anim[reel_idx]
                is_stopped = reel_stopped[reel_idx]
                velocity = reel_velocities[reel_idx]
                
                # Draw 3 symbols: above, center, below
                for offset in [-1, 0, 1]:
                    symbol_idx = int(pos + offset) % num_symbols
                    symbol = all_symbols[symbol_idx]
                    
                    # Calculate y position based on fractional position
                    frac = pos - int(pos)
                    symbol_y = reel_center_y + (offset - frac) * symbol_height
                    
                    # Only draw if visible in reel window
                    if reel_y - symbol_height < symbol_y < reel_y + reel_height + symbol_height:
                        symbol_color = SLOT_SYMBOL_COLORS.get(symbol, (255, 255, 255))
                        
                        # Motion blur effect when spinning fast
                        if velocity > 5 and not is_stopped:
                            # Fade based on speed
                            fade = max(0.3, 1.0 - (velocity / initial_velocity) * 0.6)
                            symbol_color = tuple(int(c * fade) for c in symbol_color)
                        
                        # Center symbol in reel
                        bbox = draw.textbbox((0, 0), symbol, font=font)
                        text_w = bbox[2] - bbox[0]
                        text_x = x + (reel_width - text_w) // 2
                        text_y = int(symbol_y - symbol_height // 2 + 5)
                        
                        # Only draw center symbol with full opacity, others faded
                        if offset == 0 and is_stopped:
                            # Glow effect for stopped center symbol
                            glow = tuple(min(255, int(c * 0.4)) for c in symbol_color)
                            for glow_offset in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                                draw.text((text_x + glow_offset[0], text_y + glow_offset[1]), 
                                         symbol, font=font, fill=glow)
                        
                        draw.text((text_x, text_y), symbol, font=font, fill=symbol_color)
                
                # Reel window overlay - gradient fade at top and bottom
                for i in range(12):
                    alpha = int((12 - i) / 12 * 200)
                    fade_color = (bg_dark[0], bg_dark[1], bg_dark[2])
                    # Top fade
                    draw.line([(x, reel_y + i), (x + reel_width, reel_y + i)], 
                             fill=tuple(int(c * (1 - i/12)) for c in fade_color), width=1)
                    # Bottom fade
                    draw.line([(x, reel_y + reel_height - i), (x + reel_width, reel_y + reel_height - i)], 
                             fill=tuple(int(c * (1 - i/12)) for c in fade_color), width=1)
                
                # Result highlight when stopped
                if is_stopped:
                    draw.rounded_rectangle([x-1, reel_y-1, x + reel_width+1, reel_y + reel_height+1], 
                                           radius=7, outline=result_color, width=2)
            
            # Center payline indicator
            line_y = reel_y + reel_height // 2
            # Left arrow
            draw.polygon([(32, line_y), (18, line_y - 10), (18, line_y + 10)], fill=frame_gold)
            # Right arrow
            draw.polygon([(width - 32, line_y), (width - 18, line_y - 10), (width - 18, line_y + 10)], fill=frame_gold)
            # Payline
            draw.line([(35, line_y), (width - 35, line_y)], fill=(frame_gold[0]//3, frame_gold[1]//3, frame_gold[2]//3), width=1)
            
            frames.append(img)
            
            # Consistent frame timing for smooth playback (33ms = ~30fps)
            durations.append(33)
        
        # Add final hold frames to show result
        for _ in range(12):
            frames.append(frames[-1])
            durations.append(120)
        
        # Save GIF
        gif_buffer = io.BytesIO()
        frames[0].save(
            gif_buffer,
            format='GIF',
            save_all=True,
            append_images=frames[1:],
            duration=durations,
            loop=0  # Loop forever so user can watch again
        )
        gif_buffer.seek(0)
        return gif_buffer
    
    async def _run_slot_machine(self, channel, user, bet: int):
        """Run the slot machine game with anticipation-building progressive reveals"""
        guild_id = str(channel.guild.id)
        user_id = str(user.id)
        
        # Get balance before deducting
        balance = await self.quest_data.get_balance(user_id, guild_id)
        
        # Deduct bet
        await self.quest_data.add_balance(user_id, guild_id, -bet)
        
        # Pre-generate final results
        results = [self.get_slot_symbol() for _ in range(3)]
        
        # Generate the GIF in background while spinning
        gif_task = asyncio.get_event_loop().run_in_executor(
            None, self._generate_slot_gif, results
        )
        
        # Simple spinning message
        spin_embed = discord.Embed(
            title="🎰 Slot Machine",
            description=f"**{user.display_name}** is spinning...\n💰 Bet: **{bet:,}** pts",
            color=discord.Color.blue()
        )
        spin_msg = await channel.send(embed=spin_embed)
        
        # Wait for gif to be ready
        gif_buffer = await gif_task
        
        # Determine outcome
        winnings = 0
        if results[0] == results[1] == results[2]:
            # JACKPOT!
            multiplier = SLOT_SYMBOLS[results[0]]["multiplier"]
            winnings = bet * multiplier
            final_title = "🎰 Jackpot!"
            final_color = discord.Color.gold()
        elif results[0] == results[1] or results[1] == results[2] or results[0] == results[2]:
            # Two match
            winnings = int(bet * 1.5)
            final_title = "🎰 Double Match!"
            final_color = discord.Color.green()
        else:
            final_title = "🎰 No Match"
            final_color = discord.Color.red()
        
        if winnings > 0:
            await self.quest_data.add_balance(user_id, guild_id, winnings)
        
        new_balance = balance - bet + winnings
        
        # Create clean final embed with GIF
        final_embed = discord.Embed(
            title=final_title,
            #description=f"{results[0]} {results[1]} {results[2]}",
            color=final_color
        )
        
        if winnings > 0:
            final_embed.add_field(name="Won", value=f"+{winnings:,} pts", inline=True)
        else:
            final_embed.add_field(name="Lost", value=f"{abs(winnings):,} pts", inline=True)
        
        final_embed.add_field(name="Balance", value=f"{new_balance:,} pts", inline=True)
        final_embed.set_image(url="attachment://slots.gif")
        
        file = discord.File(gif_buffer, filename="slots.gif")
        await spin_msg.edit(embed=final_embed, attachments=[file])
    
    def parse_bet(self, bet_str: str) -> int:
        """Parse a bet string that may contain commas (e.g., '5,000' -> 5000)."""
        if bet_str is None:
            return 50
        # Remove commas and convert to int
        cleaned = str(bet_str).replace(",", "").replace(" ", "")
        return int(cleaned)
    
    # coinflip and guess commands moved to gamble.py cog

    # ═══════════════════════════════════════════════════════════════
    # CARD DRAW GAMES (kept from original)
    # ═══════════════════════════════════════════════════════════════

    @game.command(name="pokemon", aliases=["poke", "pkm"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def pokemon_draw(self, ctx):
        """Draw a random Pokémon card for 100 points."""
        """🃏 Draw a random Pokémon card for 100 points."""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        cost = 500
        
        # Check timer (cooldown + daily limit)
        timer_error = await self.check_timer(ctx, "pokemon")
        if timer_error:
            embed = discord.Embed(
                title="⏰ Daily Limit Reached!",
                description=timer_error,
                color=discord.Color.orange()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        # Check balance
        balance = await self.quest_data.get_balance(user_id, guild_id)
        if balance < cost:
            embed = discord.Embed(
                title="❌ Not Enough Points!",
                description=f"You need **{cost}** stella points but only have **{balance:,}**.\n"
                           f"Complete quests to earn more!",
                color=discord.Color.red()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        # Set command cooldown, deduct cost and increment plays
        await self.set_cooldown(user_id, "pokemon_command")
        await self.quest_data.add_balance(user_id, guild_id, -cost)
        await self.increment_plays(user_id, guild_id, "pokemon")
        
        # Random rarity (gacha-style)
        rarity = self.get_random_rarity()
        rarity_data = RARITY_CONFIG[rarity]
        reward = cost * rarity_data["multiplier"]
        
        # Fetch Pokemon info
        pokemon_id = random.randint(1, 1025)
        pokemon = await self.fetch_pokemon_info(pokemon_id)
        
        # Add reward
        await self.quest_data.add_balance(user_id, guild_id, reward)
        new_balance = balance - cost + reward
        profit = reward - cost
        
        # Generate card image
        if pokemon:
            types_str = " / ".join(pokemon["types"])
            card_buffer = await generate_card_image(
                name=pokemon["name"],
                subtitle=types_str,
                rarity=rarity,
                sprite_url=pokemon["sprite"],
                multiplier=rarity_data["multiplier"],
                card_type="pokemon"
            )
        else:
            card_buffer = await generate_card_image(
                name=f"Mystery #{pokemon_id}",
                subtitle="Unknown Type",
                rarity=rarity,
                multiplier=rarity_data["multiplier"],
                card_type="pokemon"
            )
        
        file = discord.File(card_buffer, filename="pokemon_card.png")
        
        embed = discord.Embed(
            title="🃏 Pokémon Card Draw",
            color=rarity_data["color"]
        )
        embed.set_image(url="attachment://pokemon_card.png")
        
        result_name = "💰 Won" if profit > 0 else "📉 Result"
        embed.add_field(name=result_name, value=f"**{profit:+,}** pts", inline=True)
        embed.add_field(name="💳 Balance", value=f"**{new_balance:,}** pts", inline=True)
        
        await ctx.reply(embed=embed, file=file, mention_author=False)
    
    # ═══════════════════════════════════════════════════════════════
    # ANIME GACHA - DRAW COMMANDS (Group)
    # ═══════════════════════════════════════════════════════════════
    
    @commands.group(name="draw", aliases=["d"], invoke_without_command=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw(self, ctx):
        """🎴 Draw anime characters! Use `.draw` to pull or `.draw help` for info."""
        await self._execute_draw(ctx, gender_filter=None)
    
    @draw.command(name="waifu", aliases=["w", "female", "girl"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw_waifu(self, ctx):
        """🎴 Draw only female characters (waifus)."""
        await self._execute_draw(ctx, gender_filter="Female")
    
    @draw.command(name="husbando", aliases=["h", "male", "boy"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw_husbando(self, ctx):
        """🎴 Draw only male characters (husbandos)."""
        await self._execute_draw(ctx, gender_filter="Male")


    async def update_character_rarities_in_db(self, user_id: str, guild_id: str, inventory: list) -> list:
        """Update character rarities in database with corrected values and return updated inventory."""
        
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            updated_chars = []
            needs_update = False
            
            # Check each character for rarity updates
            for char in inventory:
                old_rarity = char.get("rarity", "common")
                favorites = char.get("favorites", 0)
                new_rarity = get_rarity_from_favorites(favorites)
                
                if old_rarity != new_rarity:
                    # Update character rarity
                    char["rarity"] = new_rarity
                    updated_chars.append(char)
                    needs_update = True
                else:
                    updated_chars.append(char)
            
            # Update database if any rarities changed
            if needs_update:
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$set": {f"members.{user_id}.gacha_inventory": updated_chars}},
                    upsert=True
                )
                logger.info(f"Updated rarities for {len(updated_chars)} characters in user {user_id}'s collection")
            
            return updated_chars
        except Exception as e:
            print(e)
            
    @draw.command(name="gallery", aliases=["g", "grid"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def draw_gallery(self, ctx, page_or_filter: str = None, *, filter_args: str = None):
        """🖼️ View your card collection as a beautiful gallery image.
        
        Usage:
        - `.draw gallery` - Show all cards (page 1) in grid view
        - `.draw gallery tree` - Show anime hierarchy tree view
        - `.draw gallery 2` - Show page 2 in grid view
        - `.draw gallery waifu` - Show only female characters
        - `.draw gallery husbando` - Show only male characters
        - `.draw gallery legendary` - Show only legendary cards
        - `.draw gallery epic` - Show only epic cards
        - `.draw gallery rare` - Show only rare cards
        - `.draw gallery uncommon` - Show only uncommon cards
        - `.draw gallery common` - Show only common cards
        - `.draw gallery "search term"` - Search for characters by name/anime
        """
        user_id = str(ctx.author.id)
        guild_id = str(ctx.guild.id)
        
        # Parse first argument - could be page number or filter
        page = 1
        filter_type = "all"
        search_query = None
        use_tree_view = False
        
        if page_or_filter:
            # Try to parse as integer (page number)
            try:
                page = int(page_or_filter)
            except ValueError:
                # Not a number, treat as filter
                filter_args = page_or_filter if not filter_args else f"{page_or_filter} {filter_args}"
        
        if filter_args:
            filter_args_lower = filter_args.lower().strip()
            
            # Check for tree view
            if filter_args_lower == "tree":
                use_tree_view = True
            # Check for gender filters
            elif filter_args_lower in ["waifu", "female", "girl"]:
                filter_type = "waifu"
            elif filter_args_lower in ["husbando", "male", "boy"]:
                filter_type = "husbando"
            # Check for rarity filters
            elif filter_args_lower in ["legendary", "epic", "rare", "uncommon", "common"]:
                filter_type = filter_args_lower
            else:
                # Treat as search query
                search_query = filter_args
                filter_type = "search"
        
        # Get user's inventory
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_inventory": 1}
            )
            
            if not result or not result.get("members", {}).get(user_id, {}).get("gacha_inventory"):
                await ctx.reply("❌ You don't have any cards in your collection! Use `.draw` to get some.", mention_author=False)
                return
            
            inventory = result["members"][user_id]["gacha_inventory"]
            
            # Apply filters
            filtered_inventory = []
            
            for char in inventory:
                # Gender filter
                if filter_type == "waifu" and char.get("gender", "").lower() not in ["female", "girl"]:
                    continue
                elif filter_type == "husbando" and char.get("gender", "").lower() not in ["male", "boy"]:
                    continue
                # Rarity filter
                elif filter_type in ["legendary", "epic", "rare", "uncommon", "common"]:
                    if char.get("rarity", "").lower() != filter_type:
                        continue
                # Search filter
                elif filter_type == "search" and search_query:
                    name_match = search_query.lower() in char.get("name", "").lower()
                    anime_match = search_query.lower() in char.get("anime", "").lower()
                    if not (name_match or anime_match):
                        continue
                
                filtered_inventory.append(char)
            
            if not filtered_inventory:
                filter_desc = f"matching '{search_query}'" if search_query else filter_type
                await ctx.reply(f"❌ No cards found with filter: {filter_desc}", mention_author=False)
                return
            
            # Sort by rarity (legendary first) then by favorites/likes (descending)
            rarity_order = {"legendary": 0, "epic": 1, "rare": 2, "uncommon": 3, "common": 4}
            
            def sort_key(char):
                # Case-insensitive rarity comparison
                rarity = char.get("rarity", "common").lower()
                rarity_score = rarity_order.get(rarity, 5)
                # Sort by favorites in descending order (negative for highest first)
                favorites = -char.get("favorites", 0)
                return (rarity_score, favorites)
            
            sorted_inventory = sorted(filtered_inventory, key=sort_key)
            
            # Pagination settings
            cards_per_page = 10  # 8 cards per row * 2 rows
            total_cards = len(sorted_inventory)
            total_pages = (total_cards + cards_per_page - 1) // cards_per_page
            
            # Validate page number
            if page < 1:
                page = 1
            elif page > total_pages:
                page = total_pages
            
            # Get user avatar
            avatar_bytes = None
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(ctx.author.display_avatar.url) as resp:
                        if resp.status == 200:
                            avatar_bytes = await resp.read()
            except:
                pass
            
            # Check if tree view requested
            if use_tree_view:
                # Create paginated anime tree view
                from bot.utils.cogs.game.anime_tree_view import create_anime_tree_view
                
                async with ctx.typing():
                    await create_anime_tree_view(self, ctx, sorted_inventory)
            else:
                # Generate regular grid gallery image
                buffer = await generate_gallery_image(
                    characters=sorted_inventory,
                    page=page,
                    cards_per_page=cards_per_page,
                    user_name=ctx.author.display_name,
                    user_avatar_bytes=avatar_bytes,
                    filter_type=filter_type,
                    search_query=search_query
                )
                
                # Create file
                file = discord.File(buffer, filename=f"gallery_{user_id}_page_{page}.png")
                
                # Create interactive view with pagination and filters
                view = GalleryView(
                    cog=self,
                    user=ctx.author,
                    guild_id=guild_id,
                    characters=sorted_inventory,
                    page=page,
                    filter_type=filter_type,
                    search_query=search_query
                )
                
                # Send with view
                await ctx.reply(file=file, view=view, mention_author=False)
            
        except Exception as e:
            import traceback
            error_details = f"Error in draw gallery: {e}\n\nTraceback:\n{traceback.format_exc()}"
            logger.error(error_details)
            
            # Send detailed error to user for debugging
            await ctx.reply(f"❌ **Error generating gallery image:** `{e}`\n\nPlease try again. If this persists, check the bot logs for full details.", mention_author=False)

    @draw.command(name="collection", aliases=["c", "inv", "inventory"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw_collection(self, ctx, *, args: str = None):
        """📦 View your anime character collection.
        
        Usage:
        - `.draw c` - View all characters
        - `.draw c --n miku` - Search for characters named "miku" or from series with "miku"
        - `.draw c --n re zero` - Search for characters from "Re Zero"
        - `.draw c --n Kono Subarashii Sekai ni Shukufuku wo!` - Search by full series name
        - `.draw c @user` - View another user's collection
        - `.draw c @user --n miku` - Search in another user's collection
        """
        member = None
        search_query = None
        
        if args:
            # Parse member and search query
            parts = args.split()
            member_mention = None
            
            # Check if first argument is a member mention
            if parts and parts[0].startswith('<@') and parts[0].endswith('>'):
                try:
                    member_id = int(parts[0].strip('<@!>'))
                    member = ctx.guild.get_member(member_id)
                    if member:
                        member_mention = parts[0]
                        args = ' '.join(parts[1:]).strip() if len(parts) > 1 else None
                except (ValueError, AttributeError):
                    pass
            
            # Parse search query
            if args and args.strip().startswith("--n"):
                search_query = args.strip()[3:].strip()  # Remove "--n " prefix
            elif args and args.strip().startswith("-n"):
                search_query = args.strip()[2:].strip()  # Remove "-n " prefix
        
        target = member or ctx.author
        guild_id = str(ctx.guild.id)
        user_id = str(target.id)
        
        inventory = await self.get_user_inventory(user_id, guild_id)
        
        if not inventory:
            if target == ctx.author:
                embed = discord.Embed(
                    title="📦 Empty Collection",
                    description=f"You haven't collected any characters yet!\nUse `{ctx.prefix}draw` to start collecting.",
                    color=discord.Color.greyple()
                )
            else:
                embed = discord.Embed(
                    title="📦 Empty Collection",
                    description=f"**{target.display_name}** hasn't collected any characters yet!",
                    color=discord.Color.greyple()
                )
            return await ctx.reply(embed=embed, mention_author=False)
        
        # Update rarities in database and get updated inventory
        updated_inventory = await self.update_character_rarities_in_db(user_id, guild_id, inventory)
        
        view = InventoryView(self, target, guild_id, updated_inventory, filter_type="all", search_query=search_query)
        await ctx.reply(embed=await view.get_embed(), view=view, mention_author=False)
    
    @draw.command(name="info", aliases=["help", "rates", "?"])
    async def draw_info(self, ctx):
        """📊 Show gacha rates and command help."""
        
        embed = discord.Embed(
            title="🎴 Anime Gacha - Draw Info",
            description="Collect anime characters! **Extremely rare** drops - like hunting shiny Pokemon.\nNo pity system. Pure RNG grinding.",
            color=discord.Color.gold()
        )
        
        # Commands
        embed.add_field(
            name="Commands",
            value=(
                f"`{ctx.prefix}draw` - Draw 3 random characters\n"
                f"`{ctx.prefix}draw waifu` - Draw female only\n"
                f"`{ctx.prefix}draw husbando` - Draw male only\n"
                f"`{ctx.prefix}draw gallery` - 🖼️ View collection as image\n"
                f"`{ctx.prefix}draw gallery waifu` - Gallery of female only\n"
                f"`{ctx.prefix}draw gallery legendary` - Gallery by rarity\n"
                f"`{ctx.prefix}draw collection` - View your collection\n"
                f"`{ctx.prefix}draw favorite <UID>` - ⭐ Favorite/unfavorite a character\n"
                f"`{ctx.prefix}draw unfavorite <UID>` - ☆ Unfavorite a character\n"
                f"`{ctx.prefix}draw view <UID>` - Show off a character\n"
                f"`{ctx.prefix}draw release <UID>` - Sell for pts\n"
                f"`{ctx.prefix}draw trade @user <UID>` - Trade"
            ),
            inline=False
        )
        
        # Rates - brutal
        embed.add_field(
            name="⭐ Drop Rates (Brutal)",
            value=get_gacha_rates_display(),
            inline=True
        )
        
        # Rarity explanation
        embed.add_field(
            name="📊 Character Rarity",
            value=(
                "Based on ❤️ favorites:\n"
                "🌟 10,000+ = 5★\n"
                "🟣 5,000+ = 4★\n"
                "🔵 1,000+ = 3★\n"
                "🟢 100+ = 2★\n"
                "⚪ <100 = 1★"
            ),
            inline=True
        )
        
        # Cost info
        gacha_config = get_timer_config("gacha")
        cooldown_minutes = gacha_config['cooldown'] // 60
        embed.add_field(
            name="💰 Cost & Limits",
            value=f"**{GACHA_COST}** pts per draw\n**{gacha_config['max_uses']}** draws, then {cooldown_minutes} min cooldown",
            inline=False
        )
        
        embed.set_footer(text="Getting a Legendary is like finding a shiny Arceus 🌟")
        await ctx.reply(embed=embed, mention_author=False)
    
    @draw.command(name="view", aliases=["show", "display", "v"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def draw_view(self, ctx, uid: str = None):
        """👁️ View and show off a character by UID.
        
        Usage:
        - `.draw v <UID>` - View by UID
        - `.draw v latest` or `.draw v l` - View your last claimed character
        """
        if not uid:
            return await ctx.reply(f"Usage: `{ctx.prefix}draw view <UID>`\nOr use `latest`/`l` for last claimed!", mention_author=False)
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Handle 'latest' or 'l' shortcut
        if uid.lower() in ['latest', 'l']:
            try:
                db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
                server_col = db["Servers"]
                result = await server_col.find_one(
                    {"guild_id": guild_id},
                    {f"members.{user_id}.gacha_inventory": 1}
                )
                
                if not result:
                    return await ctx.reply("❌ You don't have any characters yet!", mention_author=False)
                
                inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
                if not inventory:
                    return await ctx.reply("❌ You don't have any characters yet!", mention_author=False)
                
                # Get the most recently claimed character (last in inventory)
                latest_char = inventory[-1]
                uid = latest_char.get("uid")
                
                if not uid:
                    return await ctx.reply("❌ Could not find your latest character!", mention_author=False)
            except Exception as e:
                logger.error(f"Error getting latest character: {e}")
                return await ctx.reply("❌ Error finding your latest character!", mention_author=False)
        
        owner_id, char = await self.get_character_by_uid(guild_id, uid)
        
        if not char:
            return await ctx.reply(f"❌ No character found with UID `{uid.upper()}`", mention_author=False)
        
        # Get owner info
        try:
            owner = ctx.guild.get_member(int(owner_id))
            owner_name = owner.display_name if owner else "Unknown"
            owner_avatar = owner.display_avatar.url if owner else None
        except:
            owner_name = "Unknown"
            owner_avatar = None
        
        rarity = char.get("rarity", "common")
        rarity_data = GACHA_RARITY_TIERS.get(rarity, GACHA_RARITY_TIERS["common"])
        favorites = char.get("favorites", 0)
        
        # Calculate cover unlock progress (based on favorites)
        cover_unlocked = char.get("cover_unlocked", False)
        cover_progress = char.get("cover_progress", 0)
        unlock_threshold = max(100, favorites // 10)  # Need 10% of favorites as interactions
        
        embed = discord.Embed(
            #title=f"", # {rarity_data['stars']}
            description=f"```           {char['name']}```",
            color=rarity_data["color"]
        )
        
        # Character details in a clean format
        details = f"Series: {char.get('anime', 'Unknown')}\n"
        details += f"Gender: {char.get('gender', 'Unknown')}\n"
        details += f"Rarity: {rarity.title()}\n"
        details += f"Favorites: {favorites:,}\n"
        details += f"**UID:** `{char.get('uid', uid).upper()}`"
        
        embed.add_field(name="Character Details", value=details, inline=False)
        
        # Cover art status
        if cover_unlocked:
            embed.add_field(name="Cover Art", value="Unlocked", inline=True)
        
        # Set character image - use active cover art if set, otherwise default image
        active_cover_url = await self.cover_art_system.get_active_cover_art_url(owner_id, guild_id, char.get('uid', uid))
        if active_cover_url:
            embed.set_image(url=active_cover_url)
        elif char.get("image_url"):
            embed.set_image(url=char["image_url"])
        
        release_value = calculate_release_value(favorites, rarity, char.get('name', 'unknown'))
        embed.set_footer(icon_url=ctx.author.avatar,text=f"Owned by {owner_name} • Release value: {release_value} pts")
        
        # Check if there are other characters from the same anime
        anime_name = char.get('anime', '')
        view = None
        
        if anime_name:
            # Get other characters from the same anime (excluding current character)
            same_anime_chars = await self.get_characters_from_same_anime(guild_id, anime_name, exclude_uid=uid)
            
            if same_anime_chars:
                # Populate owner names for the dropdown options
                for other_char in same_anime_chars:
                    try:
                        other_owner_id = other_char.get("owner_id")
                        other_owner = ctx.guild.get_member(int(other_owner_id))
                        other_char["display_owner_name"] = other_owner.display_name if other_owner else "Unknown"
                    except:
                        other_char["display_owner_name"] = "Unknown"
        
        # Create the main character view with favorite and selection options
        view = CharacterView(self, char, uid, ctx.author.id, guild_id, same_anime_chars if anime_name else None)
        
        # Send with view
        await ctx.reply(embed=embed, view=view, mention_author=False)

    @draw.command(name="release", aliases=["sell", "remove"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw_release(self, ctx, uid: str = None):
        """💸 Release a character for stella points."""
        if not uid:
            return await ctx.reply(f"Usage: `{ctx.prefix}draw release <UID>`\nFind UIDs in your collection!", mention_author=False)
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Check ownership
        owner_id, char = await self.get_character_by_uid(guild_id, uid)
        
        if not char:
            return await ctx.reply(f"❌ No character found with UID `{uid.upper()}`", mention_author=False)
        
        if owner_id != user_id:
            return await ctx.reply("❌ You don't own this character!", mention_author=False)
        
        # Calculate release value
        favorites = char.get("favorites", 0)
        rarity = char.get("rarity", "common")
        release_value = calculate_release_value(favorites, rarity, char.get('name', 'unknown'))
        
        # Remove from inventory
        removed = await self.remove_character_from_inventory(user_id, guild_id, uid)
        
        if not removed:
            return await ctx.reply("❌ Failed to release character.", mention_author=False)
        
        # Add stella points
        await self.quest_data.add_balance(user_id, guild_id, release_value)
        new_balance = await self.quest_data.get_balance(user_id, guild_id)
        
        rarity_data = GACHA_RARITY_TIERS.get(rarity, GACHA_RARITY_TIERS["common"])
        
        embed = discord.Embed(
            title=f"💸 Released {char['name']}",
            description=f"*{char.get('anime', 'Unknown')}*\n\n"
                       f"**Received:** +{release_value:,} pts\n"
                       f"**New Balance:** {new_balance:,} pts",
            color=rarity_data["color"]
        )
        
        await ctx.reply(embed=embed, mention_author=False)
    
    @draw.command(name="trade", aliases=["give", "transfer"])
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def draw_trade(self, ctx, member: discord.Member = None, uid: str = None):
        """🔄 Trade a character to another user."""
        if not member or not uid:
            return await ctx.reply(f"Usage: `{ctx.prefix}draw trade @user <UID>`", mention_author=False)
        
        if member.id == ctx.author.id:
            return await ctx.reply("❌ You can't trade with yourself!", mention_author=False)
        
        if member.bot:
            return await ctx.reply("❌ You can't trade with bots!", mention_author=False)
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        target_id = str(member.id)
        
        # Check ownership
        owner_id, char = await self.get_character_by_uid(guild_id, uid)
        
        if not char:
            return await ctx.reply(f"❌ No character found with UID `{uid.upper()}`", mention_author=False)
        
        if owner_id != user_id:
            return await ctx.reply("❌ You don't own this character!", mention_author=False)
        
        # Check if target already owns this character (by name)
        is_owned, existing_owner = await self.is_character_owned_in_server(
            guild_id, char.get("name"), char.get("id")
        )
        
        # Remove from sender
        removed = await self.remove_character_from_inventory(user_id, guild_id, uid)
        if not removed:
            return await ctx.reply("❌ Failed to transfer character.", mention_author=False)
        
        # Add to receiver with new UID
        new_uid = await self.add_character_to_inventory(target_id, guild_id, char)
        
        rarity_data = GACHA_RARITY_TIERS.get(char.get("rarity", "common"))
        
        embed = discord.Embed(
            title=f"🔄 Trade Complete!",
            description=f"**{char['name']}** transferred to **{member.display_name}**\n\n"
                       f"**New UID:** `{new_uid}`",
            color=rarity_data["color"]
        )
        
        if char.get("image_url"):
            embed.set_thumbnail(url=char["image_url"])
        
        await ctx.reply(embed=embed, mention_author=False)
    
    @draw.command(name="favorite", aliases=["fav", "f"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def draw_favorite(self, ctx, *uids: str):
     """⭐ Favorite characters by UIDs.
  
     Usage: 
     - `.draw f <UID1> <UID2> ...` - Favorite by UIDs
     - `.draw f latest` or `.draw f l` - Favorite your last claimed character
     """
     if not uids:
        return await ctx.reply(f"Usage: `{ctx.prefix}draw favorite <UID> [UID2 ...]`\nOr use `latest`/`l` for last claimed!", mention_author=False)
  
     guild_id = str(ctx.guild.id)
     user_id = str(ctx.author.id)
     
     # Handle 'latest' or 'l' shortcut
     if len(uids) == 1 and uids[0].lower() in ['latest', 'l']:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_inventory": 1}
            )
            
            if not result:
                return await ctx.reply("❌ You don't have any characters yet!", mention_author=False)
            
            inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
            if not inventory:
                return await ctx.reply("❌ You don't have any characters yet!", mention_author=False)
            
            # Get the most recently claimed character (last in inventory)
            latest_char = inventory[-1]
            latest_uid = latest_char.get("uid")
            
            if not latest_uid:
                return await ctx.reply("❌ Could not find your latest character!", mention_author=False)
            
            # Replace uids with the latest UID
            uids = (latest_uid,)
        except Exception as e:
            logger.error(f"Error getting latest character: {e}")
            return await ctx.reply("❌ Error finding your latest character!", mention_author=False)
  
     guild_id = str(ctx.guild.id)
     user_id = str(ctx.author.id)
  
     success_embeds = []
     failed = []
     updated = False
  
     try:
        db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
        server_col = db["Servers"]
      
        # Get current inventory
        result = await server_col.find_one(
            {"guild_id": guild_id},
            {f"members.{user_id}.gacha_inventory": 1}
        )
      
        if not result:
            return await ctx.reply("❌ Error accessing your collection.", mention_author=False)
      
        inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
        updated_inventory = inventory[:]  # Copy to modify
      
        for uid in uids:
            upper_uid = uid.upper()
          
            # Check ownership and get char
            owner_id, char = await self.get_character_by_uid(guild_id, uid)
          
            if not char:
                failed.append((upper_uid, "No character found"))
                continue
          
            if owner_id != user_id:
                failed.append((upper_uid, "You don't own this"))
                continue
          
            # Find and update in inventory
            char_found = False
          
            for i, character in enumerate(updated_inventory):
                if character.get("uid", "").upper() == upper_uid:
                    char_found = True
                    was_favorited = character.get("favorite", False)
                  
                    if not was_favorited:
                        updated_inventory[i]["favorite"] = True
                        updated = True
                  
                    action = "favorited" if not was_favorited else "already favorited"
                    star = "⭐"
                  
                    # Create embed for this character
                    rarity = char.get("rarity", "common")
                    rarity_data = GACHA_RARITY_TIERS.get(rarity, GACHA_RARITY_TIERS["common"])
                    rarity_emoji = rarity_data["emoji"]
                    
                    embed = discord.Embed(
                        title=f"{char['name']} Favorited!",
                        description=(
                            f"**Series:** {char.get('anime', 'Unknown')}\n"
                            f"**Rarity:** {rarity.title()} {rarity_emoji}\n"
                            f"**UID:** `{upper_uid}`"
                        ),
                        color=rarity_data["color"]
                    )
                    
                    # Add character image
                    if char.get("image_url"):
                        embed.set_thumbnail(url=char["image_url"])
                    
                    # Add footer with stats
                    favorites = char.get("favorites", 0)
                    embed.set_footer(
                        text=f"❤️ {favorites:,} favorites • Added to favorites",
                        icon_url=ctx.author.avatar.url if ctx.author.avatar else None
                    )
                  
                    success_embeds.append(embed)
                    break
          
            if not char_found:
                failed.append((upper_uid, "Not found in collection"))
      
        # Update database if changes were made
        if updated:
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$set": {f"members.{user_id}.gacha_inventory": updated_inventory}},
                upsert=True
            )
      
        # Create failed embed if any
        embeds_to_send = success_embeds[:]
      
        if failed:
            fail_desc = "\n".join(f"❌ `{uid}`: {reason}" for uid, reason in failed)
            failed_embed = discord.Embed(
                title="Favorite Failed",
                description=fail_desc,
                color=0xFF0000
            )
            embeds_to_send.append(failed_embed)
      
        if embeds_to_send:
            await ctx.reply(embeds=embeds_to_send, mention_author=False)
        else:
            await ctx.reply("❌ No valid operations performed.", mention_author=False)
      
     except Exception as e:
        logger.error(f"Error in draw favorite: {e}")
        await ctx.reply("❌ Error updating favorite status. Please try again.", mention_author=False)

    @draw.command(name="unfavorite", aliases=["unfav"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def draw_unfavorite(self, ctx, *uids: str):
     """☆ Unfavorite characters by UIDs.
  
     Usage: 
     - `.draw unfav <UID1> <UID2> ...` - Unfavorite by UIDs
     - `.draw unfav latest` or `.draw unfav l` - Unfavorite your last claimed character
     """
     if not uids:
        return await ctx.reply(f"Usage: `{ctx.prefix}draw unfavorite <UID> [UID2 ...]`\nOr use `latest`/`l` for last claimed!", mention_author=False)
  
     guild_id = str(ctx.guild.id)
     user_id = str(ctx.author.id)
     
     # Handle 'latest' or 'l' shortcut
     if len(uids) == 1 and uids[0].lower() in ['latest', 'l']:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_inventory": 1}
            )
            
            if not result:
                return await ctx.reply("❌ You don't have any characters yet!", mention_author=False)
            
            inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
            if not inventory:
                return await ctx.reply("❌ You don't have any characters yet!", mention_author=False)
            
            # Get the most recently claimed character (last in inventory)
            latest_char = inventory[-1]
            latest_uid = latest_char.get("uid")
            
            if not latest_uid:
                return await ctx.reply("❌ Could not find your latest character!", mention_author=False)
            
            # Replace uids with the latest UID
            uids = (latest_uid,)
        except Exception as e:
            logger.error(f"Error getting latest character: {e}")
            return await ctx.reply("❌ Error finding your latest character!", mention_author=False)
  
     guild_id = str(ctx.guild.id)
     user_id = str(ctx.author.id)
  
     success_embeds = []
     failed = []
     updated = False
  
     try:
        db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
        server_col = db["Servers"]
      
        # Get current inventory
        result = await server_col.find_one(
            {"guild_id": guild_id},
            {f"members.{user_id}.gacha_inventory": 1}
        )
      
        if not result:
            return await ctx.reply("❌ Error accessing your collection.", mention_author=False)
      
        inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
        updated_inventory = inventory[:]  # Copy to modify
      
        for uid in uids:
            upper_uid = uid.upper()
          
            # Check ownership and get char
            owner_id, char = await self.get_character_by_uid(guild_id, uid)
          
            if not char:
                failed.append((upper_uid, "No character found"))
                continue
          
            if owner_id != user_id:
                failed.append((upper_uid, "You don't own this"))
                continue
          
            # Find and update in inventory
            char_found = False
          
            for i, character in enumerate(updated_inventory):
                if character.get("uid", "").upper() == upper_uid:
                    char_found = True
                    was_favorited = character.get("favorite", False)
                  
                    if was_favorited:
                        updated_inventory[i]["favorite"] = False
                        updated = True
                  
                    action = "unfavorited" if was_favorited else "already unfavorited"
                    star = "☆"
                  
                    # Create embed for this character
                    rarity = char.get("rarity", "common")
                    rarity_data = GACHA_RARITY_TIERS.get(rarity, GACHA_RARITY_TIERS["common"])
                    rarity_emoji = rarity_data["emoji"]
                    
                    embed = discord.Embed(
                        title=f"{rarity_emoji} {char['name']} Favorited!",
                        description=(
                            f"**Series:** {char.get('anime', 'Unknown')}\n"
                            f"**Rarity:** {rarity.title()} {rarity_emoji}\n"
                            f"**UID:** `{upper_uid}`"
                        ),
                        color=rarity_data["color"]
                    )
                    
                    # Add character image
                    if char.get("image_url"):
                        embed.set_thumbnail(url=char["image_url"])
                    
                    # Add footer with stats
                    favorites = char.get("favorites", 0)
                    embed.set_footer(
                        text=f"❤️ {favorites:,} favorites • Added to favorites",
                        icon_url=ctx.author.avatar.url if ctx.author.avatar else None
                    )
                  
                    success_embeds.append(embed)
                    break
          
            if not char_found:
                failed.append((upper_uid, "Not found in collection"))
      
        # Update database if changes were made
        if updated:
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$set": {f"members.{user_id}.gacha_inventory": updated_inventory}},
                upsert=True
            )
      
        # Create failed embed if any
        embeds_to_send = success_embeds[:]
      
        if failed:
            fail_desc = "\n".join(f"❌ `{uid}`: {reason}" for uid, reason in failed)
            failed_embed = discord.Embed(
                title="Unfavorite Failed",
                description=fail_desc,
                color=0xFF0000
            )
            embeds_to_send.append(failed_embed)
      
        if embeds_to_send:
            await ctx.reply(embeds=embeds_to_send, mention_author=False)
        else:
            await ctx.reply("❌ No valid operations performed.", mention_author=False)
      
     except Exception as e:
        logger.error(f"Error in draw unfavorite: {e}")
        await ctx.reply("❌ Error updating favorite status. Please try again.", mention_author=False)
        
    @draw.command(name="market", aliases=["shop", "marketplace"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw_market(self, ctx):
        """🏪 View the global character marketplace."""
        # For now, show coming soon - full marketplace needs more infrastructure
        embed = discord.Embed(
            title="🏪 Character Marketplace",
            description="**Coming Soon!**\n\n"
                       "The global marketplace will allow you to:\n"
                       "• List characters for sale by UID\n"
                       "• Browse and buy characters from others\n"
                       f"For now, use `{ctx.prefix}draw trade @user <UID>` for direct trades!",
            color=discord.Color.gold()
        )
        await ctx.reply(embed=embed, mention_author=False)
    
    @draw.command(name="hierarchy", aliases=["hier", "fam"])
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def draw_hierarchy(self, ctx, uid: str = None):
        """🏛️ View character hierarchy for an anime series.
        
        Shows all characters from an anime organized by role:
        - 👑 Main Characters
        - ⭐ Supporting Characters  
        - 🎭 Background Characters
        
        Characters you own are shown in color, missing ones are grayed out.
        
        Usage:
        - `.draw hierarchy <UID>` - View hierarchy for anime of character with that UID
        """
        if not uid:
            embed = discord.Embed(
                title="🏛️ Character Hierarchy",
                description=f"View all characters from an anime series!\n\n"
                           f"**Usage:** `{ctx.prefix}draw hierarchy <UID>`\n\n"
                           f"This will show the character hierarchy for the anime that the character belongs to.\n"
                           f"• 👑 **Main Characters** - Protagonists and main cast\n"
                           f"• ⭐ **Supporting Characters** - Important recurring characters\n"
                           f"• 🎭 **Background Characters** - Minor/background roles\n\n"
                           f"Characters you own are shown in full color.\n"
                           f"Characters you're missing are grayed out.",
                color=discord.Color.gold()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Get the character by UID to find the anime
        owner_id, character = await self.get_character_by_uid(guild_id, uid)
        
        if not character:
            return await ctx.reply(f"❌ No character found with UID `{uid.upper()}`", mention_author=False)
        
        anime_name = character.get("anime", "Unknown")
        if anime_name == "Unknown":
            return await ctx.reply("❌ This character doesn't have an associated anime.", mention_author=False)
        
        # Show loading message
        loading_embed = discord.Embed(
            title="🏛️ Loading Character Hierarchy...",
            description=f"Fetching all characters from **{anime_name}**...\nThis may take a moment.",
            color=discord.Color.blue()
        )
        loading_msg = await ctx.reply(embed=loading_embed, mention_author=False)
        
        try:
            # Fetch all characters from this anime using Jikan API
            session = await self.get_session()
            
            # First, search for the anime to get its ID
            anime_search_url = f"https://api.jikan.moe/v4/anime"
            params = {"q": anime_name, "limit": 5}
            
            anime_id = None
            anime_image_url = None
            
            async with session.get(anime_search_url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    animes = data.get("data", [])
                    
                    if animes:
                        # Find best match
                        for anime in animes:
                            title = anime.get("title", "")
                            title_english = anime.get("title_english", "")
                            
                            if (anime_name.lower() in title.lower() or 
                                anime_name.lower() in (title_english or "").lower() or
                                title.lower() in anime_name.lower()):
                                anime_id = anime.get("mal_id")
                                anime_image_url = anime.get("images", {}).get("jpg", {}).get("large_image_url")
                                break
                        
                        # If no exact match, use first result
                        if not anime_id and animes:
                            anime_id = animes[0].get("mal_id")
                            anime_image_url = animes[0].get("images", {}).get("jpg", {}).get("large_image_url")
            
            if not anime_id:
                await loading_msg.edit(embed=discord.Embed(
                    title="❌ Anime Not Found",
                    description=f"Could not find anime **{anime_name}** in the database.",
                    color=discord.Color.red()
                ))
                return
            
            # Fetch all characters for this anime
            characters_url = f"https://api.jikan.moe/v4/anime/{anime_id}/characters"
            
            all_characters = []
            
            async with session.get(characters_url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    char_data = await resp.json()
                    characters = char_data.get("data", [])
                    
                    for char_info in characters:
                        char = char_info.get("character", {})
                        role = char_info.get("role", "Supporting")
                        
                        # Get character details
                        char_id = char.get("mal_id")
                        char_name = char.get("name", "Unknown")
                        char_image = char.get("images", {}).get("jpg", {}).get("image_url")
                        
                        # Estimate rarity based on role and favorites
                        favorites = char_info.get("favorites", 0) or char.get("favorites", 0)
                        
                        # Determine rarity
                        if favorites >= 15000:
                            rarity = "legendary"
                        elif favorites >= 8000:
                            rarity = "epic"
                        elif favorites >= 3000:
                            rarity = "rare"
                        elif favorites >= 1000:
                            rarity = "uncommon"
                        else:
                            rarity = "common"
                        
                        all_characters.append({
                            "id": char_id,
                            "name": char_name,
                            "image_url": char_image,
                            "role": role,
                            "favorites": favorites,
                            "rarity": rarity,
                            "anime": anime_name
                        })
            
            if not all_characters:
                await loading_msg.edit(embed=discord.Embed(
                    title="❌ No Characters Found",
                    description=f"Could not find any characters for **{anime_name}**.",
                    color=discord.Color.red()
                ))
                return
            
            # Get user's owned characters from this anime
            user_inventory = await self.get_user_inventory(user_id, guild_id)
            owned_from_anime = [
                char for char in user_inventory 
                if char.get("anime", "").lower() == anime_name.lower()
            ]
            
            # Get user avatar
            avatar_bytes = None
            try:
                async with session.get(ctx.author.display_avatar.url) as resp:
                    if resp.status == 200:
                        avatar_bytes = await resp.read()
            except:
                pass
            
            # Generate the hierarchy image
            from bot.utils.cogs.game.images import generate_character_hierarchy_image
            
            buffer = await generate_character_hierarchy_image(
                anime_name=anime_name,
                anime_image_url=anime_image_url,
                all_characters=all_characters,
                owned_characters=owned_from_anime,
                user_name=ctx.author.display_name,
                user_avatar_bytes=avatar_bytes
            )
            
            # Create file and embed
            file = discord.File(buffer, filename=f"hierarchy_{anime_id}.png")
            
            # Calculate stats
            total_chars = len(all_characters)
            owned_count = len(owned_from_anime)
            completion = (owned_count / total_chars * 100) if total_chars > 0 else 0
            
            # Count by role
            main_count = sum(1 for c in all_characters if c.get("role") == "Main")
            supporting_count = sum(1 for c in all_characters if c.get("role") == "Supporting")
            background_count = total_chars - main_count - supporting_count
            
            # Send image as attachment without embedding
            await loading_msg.delete()
            await ctx.send(
                content=f"**🏛️ Character Hierarchy: {anime_name}**\n"
                       f"**{owned_count}/{total_chars}** characters collected ({completion:.1f}% complete)\n"
                       f"👑 Main: **{main_count}** | ⭐ Supporting: **{supporting_count}** | 🎭 Background: **{background_count}**\n"
                       f"_Characters you own are shown in color • Requested by {ctx.author.display_name}_",
                file=file
            )
            
        except Exception as e:
            logger.error(f"Error in draw hierarchy: {e}", exc_info=True)
            await loading_msg.edit(embed=discord.Embed(
                title="❌ Error",
                description="An error occurred while generating the hierarchy. Please try again.",
                color=discord.Color.red()
            ))
    
    @draw.command(name="steal", aliases=["thief", "rob"])
    @commands.cooldown(1, 1800, commands.BucketType.user)
    async def draw_steal(self, ctx, uid: str = None):
        """🎭 Attempt to steal a character from another player!
        
        Fair Success Rate System:
        • Equal collection value: 40% success chance
        • Lower collection value: Proportional chance (0.5%-39%)
        • Higher collection value: Bonus chance (40%-50% max)
        • Bot developer: 100% success chance
        • On failure: Sacrifice a random card to target
        
        Usage: `.draw steal <UID>`
        """
        if not uid:
            embed = discord.Embed(
                title="❌ Invalid Usage",
                description=f"Usage: `{ctx.prefix}draw steal <UID>`\n"
                           f"Steal a character from another player!",
                color=discord.Color.red()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        guild_id = str(ctx.guild.id)
        thief_id = str(ctx.author.id)
        
        # Get target character
        owner_id, target_char = await self.get_character_by_uid(guild_id, uid)
        
        if not target_char:
            return await ctx.reply(f"❌ No character found with UID `{uid.upper()}`", mention_author=False)
        
        # Can't steal from yourself
        if owner_id == thief_id:
            return await ctx.reply("❌ You can't steal from yourself!", mention_author=False)
        
        # Get target user
        try:
            target_user = ctx.guild.get_member(int(owner_id))
            target_name = target_user.display_name if target_user else "Unknown"
        except:
            target_name = "Unknown"
        
        # Get both inventories
        thief_inventory = await self.get_user_inventory(thief_id, guild_id)
        target_inventory = await self.get_user_inventory(owner_id, guild_id)
        
        if not thief_inventory:
            return await ctx.reply("❌ You need at least 1 character to attempt a steal!", mention_author=False)
        
        # Calculate collection values
        thief_value = self._calculate_collection_value(thief_inventory)
        target_value = self._calculate_collection_value(target_inventory)
        
        # Check if thief has sufficient collection value
        if thief_value < target_value:
            # Calculate fair success chance based on collection value ratio
            value_ratio = thief_value / target_value  # 0.0 to 0.99
            
            # Fair chance calculation: base chance scaled by value ratio
            # This creates a smooth curve where weaker collections have proportionally lower chances
            base_chance = 0.4  # 40% base chance for equal values
            success_chance = base_chance * value_ratio
            
            # Minimum chance of 0.5% for very weak collections (still possible but very unlikely)
            success_chance = max(0.005, success_chance)
            
            embed = discord.Embed(
                title="⚠️ Risky Steal Attempt!",
                description=f"Your collection value is significantly lower!\n\n"
                           f"**Your Collection:** {thief_value:,} pts\n"
                           f"**{target_name}'s Collection:** {target_value:,} pts\n\n"
                           f"**Success Chance:** {success_chance*100:.2f}%\n"
                           f"*Collection Power Ratio: {value_ratio*100:.1f}%*",
                color=discord.Color.orange()
            )
            embed.set_footer(text="💡 Tip: Build your collection value for better odds!")
            
            # Show warning but allow the attempt
            await ctx.reply(embed=embed, mention_author=False)
        else:
            # For equal or stronger collections, use fair calculation
            if thief_value == target_value:
                success_chance = 0.4  # 40% for equal collections
            else:
                # Bonus chance for stronger collections (capped at 50%)
                strength_ratio = min(target_value / thief_value, 1.5)
                success_chance = min(0.5, 0.4 * strength_ratio)
        
        # Check if user is bot developer (100% success rate)
        is_developer = await self._is_bot_developer(ctx.author.id)
        if is_developer:
            success_chance = 1.0  # Guaranteed success for developers
        
        # Attempt the steal
        import random
        success = random.random() < success_chance
        
        if success:
            # SUCCESS: Transfer the character
            try:
                # Remove from target's inventory
                await self._remove_character_from_inventory(owner_id, guild_id, uid)
                
                # Add to thief's inventory
                await self._add_character_to_inventory(thief_id, guild_id, target_char)
                
                # Create success embed
                rarity = target_char.get("rarity", "common")
                rarity_data = GACHA_RARITY_TIERS.get(rarity, GACHA_RARITY_TIERS["common"])
                char_name = target_char.get("name", "Unknown")
                
                embed = discord.Embed(
                    title="Steal Successful!",
                    description=f"You successfully stole **{char_name}** from {target_name}!",
                    color=rarity_data["color"]
                )
                embed.add_field(name="Character", value=f"**{char_name}**\n{rarity_data['emoji']} {rarity.title()}", inline=True)
                embed.add_field(name="Anime", value=f"*{target_char.get('anime', 'Unknown')}*", inline=True)
                embed.add_field(name="New Owner", value=f"{ctx.author.mention}", inline=True)
                embed.add_field(name="Previous Owner", value=f"{target_name}", inline=True)
                embed.set_thumbnail(url=target_char.get("image_url"))
                
                await ctx.reply(embed=embed, mention_author=False)
                
                # Notify the victim (optional - could be removed)
                if target_user:
                    try:
                        victim_embed = discord.Embed(
                            title="💔 Your Character Was Stolen!",
                            description=f"**{char_name}** was stolen from your collection by {ctx.author.display_name}!",
                            color=discord.Color.red()
                        )
                        victim_embed.add_field(name="Character", value=f"**{char_name}**\n{rarity_data['emoji']} {rarity.title()}", inline=True)
                        victim_embed.add_field(name="Anime", value=f"*{target_char.get('anime', 'Unknown')}*", inline=True)
                        victim_embed.add_field(name="Thief", value=f"{ctx.author.display_name}", inline=True)
                        victim_embed.set_thumbnail(url=target_char.get("image_url"))
                        victim_embed.set_footer(text="💔 Keep your collection secure!")
                        await target_user.send(embed=victim_embed)
                    except:
                        pass  # Can't DM user
                        
            except Exception as e:
                logger.error(f"Error transferring stolen character: {e}")
                await ctx.reply("❌ Error occurred during steal transfer. Please contact support!", mention_author=False)
        
        else:
            # FAILURE: Sacrifice a random card
            try:
                # Select random character from thief's inventory
                sacrifice_char = random.choice(thief_inventory)
                sacrifice_uid = sacrifice_char.get("uid")
                
                # Remove from thief's inventory
                await self._remove_character_from_inventory(thief_id, guild_id, sacrifice_uid)
                
                # Add to target's inventory
                await self._add_character_to_inventory(owner_id, guild_id, sacrifice_char)
                
                # Create failure embed
                sacrifice_name = sacrifice_char.get("name", "Unknown")
                sacrifice_rarity = sacrifice_char.get("rarity", "common")
                sacrifice_rarity_data = GACHA_RARITY_TIERS.get(sacrifice_rarity, GACHA_RARITY_TIERS["common"])
                
                embed = discord.Embed(
                    title="💔 Steal Failed!",
                    description=f"You got caught trying to steal **{target_char.get('name', 'Unknown')}**!\n\n"
                               f"You lost **{sacrifice_name}** as punishment.",
                    color=discord.Color.red()
                )
                embed.add_field(name="Sacrificed Character", value=f"{sacrifice_rarity_data['emoji']} **{sacrifice_name}**", inline=True)
                embed.add_field(name="Victim", value=target_name, inline=True)
                embed.set_thumbnail(url=sacrifice_char.get("image_url"))
                await ctx.reply(embed=embed, mention_author=False)
                
                # Notify the target about their new card
                if target_user:
                    try:
                        target_embed = discord.Embed(
                            title=":gift: Caught a Thief!",
                            description=f"{ctx.author.display_name} tried to steal **{target_char.get('name', 'Unknown')}** from you!\n\n"
                                       f"You caught them and received **{sacrifice_name}** as compensation!",
                            color=discord.Color.green()
                        )
                        target_embed.add_field(name="Failed Target", value=f"**{target_char.get('name', 'Unknown')}**\n*{target_char.get('anime', 'Unknown')}*", inline=True)
                        target_embed.add_field(name="Your Reward", value=f"**{sacrifice_name}**\n{sacrifice_rarity_data['emoji']} {sacrifice_rarity.title()}\n*{sacrifice_char.get('anime', 'Unknown')}*", inline=True)
                        target_embed.add_field(name="Thief", value=f"{ctx.author.display_name}", inline=True)
                        target_embed.set_thumbnail(url=sacrifice_char.get("image_url"))
                        target_embed.set_footer(text="🛡️ Justice served - You gained a new character!")
                        await target_user.send(embed=target_embed)
                    except:
                        pass  # Can't DM user
                        
            except Exception as e:
                logger.error(f"Error handling steal failure: {e}")
                await ctx.reply("❌ Error occurred during failed steal. Please contact support!", mention_author=False)
    
    def _calculate_collection_value(self, inventory: list) -> int:
        """Calculate total collection value based on character rarity and favorites"""
        total_value = 0
        for char in inventory:
            rarity = char.get("rarity", "common")
            favorites = char.get("favorites", 0)
            char_name = char.get("name", "unknown")
            
            # Use the same value calculation as release system
            char_value = calculate_release_value(favorites, rarity, char_name)
            total_value += char_value
        
        return total_value
    
    async def _is_bot_developer(self, user_id: str) -> bool:
        """Check if user is a bot developer"""
        # Replace with actual bot owner ID(s)
        # You can get this from ctx.bot.owner_id or check specific user IDs
        try:
            # Method 1: Check if bot owner
            app_info = await self.bot.application_info()
            if user_id == str(app_info.owner.id):
                return True
            
            # Method 2: Check specific developer IDs (add yours here)
            developer_ids = [
                # Add your Discord user ID here
                # "YOUR_DISCORD_USER_ID_HERE",
            ]
            return user_id in developer_ids
        except:
            return False
    
    async def _remove_character_from_inventory(self, user_id: str, guild_id: str, uid: str):
        """Remove a character from user's inventory by UID"""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$pull": {f"members.{user_id}.gacha_inventory": {"uid": uid.upper()}}}
            )
        except Exception as e:
            logger.error(f"Error removing character from inventory: {e}")
            raise
    
    async def _add_character_to_inventory(self, user_id: str, guild_id: str, character: dict):
        """Add a character to user's inventory"""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$push": {f"members.{user_id}.gacha_inventory": character}}
            )
        except Exception as e:
            logger.error(f"Error adding character to inventory: {e}")
            raise
    
    @draw.command(name="drop")
    @commands.is_owner()
    async def draw_drop(self, ctx, *, args: str = None):
        """🎯 [DEV ONLY] Drop specific characters in the 3-card draw.
        
        Usage: `.draw drop Anya Forger, Loid Forger`
               `.draw drop Naruto Uzumaki`
               `.draw drop "Character1, Character2, Character3"` (quotes optional)
               `.draw drop --anime "Re:Zero" rem, ram` (filter by anime)
        
        Unfilled slots will be randomized using normal gacha logic.
        Max 3 specific characters, rest will be random.
        """
        if not args:
            return await ctx.reply("❌ Usage: `.draw drop Anya Forger, Loid Forger` or `.draw drop --anime \"Re:Zero\" rem, ram`", mention_author=False)
        
        # Parse arguments
        anime_filter = None
        character_names = None
        
        try:
            # Check for anime filter
            if "--anime" in args:
                parts = args.split("--anime", 1)
                if len(parts) < 2:
                    return await ctx.reply("❌ Invalid format. Use: `.draw drop --anime \"Anime Name\" character1, character2`", mention_author=False)
                
                anime_part = parts[1].strip()
                # Extract anime name (quoted or unquoted)
                if anime_part.startswith('"'):
                    # Quoted anime name
                    end_quote = anime_part.find('"', 1)
                    if end_quote == -1:
                        return await ctx.reply("❌ Unclosed quote in anime name", mention_author=False)
                    anime_filter = anime_part[1:end_quote]
                    character_part = anime_part[end_quote + 1:].strip()
                else:
                    # Unquoted - take everything until comma as anime name
                    if ',' in anime_part:
                        comma_idx = anime_part.index(',')
                        anime_filter = anime_part[:comma_idx].strip()
                        character_part = anime_part[comma_idx + 1:].strip()
                    else:
                        # No comma found - take first word as anime, rest as single character
                        anime_parts = anime_part.split(None, 1)
                        if len(anime_parts) < 2:
                            return await ctx.reply("❌ Please provide character names after anime filter", mention_author=False)
                        anime_filter = anime_parts[0]
                        character_part = anime_parts[1]
                
                # Clean character names
                character_names = [name.strip() for name in character_part.split(",") if name.strip()]
            else:
                # No anime filter, just character names
                character_names = [name.strip() for name in args.split(",") if name.strip()]
            
            character_names = character_names[:3]  # Max 3 characters
            
            if not character_names:
                return await ctx.reply("❌ No valid character names provided", mention_author=False)
                
        except Exception as e:
            return await ctx.reply(f"❌ Error parsing arguments: {e}", mention_author=False)
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Send loading message
        loading_msg = await ctx.reply(
            embed=discord.Embed(
                description=f"Looking for: **{', '.join(character_names)}**" + (f"\nAnime filter: **{anime_filter}**" if anime_filter else "") + "\n```py\nFetching specific characters...```",
                color=discord.Color.purple()
            ),
            mention_author=False
        )
        
        # Fetch specific characters
        specific_characters = []
        for name in character_names:
            char = await self.fetch_character_by_name(name)
            if char and char.get("image_url") and char.get("anime"):
                # Apply anime filter if specified
                if anime_filter and anime_filter.lower() not in char.get("anime", "").lower():
                    logger.info(f"[Dev Drop] Character {char.get('name')} filtered out (not from {anime_filter})")
                    continue
                
                # Ensure proper rarity assignment
                if not char.get("rarity"):
                    anime_pop = char.get("anime_popularity", 0)
                    char_favs = char.get("favorites", 0)
                    char["rarity"] = get_combined_rarity(anime_pop, char_favs)
                specific_characters.append(char)
                logger.info(f"[Dev Drop] Found specific character: {name} -> {char.get('name', 'Unknown')}")
            else:
                logger.warning(f"[Dev Drop] Could not find character: {name}")
        
        # Fill remaining slots with random characters
        remaining_slots = 3 - len(specific_characters)
        random_characters = []
        
        if remaining_slots > 0:
            logger.info(f"[Dev Drop] Need {remaining_slots} random characters to fill remaining slots")
            random_characters = await self.pull_gacha_cards(remaining_slots, gender_filter=None, guild_id=guild_id)
        
        # Combine specific and random characters
        all_characters = specific_characters + random_characters
        
        # Ensure we have exactly 3 characters
        while len(all_characters) < 3:
            # Emergency fallback if we still don't have enough
            fallback_char = await self.fetch_character_by_rarity("common")
            if fallback_char and fallback_char.get("image_url"):
                all_characters.append(fallback_char)
            else:
                break
        
        if len(all_characters) < 3:
            await loading_msg.delete()
            return await ctx.reply("❌ Failed to gather enough characters for the draw", mention_author=False)
        
        # Check ownership for each character
        ownership_info = await self.check_character_ownership(ctx.guild, all_characters)
        
        # Generate draw image with ownership info
        img_buffer = await generate_gacha_draw_image(all_characters, ownership_info=ownership_info)
        file = discord.File(img_buffer, filename="dev_drop.png")
        
        # Get user balance for display
        balance = await self.quest_data.get_balance(user_id, guild_id)
        
        # Delete loading message
        try:
            await loading_msg.delete()
        except:
            pass
        
        # Send the result - just the image, no embed
        try:
            # Create a simple view for claiming (no cost for dev drops)
            view = GachaClaimView(self, ctx.author, guild_id, all_characters, balance, 
                                draws_left=999, is_out_of_draws=False, is_dev_drop=True)
            msg = await ctx.reply(file=file, view=view, mention_author=False)
            view.message = msg
        except Exception as e:
            logger.error(f"Error creating dev drop view: {e}", exc_info=True)
            # Fallback: send without view
            await ctx.reply(file=file, mention_author=False)

    @draw.command(aliases=["gacha", "pull"])
    async def _execute_draw(self, ctx, gender_filter: str = None):
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        cost = GACHA_COST
        
        # Check if user has reached claim limit
        session_claims = await self.get_session_claims(user_id, guild_id)
        if session_claims >= MAX_CLAIMS_PER_DRAW:
            gacha_config = get_timer_config("gacha")
            # Check remaining cooldown time
            remaining = await self.check_cooldown(user_id, "gacha_main", gacha_config["cooldown"], guild_id)
            if remaining:
                wait_time = self.format_time(remaining)
                message = get_gacha_cooldown_message(wait_time)
                return await ctx.reply(message, mention_author=False)
            else:
                # Cooldown expired, reset claims
                await self.reset_session_claims(user_id, guild_id)
        
        # Check timer (cooldown + daily limit)
        timer_error = await self.check_timer(ctx, "gacha")
        if timer_error:
            return await ctx.reply(timer_error, mention_author=False)
        
        # Check balance
        balance = await self.quest_data.get_balance(user_id, guild_id)
        if balance < cost:
            return await ctx.reply(f"❌ Need **{cost}** but have **{balance:,}** pts!", mention_author=False)
        
        # Set command cooldown, deduct cost and increment plays
        await self.set_cooldown(user_id, "gacha_command")
        await self.quest_data.add_balance(user_id, guild_id, -cost)
        await self.increment_plays(user_id, guild_id, "gacha")
        
        # Send loading message
        loading_msg = await ctx.reply(
            embed=discord.Embed(
                title="Pulling characters...",
                description="```py\nFetching your gacha results...```",
                color=discord.Color.blue()
            ),
            mention_author=False
        )
        
        # Filter text for title
        filter_text = ""
        if gender_filter == "Female":
            filter_text = " ♀️ Waifu"
        elif gender_filter == "Male":
            filter_text = " ♂️ Husbando"
        
        # Fetch characters with pity system
        characters = await self.pull_three_cards_real(gender_filter, user_id=user_id, guild_id=guild_id)
        
        # Check ownership for each character
        ownership_info = await self.check_character_ownership(ctx.guild, characters)
        
        # Generate draw image with ownership info
        img_buffer = await generate_gacha_draw_image(characters, ownership_info=ownership_info)
        file = discord.File(img_buffer, filename="gacha_draw.png")
        
        # Send image directly without embed
        new_balance = balance - cost
        gacha_config = get_timer_config("gacha")
        current_uses = await self.get_current_uses(user_id, guild_id, "gacha")
        draws_left = gacha_config['max_uses'] - current_uses
        
        # Check if user is out of draws
        is_out_of_draws = draws_left <= 0
        
        # Delete loading message
        try:
            await loading_msg.delete()
        except:
            pass
        
        # Get current session claims
        session_claims = await self.get_session_claims(user_id, guild_id)
        
        # Create claim view and send instantly
        try:
            view = GachaClaimView(self, ctx.author, guild_id, characters, new_balance, draws_left, is_out_of_draws, session_claims=session_claims)
            msg = await ctx.reply(file=file, view=view, mention_author=False)
            view.message = msg
        except Exception as e:
            logger.error(f"Error creating GachaClaimView: {e}", exc_info=True)
            # Fallback: send without view if view creation fails
            fallback_content = self._get_draw_summary_content(ctx.author.display_name, new_balance, draws_left, is_out_of_draws)
            await ctx.reply(content=fallback_content, file=file, mention_author=False)

    # Keep old slots/dice as game subcommands for backwards compatibility
    @game.command(name="slots", hidden=True)
    async def game_slots(self, ctx, bet: int = 50):
        """Redirect to main slots command."""
        # ... (rest of the code remains the same)
        await ctx.invoke(self.slots_command, bet=bet)
    
    @game.command(name="dice", aliases=["roll"], hidden=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def dice_game(self, ctx, bet: int = 50, guess: int = None):
        """🎲 Guess the dice roll! Guess 1-6 to play."""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        if guess is None:
            embed = discord.Embed(
                title="🎲 Dice Game",
                description=f"`{ctx.prefix}game dice <bet> <guess>`\n\n"
                           f"Guess 1-6. Exact = **5x**, Off by 1 = **2x**",
                color=primary_color()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        if guess < 1 or guess > 6:
            return await ctx.reply("❌ Guess between **1** and **6**!", mention_author=False)
        if bet < 10 or bet > 5000:
            return await ctx.reply("❌ Bet between **10** and **5,000** pts!", mention_author=False)
        
        balance = await self.quest_data.get_balance(user_id, guild_id)
        if balance < bet:
            return await ctx.reply(f"❌ Need **{bet:,}** but have **{balance:,}** pts!", mention_author=False)
        
        await self.quest_data.add_balance(user_id, guild_id, -bet)
        
        roll = random.randint(1, 6)
        dice_faces = {1: "⚀", 2: "⚁", 3: "⚂", 4: "⚃", 5: "⚄", 6: "⚅"}
        
        diff = abs(roll - guess)
        if diff == 0:
            winnings = bet * 5
            result = "**PERFECT!**"
            color = discord.Color.gold()
        elif diff == 1:
            winnings = bet * 2
            result = "**Close!**"
            color = discord.Color.green()
        else:
            winnings = 0
            result = "**Miss!**"
            color = discord.Color.red()
        
        if winnings > 0:
            await self.quest_data.add_balance(user_id, guild_id, winnings)
        
        new_balance = balance - bet + winnings
        profit = winnings - bet
        
        embed = discord.Embed(title="🎲 Dice Game", color=color)
        embed.add_field(name="Roll", value=f"{dice_faces[roll]} **{roll}**", inline=True)
        embed.add_field(name="Guess", value=f"**{guess}**", inline=True)
        embed.add_field(name="Result", value=result, inline=False)
        embed.add_field(
            name="Won" if profit > 0 else "Lost",
            value=f"**{profit:+,}** pts",
            inline=True
        )
        embed.add_field(name="💳 Balance", value=f"**{new_balance:,}** pts", inline=True)
        
        await ctx.reply(embed=embed, mention_author=False)
    
    # ═══════════════════════════════════════════════════════════════
    # MULTIPLAYER GAMES - HANGMAN
    # ═══════════════════════════════════════════════════════════════
    
    @commands.command(name="hangman", aliases=["hm"])
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def hangman_game(self, ctx):
        """Multiplayer Hangman! Play in DMs, results shown in channel."""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Check timer (cooldown + daily limit)
        timer_error = await self.check_timer(ctx, "hangman")
        if timer_error:
            return await ctx.reply(timer_error, mention_author=False)
        
        # Set command cooldown for starting a hangman game
        await self.set_cooldown(user_id, "hangman_command")
        await self.increment_plays(user_id, guild_id, "hangman")
        
        guild_id = str(ctx.guild.id)
        game_id = f"{guild_id}_{ctx.channel.id}_hangman_{int(datetime.now(timezone.utc).timestamp())}"
        
        # Get word from API or fallback
        word = None
        try:
            session = await self.get_session()
            async with session.get("https://random-word-api.herokuapp.com/word") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data and len(data[0]) >= 4:
                        word = data[0].upper()
        except:
            pass
        
        if not word:
            fallback = CLASSIC_CONFIG.get("hangman", {}).get("fallback_words", [
                "MISSION", "SECRET", "AGENT", "FORGER", "TWILIGHT", "CIPHER", "PUZZLE", "MYSTERY"
            ])
            word = random.choice(fallback).upper()
        
        # Initialize multiplayer game
        self.active_games[game_id] = {
            "word": word,
            "players": {},
            "channel": ctx.channel,
            "guild_id": guild_id,
            "host_id": str(ctx.author.id),
            "started": False,
            "game_msg": None
        }
        
        # Generate initial waiting room image
        host_avatar = None
        if ctx.author.avatar:
            async with aiohttp.ClientSession() as session:
                host_avatar = await fetch_avatar_bytes(session, ctx.author.avatar.url)
        
        img_buffer = await generate_waiting_room_image(
            game_name="HANGMAN",
            host_name=ctx.author.display_name,
            host_avatar_bytes=host_avatar,
            players=[],
            max_players=5,
            extra_info=f"{len(word)} letters • 6 lives"
        )
        
        file = discord.File(img_buffer, filename="hangman_lobby.png")
        embed = discord.Embed(color=discord.Color.blue())
        embed.set_image(url="attachment://hangman_lobby.png")
        embed.set_footer(text="Game starts in 30 seconds or when full!")
        
        view = HangmanJoinView(self, game_id, host_user=ctx.author)
        msg = await ctx.reply(embed=embed, file=file, view=view, mention_author=False)
        self.active_games[game_id]["game_msg"] = msg
        
        # Wait for players
        await asyncio.sleep(30)
        
        if game_id in self.active_games:
            game = self.active_games[game_id]
            if len(game["players"]) == 0:
                embed.description = "❌ No players joined! Game cancelled."
                embed.color = discord.Color.red()
                await msg.edit(embed=embed, view=None)
                del self.active_games[game_id]
            else:
                game["started"] = True
                view.stop()
                await self._start_hangman_game(game_id)
    
    async def _start_hangman_game(self, game_id: str):
        """Start the multiplayer hangman game"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        channel = game["channel"]
        failed_users = []
        
        # Send DMs to all players
        for user_id, player_data in game["players"].items():
            try:
                user = await self.bot.fetch_user(int(user_id))
                view = HangmanLetterView(self, game_id, user_id)
                
                word_display = " ".join("_" for _ in game["word"])
                embed = discord.Embed(
                    title="Hangman",
                    description=f"{HANGMAN_STAGES[0]}\n**Word:** `{word_display}`",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Guessed", value="None", inline=True)
                embed.add_field(name="Wrong", value="0/6", inline=True)
                
                dm_msg = await user.send(embed=embed, view=view)
                player_data["dm_msg"] = dm_msg
                player_data["view"] = view
            except discord.Forbidden:
                logger.warning(f"Cannot DM user {user_id} - DMs disabled")
                try:
                    user_obj = await self.bot.fetch_user(int(user_id))
                    failed_users.append(user_obj.mention)
                except:
                    failed_users.append(f"<@{user_id}>")
                player_data["status"] = "failed"
            except Exception as e:
                logger.error(f"Error sending hangman DM to {user_id}: {e}")
                try:
                    user_obj = await self.bot.fetch_user(int(user_id))
                    failed_users.append(user_obj.mention)
                except:
                    failed_users.append(f"<@{user_id}>")
                player_data["status"] = "failed"
        
        # Notify about failed DMs with mentions
        if failed_users:
            try:
                await channel.send(
                    f"⚠️ {' '.join(failed_users)} - Could not send you DMs!\n"
                    f"Please enable DMs from server members to play!",
                    delete_after=15
                )
            except:
                pass
        
        # Update channel message
        await self._update_hangman_leaderboard(game_id)
    
    async def _update_hangman_leaderboard(self, game_id: str):
        """Update the leaderboard in the channel"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        msg = game["game_msg"]
        
        # Build leaderboard
        leaderboard = []
        for user_id, player_data in game["players"].items():
            try:
                user = await self.bot.fetch_user(int(user_id))
                display = player_data["display"]
                wrong = player_data["wrong"]
                status = player_data["status"]
                
                if status == "won":
                    emoji = "🏆"
                elif status == "lost":
                    emoji = "💀"
                else:
                    emoji = "🎮"
                
                lives = "❤️" * (6 - wrong)
                leaderboard.append(f"{emoji} **{user.display_name}** - `{display}` {lives}")
            except:
                pass
        
        embed = discord.Embed(
            title="🕵️ Hangman - Live Results",
            description="\n".join(leaderboard) if leaderboard else "No players",
            color=discord.Color.blue()
        )
        embed.add_field(name="Word Length", value=f"{len(game['word'])} letters", inline=True)
        
        # Check if game is over
        all_done = all(p["status"] != "playing" for p in game["players"].values())
        if all_done:
            winners = [uid for uid, p in game["players"].items() if p["status"] == "won"]
            embed.add_field(name="Game Over!", value=f"Word was: **{game['word']}**", inline=False)
            if winners:
                embed.color = discord.Color.green()
            else:
                embed.color = discord.Color.red()
        
        try:
            await msg.edit(embed=embed)
        except:
            pass
    
    async def _end_hangman_game(self, game_id: str, winner_user_id: str):
        """End the hangman game when someone wins and notify all players"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        channel = game["channel"]
        
        try:
            # Get winner info
            winner = await self.bot.fetch_user(int(winner_user_id))
            winner_name = winner.display_name
            
            # Calculate and award winner reward (10% + 250 of host's balance)
            guild_id = game.get("guild_id")
            host_id = game.get("host_id")
            reward = 250  # Base reward
            
            if host_id and guild_id:
                try:
                    host_balance = await self.quest_data.get_balance(host_id, guild_id)
                    reward = int(host_balance * 0.10) + 250
                    await self.quest_data.add_balance(winner_user_id, guild_id, reward)
                except Exception as e:
                    logger.error(f"Error calculating hangman reward: {e}")
            
            # Send notification to channel
            embed = discord.Embed(
                title="🏆 Hangman Game Won!",
                description=f"**{winner_name}** solved the word first!\n\n**Word:** `{game['word']}`\n**Reward:** +{reward:,} points\n\nGame ended automatically for all players.",
                color=discord.Color.green()
            )
            await channel.send(embed=embed)
            
            # End game for all remaining players
            for user_id, player_data in game["players"].items():
                if player_data["status"] == "playing":
                    player_data["status"] = "ended"
                    
                    # Update their DM to show game ended
                    try:
                        if player_data.get("dm_msg") and player_data.get("view"):
                            end_embed = discord.Embed(
                                title="🏁 Game Ended",
                                description=f"**{winner_name}** won the game!\n\n**Word was:** `{game['word']}`\n\nBetter luck next time!",
                                color=discord.Color.orange()
                            )
                            await player_data["dm_msg"].edit(embed=end_embed, view=None)
                    except Exception as e:
                        logger.error(f"Error updating DM for user {user_id}: {e}")
            
            # Final leaderboard update
            await self._update_hangman_leaderboard(game_id)
            
        except Exception as e:
            logger.error(f"Error ending hangman game {game_id}: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # MULTIPLAYER GAMES - WORDLE
    # ═══════════════════════════════════════════════════════════════
    
    @commands.command(name="wordle")
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def wordle_game(self, ctx):
        """🟩 Multiplayer Wordle! Play in DMs, results shown in channel."""
        guild_id = str(ctx.guild.id)
        game_id = f"{guild_id}_{ctx.channel.id}_wordle_{int(datetime.now(timezone.utc).timestamp())}"
        
        # Get 5-letter word
        word = None
        try:
            session = await self.get_session()
            async with session.get("https://random-word-api.herokuapp.com/word?length=5") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data and len(data[0]) == 5:
                        word = data[0].upper()
        except:
            pass
        
        if not word:
            fallback = ["AGENT", "CODES", "QUEST", "SWORD", "FLAME", "STORM", "PEACE", "DREAM", "MAGIC", "BRAVE"]
            word = random.choice(fallback)
        
        # Initialize multiplayer game
        self.active_games[game_id] = {
            "word": word,
            "players": {},
            "channel": ctx.channel,
            "guild_id": guild_id,
            "host_id": str(ctx.author.id),
            "started": False,
            "game_msg": None
        }
        
        # Generate initial waiting room image
        host_avatar = None
        if ctx.author.avatar:
            async with aiohttp.ClientSession() as session:
                host_avatar = await fetch_avatar_bytes(session, ctx.author.avatar.url)
        
        img_buffer = await generate_waiting_room_image(
            game_name="WORDLE",
            host_name=ctx.author.display_name,
            host_avatar_bytes=host_avatar,
            players=[],
            max_players=5,
            extra_info="5-letter word • 6 attempts"
        )
        
        file = discord.File(img_buffer, filename="wordle_lobby.png")
        embed = discord.Embed(color=discord.Color.green())
        embed.set_image(url="attachment://wordle_lobby.png")
        embed.set_footer(text="Game starts in 30 seconds or when full!")
        
        view = WordleJoinView(self, game_id, host_user=ctx.author)
        msg = await ctx.reply(embed=embed, file=file, view=view, mention_author=False)
        self.active_games[game_id]["game_msg"] = msg
        
        # Wait for players
        await asyncio.sleep(30)
        
        if game_id in self.active_games:
            game = self.active_games[game_id]
            if len(game["players"]) == 0:
                embed.description = "❌ No players joined! Game cancelled."
                embed.color = discord.Color.red()
                await msg.edit(embed=embed, view=None)
                del self.active_games[game_id]
            else:
                game["started"] = True
                view.stop()
                await self._start_wordle_game(game_id)
    
    async def _start_wordle_game(self, game_id: str):
        """Start the multiplayer wordle game"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        channel = game["channel"]
        failed_users = []
        
        # Send DMs to all players with Pillow image
        for user_id, player_data in game["players"].items():
            try:
                user = await self.bot.fetch_user(int(user_id))
                player_data["display_name"] = user.display_name
                view = WordleGuessView(self, game_id, user_id)
                
                # Fetch avatar for the image
                avatar_bytes = None
                try:
                    session = await self.get_session()
                    avatar_url = user.display_avatar.with_size(64).url
                    avatar_bytes = await fetch_avatar_bytes(session, avatar_url)
                    player_data["avatar_bytes"] = avatar_bytes
                except:
                    pass
                
                # Generate empty board image with avatar
                img_buffer = generate_wordle_board_image(
                    [], game["word"],
                    avatar_bytes=avatar_bytes, player_name=user.display_name
                )
                file = discord.File(img_buffer, filename="wordle_board.png")
                
                embed = discord.Embed(
                    title="🟩 Your Wordle Game",
                    description=f"Click **Submit Guess** to enter a 5-letter word!\n"
                               f"❌ Wrong guess = **-15 stella points**",
                    color=discord.Color.green()
                )
                embed.set_image(url="attachment://wordle_board.png")
                embed.add_field(name="Attempts", value="0/6", inline=True)
                
                dm_msg = await user.send(embed=embed, file=file, view=view)
                player_data["dm_msg"] = dm_msg
                player_data["view"] = view
            except discord.Forbidden:
                logger.warning(f"Cannot DM user {user_id} - DMs disabled")
                try:
                    user_obj = await self.bot.fetch_user(int(user_id))
                    failed_users.append(user_obj.mention)
                except:
                    failed_users.append(f"<@{user_id}>")
                player_data["status"] = "failed"
            except Exception as e:
                logger.error(f"Error sending wordle DM to {user_id}: {e}")
                try:
                    user_obj = await self.bot.fetch_user(int(user_id))
                    failed_users.append(user_obj.mention)
                except:
                    failed_users.append(f"<@{user_id}>")
                player_data["status"] = "failed"
        
        # Notify about failed DMs with mentions
        if failed_users:
            try:
                await channel.send(
                    f"⚠️ {' '.join(failed_users)} - Could not send you DMs!\n"
                    f"Please enable DMs from server members to play!",
                    delete_after=15
                )
            except:
                pass
        
        # Update channel message with live image
        await self._update_wordle_leaderboard(game_id)
    
    async def _end_wordle_game(self, game_id: str, winner_id: str):
        """End the wordle game when someone wins - stops for everyone and pings winner"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        channel = game["channel"]
        
        # Mark game as ended
        game["ended"] = True
        
        # Get winner info
        try:
            winner = await self.bot.fetch_user(int(winner_id))
            winner_mention = winner.mention
            winner_name = winner.display_name
        except:
            winner_mention = f"<@{winner_id}>"
            winner_name = "Unknown"
        
        # Calculate and award winner reward (10% + 250 of host's balance)
        guild_id = game.get("guild_id")
        host_id = game.get("host_id")
        reward = 250  # Base reward
        
        if host_id and guild_id:
            try:
                host_balance = await self.quest_data.get_balance(host_id, guild_id)
                reward = int(host_balance * 0.10) + 250
                await self.quest_data.add_balance(winner_id, guild_id, reward)
            except Exception as e:
                logger.error(f"Error calculating wordle reward: {e}")
        
        # End game for all other players - delete old DM and send new final one
        for user_id, player_data in game["players"].items():
            if user_id == winner_id:
                continue
            
            if player_data["status"] == "playing":
                player_data["status"] = "ended"
            
            # Delete old DM and send new final embed
            try:
                dm_msg = player_data.get("dm_msg")
                if dm_msg:
                    # Delete the old message
                    try:
                        await dm_msg.delete()
                    except:
                        pass
                    
                    # Send new final message
                    avatar_bytes = player_data.get("avatar_bytes")
                    player_name = player_data.get("display_name", "Player")
                    
                    img_buffer = generate_wordle_board_image(
                        player_data["attempts"], 
                        game["word"], 
                        show_word=True,
                        avatar_bytes=avatar_bytes,
                        player_name=player_name
                    )
                    file = discord.File(img_buffer, filename="wordle_final.png")
                    
                    embed = discord.Embed(
                        title="🏁 Game Over!",
                        description=f"**Word was:** {game['word']}",
                        color=discord.Color.orange()
                    )
                    embed.set_image(url="attachment://wordle_final.png")
                    
                    # Get user to send DM
                    try:
                        user = await self.bot.fetch_user(int(user_id))
                        await user.send(
                            content=f"🏆 **{winner_name}** won the Wordle game!",
                            embed=embed,
                            file=file
                        )
                    except:
                        pass
            except Exception as e:
                logger.error(f"Error updating DM for {user_id}: {e}")
        
        # Also update winner's DM - delete old and send new
        winner_data = game["players"].get(winner_id)
        if winner_data:
            try:
                dm_msg = winner_data.get("dm_msg")
                if dm_msg:
                    try:
                        await dm_msg.delete()
                    except:
                        pass
            except:
                pass
        
        # Generate final live image showing all boards
        players_with_names = {}
        for uid, pdata in game["players"].items():
            players_with_names[uid] = pdata.copy()
            if "display_name" not in players_with_names[uid]:
                try:
                    user = await self.bot.fetch_user(int(uid))
                    players_with_names[uid]["display_name"] = user.display_name
                except:
                    players_with_names[uid]["display_name"] = f"Player"
        
        img_buffer = generate_wordle_live_image(players_with_names, self.bot)
        file = discord.File(img_buffer, filename="wordle_final.png")
        
        # Create final embed
        embed = discord.Embed(
            title="🏆 Wordle Complete!",
            description=f"**Word:** {game['word']}",
            color=discord.Color.gold()
        )
        embed.set_image(url="attachment://wordle_final.png")
        
        # Delete old channel message and send new one with winner ping
        try:
            msg = game["game_msg"]
            try:
                await msg.delete()
            except:
                pass
            
            # Send new final message with winner ping in content
            await channel.send(
                content=f"🎉 Congratulations {winner_mention}! You won the Wordle!",
                embed=embed,
                file=file
            )
        except Exception as e:
            logger.error(f"Error sending wordle final message: {e}")
        
    async def _check_wordle_game_end(self, game_id: str):
        """Check if all players are done and end the game if so"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        
        # Check if all players are done
        all_done = all(p["status"] != "playing" for p in game["players"].values())
        if all_done:
            # Mark game as ended
            game["ended"] = True
            
            # No winner - everyone lost
            channel = game["channel"]
            
            # Delete old DMs and send new final ones for all players
            for user_id, player_data in game["players"].items():
                try:
                    dm_msg = player_data.get("dm_msg")
                    if dm_msg:
                        # Delete old message
                        try:
                            await dm_msg.delete()
                        except:
                            pass
                        
                        # Send new final message
                        avatar_bytes = player_data.get("avatar_bytes")
                        player_name = player_data.get("display_name", "Player")
                        
                        img_buffer = generate_wordle_board_image(
                            player_data["attempts"], 
                            game["word"], 
                            show_word=True,
                            avatar_bytes=avatar_bytes,
                            player_name=player_name
                        )
                        file = discord.File(img_buffer, filename="wordle_final.png")
                        
                        embed = discord.Embed(
                            title="💀 Game Over!",
                            description=f"**Word was:** {game['word']}",
                            color=discord.Color.red()
                        )
                        embed.set_image(url="attachment://wordle_final.png")
                        
                        try:
                            user = await self.bot.fetch_user(int(user_id))
                            await user.send(
                                content="😔 No one won the Wordle game!",
                                embed=embed,
                                file=file
                            )
                        except:
                            pass
                except Exception as e:
                    logger.error(f"Error updating DM for {user_id}: {e}")
            
            # Generate final live image
            players_with_names = {}
            for uid, pdata in game["players"].items():
                players_with_names[uid] = pdata.copy()
                if "display_name" not in players_with_names[uid]:
                    try:
                        user = await self.bot.fetch_user(int(uid))
                        players_with_names[uid]["display_name"] = user.display_name
                    except:
                        players_with_names[uid]["display_name"] = f"Player"
            
            img_buffer = generate_wordle_live_image(players_with_names, self.bot)
            file = discord.File(img_buffer, filename="wordle_final.png")
            
            embed = discord.Embed(
                title="💀 Wordle - Game Over!",
                description=f"**Word was:** {game['word']}",
                color=discord.Color.red()
            )
            embed.set_image(url="attachment://wordle_final.png")
            
            # Delete old channel message and send new one
            try:
                msg = game["game_msg"]
                try:
                    await msg.delete()
                except:
                    pass
                
                # Send new final message with "no one won" in content
                await channel.send(
                    content="😔 **No one won the Wordle!** Better luck next time!",
                    embed=embed,
                    file=file
                )
            except Exception as e:
                logger.error(f"Error sending wordle final message: {e}")
            
            # Clean up
            await asyncio.sleep(60)
            if game_id in self.active_games:
                del self.active_games[game_id]

    async def _update_wordle_leaderboard(self, game_id: str):
        """Update the wordle leaderboard in the channel with live image"""
        if game_id not in self.active_games:
            return
        
        game = self.active_games[game_id]
        
        # Don't update if game already ended
        if game.get("ended"):
            return
        
        msg = game["game_msg"]
        
        # Build player data with display names for image
        players_with_names = {}
        for user_id, player_data in game["players"].items():
            players_with_names[user_id] = player_data.copy()
            if "display_name" not in players_with_names[user_id]:
                try:
                    user = await self.bot.fetch_user(int(user_id))
                    players_with_names[user_id]["display_name"] = user.display_name
                    # Also store in original for future use
                    player_data["display_name"] = user.display_name
                except:
                    players_with_names[user_id]["display_name"] = f"Player"
        
        # Generate live image showing all boards
        img_buffer = generate_wordle_live_image(players_with_names, self.bot)
        file = discord.File(img_buffer, filename="wordle_live.png")
        
        # Build text leaderboard as well
        leaderboard = []
        for user_id, player_data in game["players"].items():
            try:
                attempts = len(player_data["attempts"])
                status = player_data["status"]
                name = player_data.get("display_name", "Player")
                
                if status == "won":
                    emoji = "🏆"
                elif status == "lost":
                    emoji = "💀"
                elif status == "ended":
                    emoji = "🏁"
                else:
                    emoji = "🎮"
                
                leaderboard.append(f"{emoji} **{name}** - {attempts}/6")
            except:
                pass
        
        embed = discord.Embed(
            title="🟩 Wordle - Live Results",
            description="\n".join(leaderboard) if leaderboard else "Waiting for players...",
            color=discord.Color.green()
        )
        embed.set_image(url="attachment://wordle_live.png")
        embed.set_footer(text="First to guess correctly wins!")
        
        try:
            await msg.edit(embed=embed, attachments=[file])
        except Exception as e:
            logger.error(f"Error updating wordle leaderboard: {e}")
    
    # ═══════════════════════════════════════════════════════════════
    # CLASSIC GAMES - WORDLE (OLD - KEEPING FOR COMPATIBILITY)
    # ═══════════════════════════════════════════════════════════════
    
    async def _old_wordle_timeout_handler(self, game, game_key, msg):
        """Handle old wordle timeout"""
        def get_result(guess, answer):
            result = []
            answer_chars = list(answer)
            for i, (g, a) in enumerate(zip(guess, answer)):
                if g == a:
                    result.append("🟩")
                    answer_chars[i] = None
                else:
                    result.append(None)
            for i, g in enumerate(guess):
                if result[i] is None:
                    if g in answer_chars:
                        result[i] = "🟨"
                        answer_chars[answer_chars.index(g)] = None
                    else:
                        result[i] = "⬛"
            return "".join(result)
        
        def build_embed(game, status="playing"):
            if status == "win":
                title = "🎉 You Won!"
                color = discord.Color.green()
            elif status == "lose":
                title = "❌ Game Over!"
                color = discord.Color.red()
            else:
                title = "🟩 Wordle"
                color = discord.Color.blue()
            embed = discord.Embed(title=title, color=color)
            grid = []
            for attempt in game["attempts"]:
                result = get_result(attempt, game["word"])
                grid.append(f"{result} `{attempt}`")
            for _ in range(6 - len(game["attempts"])):
                grid.append("⬜⬜⬜⬜⬜")
            embed.description = "\n".join(grid)
            embed.add_field(name="Attempts", value=f"{len(game['attempts'])}/6", inline=True)
            return embed
        
        embed = build_embed(game, "lose")
        embed.add_field(name="⏰ Timeout!", value=f"The word was **{game['word']}**", inline=False)
        await msg.edit(embed=embed)
        del self.active_games[game_key]
        return

    # ═══════════════════════════════════════════════════════════════
    # GROUNDED GAMES (Spy x Family Themed Economy)
    # ═══════════════════════════════════════════════════════════════
    
    async def get_user_job(self, user_id: str, guild_id: str) -> Optional[str]:
        """Get the user's current job ID."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.current_job": 1}
            )
            if result:
                return result.get("members", {}).get(user_id, {}).get("current_job")
        except Exception as e:
            logger.error(f"Error getting user job: {e}")
        return None
    
    async def set_user_job(self, user_id: str, guild_id: str, job_id: Optional[str]):
        """Set the user's current job."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            if job_id is None:
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$unset": {f"members.{user_id}.current_job": ""}},
                    upsert=True
                )
            else:
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$set": {f"members.{user_id}.current_job": job_id}},
                    upsert=True
                )
        except Exception as e:
            logger.error(f"Error setting user job: {e}")
    
    async def get_user_activity(self, user_id: str, guild_id: str) -> int:
        """Get user's activity score (based on messages, commands used, etc.)."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.activity_score": 1}
            )
            if result:
                return result.get("members", {}).get(user_id, {}).get("activity_score", 0)
        except Exception as e:
            logger.error(f"Error getting activity: {e}")
        return 0
    
    async def increment_activity(self, user_id: str, guild_id: str, amount: int = 1):
        """Increment user's activity score."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$inc": {f"members.{user_id}.activity_score": amount}},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error incrementing activity: {e}")
    
    async def get_user_stars(self, user_id: str, guild_id: str) -> int:
        """Get user's total stella stars earned (lifetime earnings)."""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.total_stars_earned": 1}
            )
            if result:
                return result.get("members", {}).get(user_id, {}).get("total_stars_earned", 0)
        except Exception as e:
            logger.error(f"Error getting stars: {e}")
        return 0
    
    def get_job_by_id(self, job_id: str) -> Optional[Dict]:
        """Get job data by ID from config."""
        jobs_config = GROUNDED_CONFIG.get("jobs_system", {}).get("available_jobs", [])
        for job in jobs_config:
            if job.get("id") == job_id:
                return job
        return None
    
    @commands.command(name="jobs", aliases=["job_list", "careers"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def jobs_command(self, ctx):
        """📋 View available jobs and apply for one!"""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Increment activity for using commands
        await self.increment_activity(user_id, guild_id, 1)
        
        # Get user stats
        current_job_id = await self.get_user_job(user_id, guild_id)
        balance = await self.quest_data.get_balance(user_id, guild_id)
        stars = await self.get_user_stars(user_id, guild_id)
        activity = await self.get_user_activity(user_id, guild_id)
        
        jobs_config = GROUNDED_CONFIG.get("jobs_system", {})
        available_jobs = jobs_config.get("available_jobs", [])
        categories = jobs_config.get("job_categories", {})
        
        # Build embed
        embed = discord.Embed(
            title="📋 Job Board",
            description="Apply for a job to start earning stella points with `.work`!\n\n"
                       f"**Your Stats:**\n"
                       f"⭐ Stars: **{stars:,}**\n"
                       f"📊 Activity: **{activity}**\n"
                       f"💰 Balance: **{balance:,}**",
            color=discord.Color.blue()
        )
        
        if current_job_id:
            current_job = self.get_job_by_id(current_job_id)
            if current_job:
                embed.add_field(
                    name="💼 Current Job",
                    value=f"{current_job['emoji']} **{current_job['title']}**\n"
                          f"Pay: {current_job['pay_range'][0]}-{current_job['pay_range'][1]} pts",
                    inline=False
                )
        
        # Group jobs by category
        jobs_by_category = {}
        for job in available_jobs:
            cat = job.get("category", "entry")
            if cat not in jobs_by_category:
                jobs_by_category[cat] = []
            jobs_by_category[cat].append(job)
        
        for cat_id, cat_jobs in jobs_by_category.items():
            cat_info = categories.get(cat_id, {"name": cat_id.title(), "emoji": "📋"})
            job_lines = []
            for job in cat_jobs:
                reqs = job.get("requirements", {})
                qualified = (
                    stars >= reqs.get("min_stars", 0) and
                    activity >= reqs.get("min_activity", 0) and
                    balance >= reqs.get("min_balance", 0)
                )
                status = "✅" if qualified else "🔒"
                job_lines.append(f"{status} {job['emoji']} **{job['title']}** - {job['pay_range'][0]}-{job['pay_range'][1]} pts")
            
            embed.add_field(
                name=f"{cat_info['emoji']} {cat_info['name']}",
                value="\n".join(job_lines) if job_lines else "No jobs",
                inline=False
            )
        
        # Create view with job select and buttons
        view = JobBoardView(self, ctx.author, guild_id, current_job_id)
        await view.setup()  # Async setup to add the select menu with user stats
        await ctx.reply(embed=embed, view=view, mention_author=False)
    
    @commands.command(name="work")
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def work_command(self, ctx):
        """💼 Work at your job to earn stella points!"""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Increment activity
        await self.increment_activity(user_id, guild_id, 1)
        
        # Get work config from JSON
        work_config = GROUNDED_CONFIG.get("work", {})
        cooldown = work_config.get("cooldown", 1800)
        
        # Check cooldown
        remaining = await self.check_cooldown(user_id, "work", cooldown)
        if remaining:
            return await ctx.reply(f"⏳ You can work again in **{self.format_time(remaining)}**", mention_author=False)
        
        # Get character info
        character = await self.get_user_character(user_id, guild_id)
        
        # Determine job title and message
        if character:
            char_bonus = work_config.get("character_bonuses", {}).get(character, {})
            job_title = char_bonus.get("title", "Worker")
            job_emoji = work_config.get("emoji", "💼")
        else:
            # Use default job
            default_jobs = work_config.get("default_jobs", [])
            if default_jobs:
                job_info = random.choice(default_jobs)
                job_title = job_info.get("title", "Worker")
            else:
                job_title = "Worker"
            job_emoji = work_config.get("emoji", "💼")
        
        # Calculate reward
        base_min, base_max = work_config.get("base_reward", [25, 75])
        base_reward = random.randint(base_min, base_max)
        
        # Apply character multiplier
        multiplier = 1.0
        char_message = None
        if character:
            char_bonus = work_config.get("character_bonuses", {}).get(character, {})
            multiplier = char_bonus.get("multiplier", 1.0)
            char_message = char_bonus.get("message")
        
        # If no character message, use default job message
        if not char_message:
            default_jobs = work_config.get("default_jobs", [])
            if default_jobs:
                job_info = random.choice(default_jobs)
                char_message = job_info.get("message", "You completed your work shift!")
            else:
                char_message = "You completed your work shift!"
        
        total_reward = int(base_reward * multiplier)
        
        # Add reward and set cooldown
        await self.quest_data.add_balance(user_id, guild_id, total_reward)
        await self.set_cooldown(user_id, "work")
        
        # Track total stars earned
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            await server_col.update_one(
                {"guild_id": guild_id},
                {"$inc": {f"members.{user_id}.total_stars_earned": total_reward}},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Error tracking stars: {e}")
        
        new_balance = await self.quest_data.get_balance(user_id, guild_id)
        
        # Create embed
        embed = discord.Embed(
            title=f"{job_emoji} {job_title}",
            description=char_message,
            color=discord.Color.green()
        )
        embed.add_field(
            name="💰 Earned",
            value=f"**+{total_reward:,}** pts",
            inline=True
        )
        embed.add_field(
            name="💳 Balance",
            value=f"**{new_balance:,}** pts",
            inline=True
        )
        
        if character and multiplier != 1.0:
            bonus_pct = int((multiplier - 1.0) * 100)
            embed.add_field(
                name=f"🌟 {character} Bonus",
                value=f"+{bonus_pct}%",
                inline=True
            )
        
        await ctx.reply(embed=embed, mention_author=False)
    
    @commands.command(name="rob", aliases=["steal"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def rob_command(self, ctx, target: discord.Member = None):
        """💰 Attempt to steal stella points from another user. High risk!"""
        if target is None:
            return await ctx.reply(f"`{ctx.prefix}rob @user`", mention_author=False)
        
        if target.id == ctx.author.id:
            return await ctx.reply("You can't rob yourself!", mention_author=False)
        
        if target.bot:
            return await ctx.reply("You can't rob bots!", mention_author=False)
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        target_id = str(target.id)
        
        # Check cooldown (2 hours)
        remaining = await self.check_cooldown(user_id, "rob", 7200)
        if remaining:
            return await ctx.reply(f"⏳ You can rob again in **{self.format_time(remaining)}**", mention_author=False)
        
        # Check target balance
        target_balance = await self.quest_data.get_balance(target_id, guild_id)
        if target_balance < 500:
            return await ctx.reply(f"{target.display_name} doesn't have enough to steal (min 500 pts)", mention_author=False)
        
        config = GROUNDED_CONFIG.get("rob", {})
        base_success = config.get("success_rate", 0.4)
        steal_min, steal_max = config.get("steal_percent", [10, 30])
        fine_min, fine_max = config.get("fail_fine_percent", [15, 25])
        
        character = await self.get_user_character(user_id, guild_id)
        success_rate = base_success
        
        if character:
            char_bonus = config.get("character_bonuses", {}).get(character, {})
            success_rate += char_bonus.get("success_boost", 0)
        
        await self.set_cooldown(user_id, "rob")
        
        # Get avatar URLs for crime scene image
        robber_avatar_url = ctx.author.display_avatar.with_size(128).url
        victim_avatar_url = target.display_avatar.with_size(128).url
        
        if random.random() < success_rate:
            steal_percent = random.randint(steal_min, steal_max) / 100
            stolen = int(target_balance * steal_percent)
            
            await self.quest_data.add_balance(target_id, guild_id, -stolen)
            await self.quest_data.add_balance(user_id, guild_id, stolen)
            new_balance = await self.quest_data.get_balance(user_id, guild_id)
            
            success_msgs = config.get("success_messages", ["You stole their points!"])
            
            # Generate crime scene image
            img_buffer = await generate_crime_scene_image(
                robber_avatar_url, victim_avatar_url,
                ctx.author.display_name, target.display_name,
                success=True, amount=stolen
            )
            file = discord.File(img_buffer, filename="robbery.png")
            
            embed = discord.Embed(
                title="💰 Robbery Successful!",
                description=f"{random.choice(success_msgs)}",
                color=discord.Color.green()
            )
            embed.set_image(url="attachment://robbery.png")
            embed.add_field(name="💰 Stolen", value=f"+**{stolen}** pts", inline=True)
            embed.add_field(name="💳 Balance", value=f"**{new_balance:,}** pts", inline=True)
            
            await ctx.reply(embed=embed, file=file, mention_author=False)
        else:
            user_balance = await self.quest_data.get_balance(user_id, guild_id)
            fine_percent = random.randint(fine_min, fine_max) / 100
            fine = int(user_balance * fine_percent) if user_balance > 0 else 50
            fine = max(50, fine)
            
            await self.quest_data.add_balance(user_id, guild_id, -fine)
            new_balance = await self.quest_data.get_balance(user_id, guild_id)
            
            fail_msgs = config.get("fail_messages", ["You got caught!"])
            
            # Generate crime scene image
            img_buffer = await generate_crime_scene_image(
                robber_avatar_url, victim_avatar_url,
                ctx.author.display_name, target.display_name,
                success=False, amount=fine
            )
            file = discord.File(img_buffer, filename="caught.png")
            
            embed = discord.Embed(
                title="🚔 Caught!",
                description=f"{random.choice(fail_msgs)}",
                color=discord.Color.red()
            )
            embed.set_image(url="attachment://caught.png")
            embed.add_field(name="💸 Fine", value=f"-**{fine}** pts", inline=True)
            embed.add_field(name="💳 Balance", value=f"**{new_balance:,}** pts", inline=True)
            
            await ctx.reply(embed=embed, file=file, mention_author=False)
    
    @commands.command(name="claim", aliases=["daily"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def claim_command(self, ctx):
        """🎁 Claim your daily stella points reward!"""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Check cooldown (24 hours) - per-server
        remaining = await self.check_cooldown(user_id, "claim", 86400, guild_id)
        if remaining:
            return await ctx.reply(f"⏳ Next daily in **{self.format_time(remaining)}**", mention_author=False)
        
        config = GROUNDED_CONFIG.get("claim", {})
        base_min, base_max = config.get("base_reward", [100, 200])
        streak_bonus = config.get("streak_bonus", 25)
        max_streak = config.get("max_streak", 30)
        milestones = config.get("streak_milestone_bonuses", {})
        
        # Get current streak and last claim date
        current_streak, last_claim_date = await self.get_daily_streak(user_id, guild_id)
        now = datetime.now(timezone.utc)
        
        # Check if streak should reset (missed a day)
        if last_claim_date:
            # Calculate days since last claim
            days_diff = (now.date() - last_claim_date.date()).days
            if days_diff > 1:  # Missed more than 1 day
                streak = 1  # Reset streak
            else:
                streak = min(current_streak + 1, max_streak)  # Continue streak
        else:
            streak = 1  # First time claiming
        
        await self.update_daily_streak(user_id, guild_id, streak)
        
        # Calculate reward
        base_reward = random.randint(base_min, base_max)
        streak_reward = streak * streak_bonus
        
        # Character bonus
        character = await self.get_user_character(user_id, guild_id)
        char_bonus = 0
        if character:
            char_bonuses = config.get("character_bonuses", {}).get(character, {})
            char_bonus = char_bonuses.get("base_bonus", 0)
        
        # Milestone bonus
        milestone_bonus = milestones.get(str(streak), 0)
        
        total_reward = base_reward + streak_reward + char_bonus + milestone_bonus
        
        await self.quest_data.add_balance(user_id, guild_id, total_reward)
        await self.set_cooldown(user_id, "claim", guild_id)
        
        new_balance = await self.quest_data.get_balance(user_id, guild_id)
        
        embed = discord.Embed(
            title="🎁 Daily Claimed!",
            color=discord.Color.gold()
        )
        
        breakdown = f"Base: +{base_reward}\nStreak ({streak}d): +{streak_reward}"
        if char_bonus > 0:
            breakdown += f"\n{character}: +{char_bonus}"
        if milestone_bonus > 0:
            breakdown += f"\n🏆 Milestone: +{milestone_bonus}"
        
        embed.add_field(name="💰 Reward", value=f"**+{total_reward}** pts\n-# {breakdown}", inline=True)
        embed.add_field(name="💳 Balance", value=f"**{new_balance:,}** pts", inline=True)
        embed.add_field(name="🔥 Streak", value=f"**{streak}** days", inline=True)
        
        if milestone_bonus > 0:
            embed.set_footer(text=f"🎉 {streak}-day milestone bonus!")
        
        await ctx.reply(embed=embed, mention_author=False)
    
    @commands.command(name="stats", aliases=["me"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def stats_command(self, ctx, member: discord.Member = None):
        """📊 View your profile card with game stats!"""
        target = member or ctx.author
        guild_id = str(ctx.guild.id)
        user_id = str(target.id)
        
        # Get user data
        balance = await self.quest_data.get_balance(user_id, guild_id)
        
        # Get job info
        current_job_id = await self.get_user_job(user_id, guild_id)
        job_data = self.get_job_by_id(current_job_id) if current_job_id else None
        job_title = job_data.get("title") if job_data else None
        job_emoji = job_data.get("emoji", "💼") if job_data else "💼"
        
        # Get streak
        daily_streak, _ = await self.get_daily_streak(user_id, guild_id)
        
        # Get total earned and games played from database
        total_earned = 0
        total_games = 0
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            server_data = await server_col.find_one({"guild_id": guild_id})
            if server_data and "members" in server_data:
                member_data = server_data["members"].get(user_id, {})
                total_earned = member_data.get("total_stars_earned", 0)
                # Sum up game plays
                game_plays = member_data.get("daily_game_plays", {})
                for game_type, plays in game_plays.items():
                    if isinstance(plays, int):
                        total_games += plays
        except Exception as e:
            logger.error(f"Error fetching stats: {e}")
        
        # Generate profile card
        avatar_url = target.display_avatar.with_size(128).url
        
        img_buffer = await generate_profile_card(
            user_name=target.display_name,
            avatar_url=avatar_url,
            balance=balance,
            job_title=job_title,
            job_emoji=job_emoji,
            daily_streak=daily_streak,
            total_games=total_games,
            total_earned=total_earned
        )
        
        file = discord.File(img_buffer, filename="profile.png")
        
        embed = discord.Embed(color=discord.Color.blurple())
        embed.set_image(url="attachment://profile.png")
        embed.set_footer(text=f"Use {ctx.prefix}stats @user to view someone else's profile")
        
        await ctx.reply(embed=embed, file=file, mention_author=False)
    
    # ═══════════════════════════════════════════════════════════════
    # ERROR HANDLERS
    # ═══════════════════════════════════════════════════════════════
    
    @hangman_game.error
    @wordle_game.error
    @jobs_command.error
    @work_command.error
    @rob_command.error
    @claim_command.error
    async def game_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            embed = discord.Embed(
                title="⏳ Cooldown",
                description=f"Please wait **{error.retry_after:.1f}s** before playing again!",
                color=discord.Color.orange()
            )
            await ctx.reply(embed=embed, mention_author=False)
        elif isinstance(error, commands.BadArgument):
            embed = discord.Embed(
                title="❌ Invalid Input",
                description="Please enter valid numbers!",
                color=discord.Color.red()
            )
            await ctx.reply(embed=embed, mention_author=False)
        elif isinstance(error, commands.MemberNotFound):
            await ctx.reply("❌ Member not found!", mention_author=False)

    @commands.group(name="reaction", aliases=["rea"], invoke_without_command=True)
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def reaction_group(self, ctx):
        """🧠 Reaction game - Remember the emoji! Matches get harder as you streak!"""
        
        # Get streak for difficulty scaling
        reaction_data = Reaction_Data()
        streak_doc = await reaction_data.mongo.streaks.find_one({"user_id": ctx.author.id, "guild_id": ctx.guild.id})
        streak = streak_doc.get("streak", 0) if streak_doc else 0
        
        # Difficulty Scaling
        # Base time: 10s. Reduces by 0.5s every streak point. Min 2.5s.
        base_time = 10
        param = streak * 0.5
        play_time = max(2.5, base_time - param)
        
        emojis = ["😀","😊","😂","😍","😎","😢","😠","😱","😡","😐","🥳","😏","🙃","😇","😅","😜","😌","😋"]
        shuffled = emojis * 2
        random.shuffle(shuffled)
        chosen = random.choice(emojis)
        
        if not hasattr(self, 'correct_emojis'):
            self.correct_emojis = {}
        self.correct_emojis[ctx.channel.id] = chosen

        embed = discord.Embed(
            description=f"```Remember this emoji: {chosen}```\n\nStreak: **{streak}**\nTime: **{play_time:.1f}s**",
            color=primary_color()
        )
        msg = await ctx.reply(embed=embed, mention_author=False)
        await asyncio.sleep(2)

        view = Reaction(ctx, shuffled, chosen, msg, self.bot)
        future = int((datetime.now(timezone.utc) + timedelta(seconds=play_time)).timestamp())
        
        def timestamp_gen(ts: int) -> str:
            return f"<t:{int(ts)}:R>"
        
        embed = discord.Embed(
            description=f"React with the emoji you remembered.\n`Remaining Time:` {timestamp_gen(future)}",
            color=primary_color(),
        )
        
        try:
            await msg.edit(embed=embed, view=view)
            
            # Wait for user input or timeout
            # We use view.wait() which returns True if stopped (answered), or None if timeout (if view has timeout)
            # But we want custom timeout based on difficulty.
            
            passed = await asyncio.wait_for(view.wait(), timeout=play_time)
            
            if passed:
            # View likely resets on wrong answer, but here we enforce timeout reset)
            # Safest is to let View handle it if possible, but we can force reset here.
            await reaction_data.mongo.streaks.delete_one({"user_id": ctx.author.id, "guild_id": ctx.guild.id})
    
    @reaction_group.command(name="leaderboard", aliases=["lb"])
    async def reaction_leaderboard(self, ctx):
        """🏆 View reaction streak leaderboard"""
        
        reaction_data = Reaction_Data()
        
        try:
            # Get all users with streak data for this guild
            pipeline = [
                {"$match": {"guild_id": ctx.guild.id}},
                {"$project": {"user_id": "$user_id", "streak": "$streak"}},
                {"$sort": {"streak": -1}},
                {"$limit": 10}
            ]
            
            cursor = reaction_data.mongo.highscores.aggregate(pipeline)
            top_players = await cursor.to_list(length=10)
            
            if not top_players:
                embed = discord.Embed(
                    title="🏆 Reaction Streak Leaderboard",
                    description="No streak data found! Play `.reaction` to set a streak!",
                    color=discord.Color.orange()
                )
                return await ctx.reply(embed=embed, mention_author=False)
            
            embed = discord.Embed(
                title="🏆 Reaction Streak Leaderboard",
                description="Top reaction game streaks in this server!",
                color=discord.Color.orange()
            )
            
            user_in_top = False
            for i, player in enumerate(top_players, 1):
                user_id = player["user_id"]
                streak = player["streak"]
                
                if str(user_id) == str(ctx.author.id):
                    user_in_top = True
                
                try:
                    user = ctx.guild.get_member(int(user_id))
                    username = user.display_name if user else f"User {user_id}"
                except:
                    username = f"User {user_id}"
                
                medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"#{i}"
                embed.add_field(
                    name=f"{medal} {username}",
                    value=f"Streak: **{streak}** 🔥",
                    inline=False
                )
            
            # Show user's rank if not in top 10
            if not user_in_top:
                user_score_doc = await reaction_data.mongo.highscores.find_one({"user_id": ctx.author.id, "guild_id": ctx.guild.id})
                if user_score_doc:
                    user_streak = user_score_doc.get("streak", 0)
                    # Calculate rank
                    rank = await reaction_data.mongo.highscores.count_documents({
                        "guild_id": ctx.guild.id, 
                        "streak": {"$gt": user_streak}
                    }) + 1
                    
                    embed.add_field(
                        name="────────────────",
                        value=f"**Your Rank:** #{rank}\n**Streak:** {user_streak} 🔥",
                        inline=False
                    )
            
            embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
            await ctx.reply(embed=embed, mention_author=False)
            
        except Exception as e:
            logger.error(f"Error fetching reaction leaderboard: {e}")
            embed = discord.Embed(
                title="❌ Error",
                description="Failed to fetch leaderboard. Try again later.",
                color=discord.Color.red()
            )
            await ctx.reply(embed=embed, mention_author=False)
    
    # ═══════════════════════════════════════════════════════════════
    # COVER ART SYSTEM - .draw cover subcommands
    # ═══════════════════════════════════════════════════════════════

    @draw.group(name="cover", invoke_without_command=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def draw_cover_group(self, ctx, uid: str = None):
        """🎨 Browse cover art for your gacha characters with advanced filtering
        
        **Usage:**
        • `.draw cover <UID>` - Browse art by character UID
        
        **Features:**
        • 🔍 Filter by image source (Danbooru, Gelbooru, Yande.re, etc.)
        • 👁️ Switch between Gallery (3 images) and Single (1 image) view modes
        • ◀️ ▶️ Navigate through pages with prev/next buttons
        
        **Examples:**
        • `.draw cover F9D6E292`
        • `.draw cover anya forger`
        • `.draw cover delete F9D6E292 C421FAFA7CB8684D`
        
        **Image Sources:**
        • Safebooru, Danbooru, Gelbooru (Primary)
        • Yande.re, Konachan (High Quality)
        • TBIB, Anime-Pictures, Tumblr (Additional)
        """
        if not uid:
            embed = discord.Embed(
                title="🎨 Cover Art System",
                description="Browse and purchase beautiful cover art for your characters!\n\n"
                           "**Usage:**\n"
                           f"• `{ctx.prefix}draw cover <UID or name>` - Browse art for your character\n"
                           f"• `{ctx.prefix}draw cover buy <UID> <code_hex>` - Buy art using the code shown\n"
                           f"• `{ctx.prefix}draw cover delete <UID> <cover_id>` - Delete cover art for 10% refund\n\n"
                           "**Features:**\n"
                           "• 🛒 **Safe Buying** - Use unique codes to buy exactly what you see\n"
                           "• 🎲 **Random Page** - Jump to a random page to find new art\n"
                           "• 🔍 **Source Filtering** - Filter by Danbooru, Gelbooru, Yande.re, and more\n"
                           "• 👁️ **View Modes** - Gallery (3 images) or Single (1 image) view\n"
                           "• 🗑️ **Deletion** - Delete unwanted cover art for 10% cash back\n\n"
                           "**Examples:**\n"
                           f"• `{ctx.prefix}draw cover F9D6E292`\n"
                           f"• `{ctx.prefix}draw cover buy F9D6E292 A1B2C3D4`\n"
                           f"• `{ctx.prefix}draw cover delete F9D6E292 C421FAFA7CB8684D`\n\n"
                           "**Image Sources:**\n"
                           "• Safebooru, Danbooru, Gelbooru (Primary)\n"
                           "• Yande.re, Konachan (High Quality)\n"
                           "• TBIB, Anime-Pictures, Tumblr (Additional)",
                color=discord.Color.purple()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        uid = uid.strip()
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        if not await self.check_cover_command_cooldown(ctx):
            return
        
        logger.info(f"[Cover Gallery] User {user_id} searching for: {uid}")
        char = await self._get_character_from_inventory(user_id, guild_id, uid)
        if not char:
            logger.debug(f"[Cover Gallery] UID search failed, trying name search for: {uid}")
            char = await self._get_character_from_name(user_id, guild_id, uid)
            if not char:
                logger.warning(f"[Cover Gallery] No character found with UID or name: {uid}")
                return await ctx.reply(f"❌ No character found with UID or name `{uid}`", mention_author=False)
        
        logger.info(f"[Cover Gallery] Found character: {char.get('name')} (UID: {char.get('uid')})")
        
        owner_id = await self._get_character_owner(guild_id, char['uid'])
        if owner_id != user_id:
            logger.warning(f"[Cover Gallery] User {user_id} doesn't own character {char.get('uid')}")
            return await ctx.reply("❌ You don't own this character!", mention_author=False)
        
        user_lock = self.get_user_lock(user_id)
        
        async with user_lock:
            await self.set_cover_command_status(user_id, True)
            
            try:
                wait_msg = await ctx.reply("🔍 Please wait, searching for cover art...", mention_author=False)
                char_name = char.get('name', '')
                series_name = char.get('anime', '')
                logger.info(f"[Cover Gallery] Search started - Character: '{char_name}' | Series: '{series_name}' | User: {user_id}")
                
                try:
                    # Fetch ALL cached images for this character (use large limit to get everything)
                    images, max_pages = await self.cover_art_system.search_cover_art(char_name, series_name, page=1, limit=99999, character_uid=char.get('uid'))
                    logger.info(f"[Cover Gallery] API returned {len(images) if images else 0} images, max_pages: {max_pages}")
                except Exception as search_error:
                    logger.error(f"[Cover Gallery] Search API error: {search_error}", exc_info=True)
                    images = []
                    max_pages = 0
                
                try:
                    await wait_msg.delete()
                except:
                    pass
                
                if not images:
                    logger.warning(f"[Cover Gallery] No images found for '{char_name}' from '{series_name}'")
                    await ctx.reply(f"❌ No cover art found for **{char_name}**!", mention_author=False)
                    return
                
                logger.info(f"[Cover Gallery] Successfully found {len(images)} images for '{char_name}'")
                
                # Create initial embeds (gallery mode, 3 images)
                embeds = await self.cover_art_system.create_cover_art_embeds(char, images[:3], page=1, total_pages=max_pages)
                
                # Give Discord time to process/cache image URLs before sending
                await asyncio.sleep(0.15)
                
                # Create advanced view with ALL images for filtering
                view = CoverGalleryView(self.cover_art_system, char, user_id, guild_id, images, current_page=1, total_pages=max_pages)
                
                msg = await ctx.reply(embeds=embeds, view=view, mention_author=False)
                view.message = msg
                
            except asyncio.TimeoutError:
                logger.error(f"[Cover Gallery] Timeout for user {user_id} searching '{char_name}'")
                await ctx.reply("⏰ Search timed out! The servers might be busy. Please try again in a moment.", mention_author=False)
            except Exception as e:
                logger.error(f"[Cover Gallery] Unexpected error for user {user_id}: {e}", exc_info=True)
                await ctx.reply(f"❌ Error loading cover art gallery! Please try again.\n*Debug: {str(e)[:100]}*", mention_author=False)
            finally:
                await self.set_cover_command_status(user_id, False)
    
    @draw_cover_group.command(name="gallery", aliases=["browse", "shop"])
    async def cover_gallery(self, ctx, *, query: str = None):
        """🖼️ Browse and buy cover art for your character
        
        **Usage:**
        • `.cover gallery <UID>` - Use character UID
        • `.cover gallery <character name>` - Search by name
        
        **Examples:**
        • `.cover gallery F9D6E292`
        • `.cover gallery anya forger`
        """
        if not query:
            return await ctx.reply(
                f"Usage: `{ctx.prefix}cover gallery <UID or character name>`\n"
                "Examples:\n"
                "• `.cover gallery F9D6E292`\n"
                "• `.cover gallery anya forger`",
                mention_author=False
            )
        
        uid = query.strip()
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Check if user is already running a command
        if not await self.check_cover_command_cooldown(ctx):
            return
        
        logger.info(f"[Cover Gallery] User {user_id} searching for: {uid}")
        char = await self._get_character_from_inventory(user_id, guild_id, uid)
        if not char:
            logger.debug(f"[Cover Gallery] UID search failed, trying name search for: {uid}")
            char = await self._get_character_from_name(user_id, guild_id, uid)
            if not char:
                logger.warning(f"[Cover Gallery] No character found with UID or name: {uid}")
                return await ctx.reply(f"❌ No character found with UID or name `{uid}`", mention_author=False)
        
        logger.info(f"[Cover Gallery] Found character: {char.get('name')} (UID: {char.get('uid')})")
        
        # Check if user owns the character
        owner_id = await self._get_character_owner(guild_id, char['uid'])
        if owner_id != user_id:
            logger.warning(f"[Cover Gallery] User {user_id} doesn't own character {char.get('uid')}")
            return await ctx.reply("❌ You don't own this character!", mention_author=False)
        
        # Get user-specific lock for queuing
        user_lock = self.get_user_lock(user_id)
        
        async with user_lock:
            # Set active status
            await self.set_cover_command_status(user_id, True)
            
            try:
                # Send please wait message
                wait_msg = await ctx.reply("🔍 Searching for cover art... This may take a moment!", mention_author=False)
                char_name = char.get('name', '')
                series_name = char.get('anime', '')
                logger.info(f"[Cover Gallery] Search started - Character: '{char_name}' | Series: '{series_name}' | User: {user_id}")
                
                # Get owned hashes for filtering
                try:
                    user_arts = await self.cover_art_system._get_user_cover_arts(user_id, guild_id)
                    char_uid = char.get('uid')
                    owned_hashes = {art.get('image_hash') for art in user_arts if art.get('character_uid') == char_uid and art.get('image_hash')}
                except:
                    owned_hashes = set()

                # Search for cover art - fetch 100 images for better pagination
                try:
                    images, max_pages = await self.cover_art_system.search_cover_art(char_name, series_name, page=1, limit=100, character_uid=char.get('uid'), owned_hashes=owned_hashes)
                    logger.info(f"[Cover Gallery] API returned {len(images) if images else 0} images, max_pages: {max_pages}")
                except Exception as search_error:
                    logger.error(f"[Cover Gallery] Search API error: {search_error}", exc_info=True)
                    images = []
                    max_pages = 0
                
                # Delete wait message
                try:
                    await wait_msg.delete()
                except:
                    pass
                
                if not images:
                    logger.warning(f"[Cover Gallery] No images found for '{char_name}' from '{series_name}'")
                    await ctx.reply(f"❌ No cover art found for **{char_name}**!\n*Try using `.cover search {char_name}` to preview available art.*", mention_author=False)
                    return
                
                logger.info(f"[Cover Gallery] Successfully found {len(images)} images for '{char_name}'")
                
                # Create 3 separate embeds
                embeds = await self.cover_art_system.create_cover_art_embeds(char, images, page=1, total_pages=max_pages)
                
                # Create view with Select dropdown for buying
                view = CoverGalleryView(self.cover_art_system, char, user_id, guild_id, images, current_page=1, total_pages=max_pages)
                
                msg = await ctx.reply(embeds=embeds, view=view, mention_author=False)
                view.message = msg
                
            except asyncio.TimeoutError:
                logger.error(f"[Cover Gallery] Timeout for user {user_id} searching '{char_name}'")
                await ctx.reply("⏰ Search timed out! The servers might be busy. Please try again in a moment.", mention_author=False)
            except Exception as e:
                logger.error(f"[Cover Gallery] Unexpected error for user {user_id}: {e}", exc_info=True)
                await ctx.reply(f"❌ Error loading cover art gallery! Please try again.\n*Debug: {str(e)[:100]}*", mention_author=False)
            finally:
                # Clear active status
                await self.set_cover_command_status(user_id, False)
    
    @draw_cover_group.command(name="search")
    async def cover_search(self, ctx, *, query: str = None):
        """🔍 Search for cover art (preview only)
        
        **Format Examples:**
        • .cover search anya forger
        • .cover search emilia | re:zero
        • .cover search rem | re:zero
        • .cover search kohaku | dr. stone
        
        Use | to separate character name from series (optional)
        """
        if not query:
            return await ctx.reply(
                f"Usage: `{ctx.prefix}cover search <character name> [| series]`\n"
                "Examples:\n"
                "• `.cover search anya forger`\n"
                "• `.cover search emilia | re:zero`\n"
                "• `.cover search rem | re:zero`",
                mention_author=False
            )
        
        # Parse query - use | as separator for series
        if "|" in query:
            parts = query.split("|", 1)
            character_name = parts[0].strip()
            series_name = parts[1].strip() if len(parts) > 1 else None
        else:
            character_name = query.strip()
            series_name = None
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Check if user is already running a command
        if not await self.check_cover_command_cooldown(ctx):
            return
        
        # Get user-specific lock for queuing
        user_lock = self.get_user_lock(user_id)
        
        async with user_lock:
            # Set active status
            await self.set_cover_command_status(user_id, True)
            
            try:
                # Send please wait message
                wait_msg = await ctx.reply("🔍 Searching for cover art... This may take a moment!", mention_author=False)
                logger.info(f"Cover art search started for user {user_id} - '{character_name}' from '{series_name or 'Any series'}'")
                
                # Search for cover art using proper format
                images, max_pages = await self.cover_art_system.search_cover_art(character_name, series_name, page=1, limit=9)
                
                # Delete wait message
                try:
                    await wait_msg.delete()
                except:
                    pass
                
                if not images:
                    # Try fallback search without series if no results
                    if series_name:
                        logger.info(f"[Cover Search] No results with series, trying without series")
                        images, max_pages = await self.cover_art_system.search_cover_art(character_name, None, page=1, limit=9)
                
                if not images:
                    await ctx.reply(
                        f"❌ No cover art found for **{character_name}**!\n"
                        f"*Try: `.cover search {character_name.lower()}` or check spelling*",
                        mention_author=False
                    )
                    return
                
                logger.info(f"[Cover Search] Found {len(images)} images for '{character_name}'")
                
                # Create single clean embed with image grid
                embed = discord.Embed(
                    title=f"🔍 {character_name}",
                    description=f"*{series_name or 'Various Series'}* • Page 1/{max_pages}\n"
                                f"Found **{len(images)}** images from multiple sources",
                    color=discord.Color.purple()
                )
                
                # Show first 3 images as thumbnails in description
                for i, img in enumerate(images[:3], 1):
                    embed.add_field(
                        name=f"🖼️ Option {i}",
                        value=f"**ID:** `{img['id']}`\n"
                              f"**Source:** {img['source']}\n"
                              f"**Score:** {img['score']} • {img['width']}x{img['height']}",
                        inline=True
                    )
                
                # Set first image as main display
                if images[0].get('preview_url'):
                    embed.set_image(url=images[0]['preview_url'])
                
                embed.set_footer(text="Use .cover gallery <UID> to purchase for your character")
                
                # Create view with clean button layout
                view = CoverArtSearchView(
                    self.cover_art_system,
                    {"name": character_name, "anime": series_name or "Unknown", "uid": "SEARCH"},
                    user_id,
                    guild_id,
                    images,
                    current_page=1,
                    total_pages=max_pages
                )
                
                msg = await ctx.reply(embed=embed, view=view, mention_author=False)
                view.message = msg
                
            except asyncio.TimeoutError:
                logger.error(f"Cover art search timeout for user {user_id}")
                await ctx.reply("⏰ Search timed out! The servers might be busy. Please try again in a moment.", mention_author=False)
            except Exception as e:
                logger.error(f"Error in cover search: {e}")
                await ctx.reply("❌ Error searching for cover art! Please try again.", mention_author=False)
            finally:
                # Clear active status
                await self.set_cover_command_status(user_id, False)
    
    @draw_cover_group.command(name="collection", aliases=["c"])
    async def cover_collection(self, ctx, *, uid: str = None):
        """🖼️ View your cover art collection for a character with pagination
        
        **Usage:**
        • `.draw cover collection <UID>` - View cover art collection
        • `.draw cover c <UID>` - Short version
        
        **Features:**
        • 📖 Paginated view (3 images per page)
        • 🔢 Navigate with buttons
        • 🎨 Beautiful gallery layout
        
        **Examples:**
        • `.draw cover collection 9C231F46`
        • `.draw cover c 9C231F46`
        """
        if not uid:
            return await ctx.reply(
                f"Usage: `{ctx.prefix}draw cover collection <UID>`\n"
                f"Short version: `{ctx.prefix}draw cover c <UID>`\n\n"
                "Examples:\n"
                "• `.draw cover collection 9C231F46`\n"
                "• `.draw cover c 9C231F46`",
                mention_author=False
            )
        
        uid = uid.strip()
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Check if user is already running a command
        if not await self.check_cover_command_cooldown(ctx):
            return
        
        logger.info(f"[Cover Collection] User {user_id} viewing collection for: {uid}")
        char = await self._get_character_from_inventory(user_id, guild_id, uid)
        if not char:
            logger.debug(f"[Cover Collection] UID search failed, trying name search for: {uid}")
            char = await self._get_character_from_name(user_id, guild_id, uid)
            if not char:
                logger.warning(f"[Cover Collection] No character found with UID or name: {uid}")
                return await ctx.reply(f"❌ No character found with UID or name `{uid}`", mention_author=False)
        
        logger.info(f"[Cover Collection] Found character: {char.get('name')} (UID: {char.get('uid')})")
        
        # Check if user owns the character
        owner_id = await self._get_character_owner(guild_id, char['uid'])
        if owner_id != user_id:
            logger.warning(f"[Cover Collection] User {user_id} doesn't own character {char.get('uid')}")
            return await ctx.reply("❌ You don't own this character!", mention_author=False)
        
        # Fetch cover art data from characters collection and merge it
        char_uid_lower = char['uid'].lower()
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.characters.{char_uid_lower}": 1}
            )
            
            if result:
                char_data = result.get("members", {}).get(user_id, {}).get("characters", {}).get(char_uid_lower, {})
                # Merge cover art data into character object
                if char_data.get('cover_unlocked'):
                    char['cover_unlocked'] = char_data['cover_unlocked']
                    char['cover_art'] = char_data.get('cover_art', {})
                    if 'cover_collection' in char_data:
                        char['cover_collection'] = char_data['cover_collection']
                    logger.info(f"[Cover Collection] Merged cover art data for character {char['uid']}")
        except Exception as e:
            logger.error(f"[Cover Collection] Error fetching cover art data: {e}")
        
        # Check if character has cover art unlocked
        if not char.get('cover_unlocked', False):
            return await ctx.reply(
                f"❌ **{char.get('name', 'Unknown')}** doesn't have any cover art yet!\n"
                f"Use `{ctx.prefix}draw cover gallery {char.get('uid')}` to browse and purchase cover art.",
                mention_author=False
            )
        
        # Get user-specific lock for queuing
        user_lock = self.get_user_lock(user_id)
        
        async with user_lock:
            # Set active status
            await self.set_cover_command_status(user_id, True)
            
            try:
                # Create collection view with pagination
                view = CoverCollectionView(
                    self.cover_art_system,
                    char,
                    user_id,
                    guild_id,
                    current_page=1
                )
                
                # Get initial embeds
                embeds = await view.get_current_embeds()
                
                if not embeds:
                    await ctx.reply("❌ No cover art found for this character!", mention_author=False)
                    return
                
                msg = await ctx.reply(embeds=embeds, view=view, mention_author=False)
                view.message = msg
            except Exception as e:
                logger.error(f"[Cover Collection] Error for user {user_id}: {e}", exc_info=True)
                await ctx.reply("❌ Error loading cover art collection! Please try again.", mention_author=False)
            finally:
                # Clear active status
                await self.set_cover_command_status(user_id, False)

    @draw_cover_group.command(name="buy", aliases=["purchase"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def cover_buy(self, ctx, uid: str = None, hex_code: str = None):
        """🛒 Purchase cover art using its unique hex code
        
        **Usage:**
        • `.draw cover buy <UID> <hex_code>` - Purchase cover art by hex code
        
        **Examples:**
        • `.draw cover buy F9D6E292 A1B2C3D4`
        • `.draw cover buy BE1677D1 8F3E2A1C`
        
        **How to get the hex code:**
        1. Use `.draw cover <UID>` to browse cover art
        2. Each image shows its unique 8-character hex code
        3. Use this command with that code to purchase
        """
        if not uid or not hex_code:
            embed = discord.Embed(
                title="🛒 Buy Cover Art",
                description="Purchase cover art using its unique hex code.\n\n"
                           "**Usage:**\n"
                           f"• `{ctx.prefix}draw cover buy <UID> <hex_code>`\n\n"
                           "**Examples:**\n"
                           f"• `{ctx.prefix}draw cover buy F9D6E292 A1B2C3D4`\n"
                           f"• `{ctx.prefix}draw cover buy BE1677D1 8F3E2A1C`\n\n"
                           "**How to get the code:**\n"
                           "Each image in the gallery shows a unique 8-character hex code.\n"
                           "Copy that code and use it with this command!",
                color=discord.Color.blue()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        uid = uid.strip().upper()
        hex_code = hex_code.strip().upper()
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Validate hex code format (8 hex characters)
        if len(hex_code) != 8 or not all(c in '0123456789ABCDEF' for c in hex_code):
            return await ctx.reply(
                f"❌ Invalid hex code `{hex_code}`! Must be exactly 8 characters (0-9, A-F).\n"
                f"Use `{ctx.prefix}draw cover {uid}` to browse and find valid codes.",
                mention_author=False
            )
        
        # Get character from inventory
        char = await self._get_character_from_inventory(user_id, guild_id, uid)
        if not char:
            char = await self._get_character_from_name(user_id, guild_id, uid)
            if not char:
                return await ctx.reply(f"❌ No character found with UID or name `{uid}`", mention_author=False)
        
        # Check ownership
        owner_id = await self._get_character_owner(guild_id, char['uid'])
        if owner_id != user_id:
            return await ctx.reply("❌ You don't own this character!", mention_author=False)
        
        try:
            # Attempt purchase
            success, message, purchase_data = await self.cover_art_system.purchase_cover_art_by_hex(
                user_id, guild_id, char['uid'], hex_code
            )
            
            if success:
                # Create success embed
                embed = discord.Embed(
                    title="✅ Cover Art Purchased!",
                    description=f"**{char.get('name')}** • `{char.get('uid').upper()}`",
                    color=discord.Color.green()
                )
                
                embed.add_field(
                    name="Purchase Details",
                    value=f"• **Cost:** {purchase_data.get('cost', 0)} pts\n"
                          f"• **Code:** `{hex_code}`\n"
                          f"• **ID:** `{purchase_data.get('unique_id', 'N/A')}`",
                    inline=False
                )
                
                if purchase_data.get('image_url'):
                    embed.set_thumbnail(url=purchase_data['image_url'])
                
                embed.set_footer(text=f"Use .draw covers {char['uid'].upper()} to view your collection!")
                
                await ctx.reply(embed=embed, mention_author=False)
            else:
                await ctx.reply(f"{message}", mention_author=False)
                
        except Exception as e:
            logger.error(f"Error in cover buy command: {e}", exc_info=True)
            await ctx.reply("❌ Error processing purchase! Please try again.", mention_author=False)

    @draw_cover_group.command(name="delete", aliases=["remove", "del"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def cover_delete(self, ctx, uid: str, cover_id: str):
        """🗑️ Delete cover art for 10% cash back refund
        
        **Usage:**
        • `.draw cover delete <UID> <cover_id>` - Delete specific cover art
        
        **Examples:**
        • `.draw cover delete F9D6E292 C421FAFA7CB8684D`
        • `.draw cover delete F9D6E292 12345678`
        
        **Features:**
        • 10% cash back refund of original purchase price
        • Permanent deletion - cannot be recovered
        • Works with both custom names and IDs
        """
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Validate inputs
        uid = uid.strip().upper()
        cover_id = cover_id.strip().upper()
        
        if not uid or not cover_id:
            return await ctx.reply(
                f"❌ Usage: `{ctx.prefix}draw cover delete <UID> <cover_id>`\n"
                f"Example: `{ctx.prefix}draw cover delete F9D6E292 C421FAFA7CB8684D`",
                mention_author=False
            )
        
        try:
            # Check if user owns the character
            char = await self._get_character_from_inventory(user_id, guild_id, uid)
            if not char:
                return await ctx.reply(f"❌ No character found with UID `{uid}`", mention_author=False)
            
            # Get user's cover arts for this character
            user_arts = await self.cover_art_system._get_user_cover_arts_for_character(user_id, guild_id, uid)
            
            # Find the cover art to delete
            target_art = None
            for art in user_arts:
                # Check both 'id' (new format) and 'unique_id' (legacy) fields
                art_id = art.get('id', art.get('unique_id', '')).upper()
                art_custom_name = art.get('custom_name', '').upper()
                
                if art_id == cover_id or art_custom_name == cover_id:
                    target_art = art
                    break
            
            if not target_art:
                return await ctx.reply(
                    f"❌ No cover art found with ID `{cover_id}` for character `{char.get('name')}`\n"
                    f"Use `{ctx.prefix}draw cover collection {uid}` to see your cover art collection.",
                    mention_author=False
                )
            
            # Calculate refund (10% of original cost)
            original_cost = target_art.get('cost', 0)
            refund_amount = int(original_cost * 0.1)  # 10% refund
            
            if refund_amount <= 0:
                refund_amount = 10  # Minimum refund of 10 pts
            
            # Check if this is the active cover art
            is_active = target_art.get('selected', False)
            
            # Create confirmation embed
            embed = discord.Embed(
                title="🗑️ Confirm Cover Art Deletion",
                description=f"Are you sure you want to delete this cover art?",
                color=discord.Color.orange()
            )
            
            embed.add_field(name="Character", value=f"**{char.get('name')}** (`{uid}`)", inline=False)
            embed.add_field(name="Cover Art", value=f"ID: `{target_art.get('unique_id')}`", inline=False)
            embed.add_field(name="Refund", value=f"**{refund_amount}** stella points (10% of {original_cost})", inline=False)
            
            if is_active:
                embed.add_field(name="⚠️ Warning", value="This is your currently active cover art!", inline=False)
            
            embed.set_footer(text="This action cannot be undone!")
            
            # Add confirmation buttons
            view = DeleteConfirmationView(self.cover_art_system, user_id, guild_id, uid, target_art, refund_amount, is_active)
            
            await ctx.reply(embed=embed, view=view, mention_author=False)
            
        except Exception as e:
            logger.error(f"Error in cover delete command: {e}")
            await ctx.reply("❌ Error processing deletion request! Please try again.", mention_author=False)

    @draw.command(name="covers")
    async def draw_covers(self, ctx, *, uid: str = None):
        """🖼️ View your cover art collection for a character (alias for .draw cover collection)
        
        **Usage:**
        • `.draw covers <UID>` - View cover art collection
        
        **Examples:**
        • `.draw covers F9D6E292`
        • `.draw covers 9C231F46`
        
        **Features:**
        • Automatically scans for duplicate images
        • Generates hashes for images that don't have one
        • Removes duplicate cover art to clean up your inventory
        """
        # First, run duplicate detection and cleanup
        if uid:
            await self._scan_and_fix_duplicates(ctx, uid)
        
        # Then call the cover_collection command
        await ctx.invoke(self.cover_collection, uid=uid)
    
    async def _scan_and_fix_duplicates(self, ctx, uid: str):
        """Aggressively scan for duplicate cover art and remove them from database.
        Also removes images with bad aspect ratios (too wide for cards)."""
        import hashlib
        
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        
        # Get character
        char = await self._get_character_from_inventory(user_id, guild_id, uid)
        if not char:
            char = await self._get_character_from_name(user_id, guild_id, uid)
        if not char:
            return
        
        char_uid_lower = char['uid'].lower()
        
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.characters.{char_uid_lower}": 1}
            )
            
            if not result:
                return
            
            char_data = result.get("members", {}).get(user_id, {}).get("characters", {}).get(char_uid_lower, {})
            
            # Get all cover arts - handle both formats
            original_cover_arts = []
            if 'cover_collection' in char_data and isinstance(char_data['cover_collection'], list):
                original_cover_arts = list(char_data['cover_collection'])
            elif char_data.get('cover_art'):
                original_cover_arts = [char_data['cover_art']]
            
            if not original_cover_arts:
                return
            
            original_count = len(original_cover_arts)
            logger.info(f"[Duplicate Scan] Scanning {original_count} cover arts for {char_uid_lower}")
            
            # Track unique items using multiple identifiers
            seen_urls = set()
            seen_image_ids = set()
            unique_arts = []
            duplicates_removed = 0
            bad_ratio_removed = 0
            
            for art in original_cover_arts:
                is_duplicate = False
                is_bad_ratio = False
                
                # Get all possible identifiers
                image_url = art.get('image_url', '')
                image_id = art.get('image_id')
                width = art.get('width', 0)
                height = art.get('height', 0)
                
                # Check aspect ratio - remove wide/landscape images
                # Good ratio for cards: width/height <= 1.2 (portrait or square-ish)
                if width and height and width > height * 1.2:
                    is_bad_ratio = True
                    logger.info(f"[Duplicate Scan] Removing bad ratio image: {width}x{height} (ratio: {width/height:.2f})")
                
                # Check by URL first (most reliable)
                if not is_bad_ratio and image_url:
                    # Normalize URL for comparison
                    normalized_url = image_url.strip().lower()
                    if normalized_url in seen_urls:
                        is_duplicate = True
                        logger.info(f"[Duplicate Scan] Removing URL duplicate: {image_url[:60]}...")
                    else:
                        seen_urls.add(normalized_url)
                
                # Check by image_id
                if not is_duplicate and not is_bad_ratio and image_id is not None:
                    if image_id in seen_image_ids:
                        is_duplicate = True
                        logger.info(f"[Duplicate Scan] Removing image_id duplicate: {image_id}")
                    else:
                        seen_image_ids.add(image_id)
                
                if is_bad_ratio:
                    bad_ratio_removed += 1
                elif is_duplicate:
                    duplicates_removed += 1
                else:
                    # Keep this art, ensure it has a hash
                    if not art.get('image_hash') and image_url:
                        art['image_hash'] = hashlib.md5(image_url.encode()).hexdigest()
                    unique_arts.append(art)
            
            total_removed = duplicates_removed + bad_ratio_removed
            
            # Only update if we actually removed items
            if total_removed > 0:
                logger.info(f"[Duplicate Scan] Removed {duplicates_removed} duplicates, {bad_ratio_removed} bad ratio, keeping {len(unique_arts)}")
                
                # Force update the database with cleaned list
                await server_col.update_one(
                    {"guild_id": guild_id},
                    {"$set": {f"members.{user_id}.characters.{char_uid_lower}.cover_collection": unique_arts}}
                )
                
                # Notify user
                message_parts = ["**🧹 Cover Art Inventory Cleaned!**"]
                if duplicates_removed > 0:
                    message_parts.append(f"🗑️ Removed **{duplicates_removed}** duplicate(s)")
                if bad_ratio_removed > 0:
                    message_parts.append(f"📐 Removed **{bad_ratio_removed}** landscape/wide image(s)")
                message_parts.append(f"📦 You now have **{len(unique_arts)}** unique cover art(s)")
                
                await ctx.send("\n".join(message_parts), delete_after=15)
                logger.info(f"[Duplicate Scan] Successfully cleaned inventory for {char['uid']}")
            else:
                logger.info(f"[Duplicate Scan] No issues found for {char_uid_lower}")
        
        except Exception as e:
            logger.error(f"[Duplicate Scan] Error scanning for duplicates: {e}", exc_info=True)


    async def _get_character_from_inventory(self, user_id: str, guild_id: str, uid: str) -> Optional[Dict]:
        """Get character from user's inventory by UID"""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_inventory": 1}
            )
            
            if result:
                inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
                uid_upper = uid.upper()
                for char in inventory:
                    if char.get("uid", "").upper() == uid_upper:
                        return char
        except Exception as e:
            logger.error(f"Error getting character from inventory: {e}")
        
        return None
    
    async def _get_character_from_name(self, user_id: str, guild_id: str, name: str) -> Optional[Dict]:
        """Get character from user's inventory by name (case-insensitive)"""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {f"members.{user_id}.gacha_inventory": 1}
            )
            
            if result:
                inventory = result.get("members", {}).get(user_id, {}).get("gacha_inventory", [])
                name_lower = name.lower()
                for char in inventory:
                    char_name = char.get('name', '').lower()
                    # Match by exact name or partial match
                    if char_name == name_lower or name_lower in char_name:
                        return char
        except Exception as e:
            logger.error(f"Error getting character from name: {e}")
        
        return None
    
    async def _get_character_owner(self, guild_id: str, uid: str) -> Optional[str]:
        """Find who owns a character by UID"""
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            server_col = db["Servers"]
            
            result = await server_col.find_one(
                {"guild_id": guild_id},
                {"members": 1}
            )
            
            if result:
                members = result.get("members", {})
                uid_upper = uid.upper()
                for user_id, member_data in members.items():
                    inventory = member_data.get("gacha_inventory", [])
                    for char in inventory:
                        if char.get("uid", "").upper() == uid_upper:
                            return user_id
        except Exception as e:
            logger.error(f"Error finding character owner: {e}")
        
        return None


    # ═══ FISHING SYSTEM ═══
    async def get_fishing_inventory(self, user_id: str, guild_id: str) -> dict:
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            result = await db["Servers"].find_one({"guild_id": guild_id}, {f"members.{user_id}.fishing": 1})
            if result:
                fishing = result.get("members", {}).get(user_id, {}).get("fishing", {})
                if fishing:
                    return fishing
        except Exception as e:
            logger.error(f"Error getting fishing inventory: {e}")
        return {"bait": {}, "rod": "basic_rod", "rod_durability": 100, "hook": "rusty_hook"}
    
    async def save_fishing_inventory(self, user_id: str, guild_id: str, inventory: dict):
        try:
            db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
            await db["Servers"].update_one({"guild_id": guild_id}, {"$set": {f"members.{user_id}.fishing": inventory}}, upsert=True)
        except Exception as e:
            logger.error(f"Error saving fishing inventory: {e}")
    
    async def damage_rod(self, user_id: str, guild_id: str, damage: int) -> tuple:
        inventory = await self.get_fishing_inventory(user_id, guild_id)
        new_dur = max(0, inventory.get("rod_durability", 100) - damage)
        inventory["rod_durability"] = new_dur
        if new_dur <= 0:
            inventory["rod"] = None
        await self.save_fishing_inventory(user_id, guild_id, inventory)
        return new_dur, new_dur <= 0

    @commands.command(name="fish", aliases=["fishing"])
    async def fish_cmd(self, ctx, bait: str = None):
        """🎣 Go fishing! Rod breaks on fails. Limited to 5 fish per hour."""
        user_id, guild_id = str(ctx.author.id), str(ctx.guild.id)
        
        # Check if user has reached fish session limit (similar to gacha)
        fish_config = get_timer_config("fish")
        max_fish = fish_config["max_uses"]
        session_uses = await self.get_fish_session_uses(user_id, guild_id)
        
        if session_uses >= max_fish:
            # Check remaining cooldown time
            remaining = await self.check_cooldown(user_id, "fish_main", fish_config["cooldown"], guild_id)
            if remaining:
                wait_time = self.format_time(remaining)
                message = (
                    f"⏰ **Fishing is cooling down!** Wait **{wait_time}** before fishing again.\n"
                    f"> You've used all **{max_fish} fishing attempts** this session. Please wait to fish again."
                )
                return await ctx.reply(message, mention_author=False)
            else:
                # Cooldown expired, reset session
                await self.reset_fish_session(user_id, guild_id)
        
        inv = await self.get_fishing_inventory(user_id, guild_id)
        
        if not inv.get("rod"):
            embed = discord.Embed(
                title="🔧 Rod Broken!",
                description="You need a fishing rod to go fishing!\n\nBuy one from the shop:\n`.fishshop buy basic_rod`",
                color=discord.Color.red()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        if not inv.get("bait"):
            embed = discord.Embed(
                title="🎣 No Bait!",
                description="You need bait to go fishing!\n\nBuy bait from the shop:\n`.fishshop` - View available items\n`.fishshop buy worms 10` - Buy 10 worms (100 pts)\n\n💡 **Starter Tip:** Worms are cheap and work great for common fish!",
                color=discord.Color.orange()
            )
            return await ctx.reply(embed=embed, mention_author=False)
        
        bait = bait.lower() if bait else list(inv["bait"].keys())[0]
        if bait not in inv.get("bait", {}) or inv["bait"].get(bait, 0) <= 0:
            return await ctx.reply(f"❌ No **{bait}**!", mention_author=False)
        
        inv["bait"][bait] -= 1
        if inv["bait"][bait] <= 0:
            del inv["bait"][bait]
        await self.save_fishing_inventory(user_id, guild_id, inv)
        
        # Get equipment data for display
        rod_key = inv.get("rod", "basic_rod")
        rod_data = FISHING_SHOP.get(rod_key, FISHING_SHOP["basic_rod"])
        rod_durability = inv.get("rod_durability", 100)
        rod_max = rod_data.get("max_durability", 100)
        
        hook_key = inv.get("hook", "rusty_hook")
        hook_data = FISHING_SHOP.get(hook_key, FISHING_SHOP["rusty_hook"])
        
        bait_data = FISHING_SHOP.get(bait, {})
        
        # Get user stats
        db = self.quest_data.mongoConnect[self.quest_data.DB_NAME]
        result = await db["Servers"].find_one({"guild_id": guild_id}, {f"members.{user_id}.fishing_stats": 1})
        fishing_stats = result.get("members", {}).get(user_id, {}).get("fishing_stats", {"caught": 0, "species": 0}) if result else {"caught": 0, "species": 0}
        
        # Calculate bait remaining
        bait_count = sum(inv.get("bait", {}).values())
        
        view = FishingGameView(self, ctx.author, guild_id, bait, inv)
        embed = discord.Embed(
            title="🎣 Fishing Adventure",
            description="Cast your line into the waters and see what you catch!\n\nPress 🎣 Cast Line to begin!",
            color=0x3498db
        )
        
        # Equipment column
        equipment_text = (
            f"🎣 **{rod_data['name']}**\n"
            f"⚙️ **Hook:** {hook_data['name']}\n"
            f"{bait_data.get('emoji', '🪱')} **Bait:** {bait_data.get('name', bait)} ({bait_count} left)"
        )
        embed.add_field(name="Equipment", value=equipment_text, inline=True)
        
        # Stats column
        stats_text = (
            f"📊 **Caught:** {fishing_stats.get('caught', 0)}\n"
            f"🐟 **Species:** {fishing_stats.get('species', 0)}/22\n"
            f"✅ **Progress:** {(fishing_stats.get('species', 0) / 22 * 100):.1f}%"
        )
        embed.add_field(name="Your Stats", value=stats_text, inline=True)
        
        # Active bonuses
        bonuses_text = (
            f"✨ +{rod_data.get('catch_bonus', 0)}% rewards\n"
            f"⚖️ +{rod_data.get('weight_bonus', 0)}% weight"
        )
        embed.add_field(name="Active Bonuses", value=bonuses_text, inline=False)
        
        embed.set_footer(text=f"Better equipment = better catches! Use .fishshop to upgrade")
        view.message = await ctx.reply(embed=embed, view=view, mention_author=False)

    @commands.command(name="fishshop", aliases=["fs"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def fishshop_cmd(self, ctx, action: str = None, *, args: str = None):
# ... (rest of the code remains the same)
        """🏪 Buy fishing gear. Usage: .fishshop buy worms 10"""
        user_id, guild_id = str(ctx.author.id), str(ctx.guild.id)
        
        # Handle inventory subcommand
        if action and action.lower() in ["inv", "inventory", "i"]:
            return await self.show_fishing_inventory(ctx, user_id, guild_id)
        
        if action and action.lower() == "buy" and args:
            parts = args.split()
            amount = int(parts[-1]) if parts[-1].isdigit() else 1
            item_name = "_".join(parts[:-1] if parts[-1].isdigit() else parts).lower()
            item_key = next((k for k in FISHING_SHOP if k == item_name), None)
            if not item_key:
                return await ctx.reply(f"❌ Item not found!", mention_author=False)
            
            item = FISHING_SHOP[item_key]
            if item["type"] != "bait":
                amount = 1
            cost = item["price"] * amount
            bal = await self.quest_data.get_balance(user_id, guild_id)
            if bal < cost:
                embed = discord.Embed(
                    title="❌ Insufficient Funds",
                    description=f"You need **{cost:,}** pts but only have **{bal:,}** pts.\n\n💡 Earn more by fishing or completing quests!",
                    color=discord.Color.red()
                )
                return await ctx.reply(embed=embed, mention_author=False)
            
            await self.quest_data.add_balance(user_id, guild_id, -cost)
            inv = await self.get_fishing_inventory(user_id, guild_id)
            new_bal = bal - cost
            
            if item["type"] == "bait":
                inv["bait"][item_key] = inv.get("bait", {}).get(item_key, 0) + amount
                await self.save_fishing_inventory(user_id, guild_id, inv)
                embed = discord.Embed(
                    title="✅ Purchase Successful!",
                    description=(
                        f"Bought **{amount}x** {item['emoji']} **{item['name']}**\n\n"
                        f"💰 **Cost:** {cost:,} pts\n"
                        f"📊 **Balance:** {new_bal:,} pts\n\n"
                        f"Use .fish to start fishing with your new equipment!"
                    ),
                    color=discord.Color.green()
                )
                return await ctx.reply(embed=embed, mention_author=False)
            
            elif item["type"] == "rod":
                old_rod = inv.get("rod")
                inv["rod"], inv["rod_durability"] = item_key, item["max_durability"]
                await self.save_fishing_inventory(user_id, guild_id, inv)
                embed = discord.Embed(
                    title="✅ Purchase Successful!",
                    description=(
                        f"**{item['emoji']} {item['name']}**\n\n"
                        f"💰 **Cost:** {cost:,} pts\n"
                        f"💵 **New Balance:** {new_bal:,} pts"
                    ),
                    color=discord.Color.green()
                )
                embed.add_field(name="Rod Stats", value=(
                        f"- Reward Bonus: **+{item.get('catch_bonus', 0)}%**\n"
                        f"- Weight Bonus: **+{item.get('weight_bonus', 0)}%**\n"
                        f"- Durability: **{item['max_durability']}/{item['max_durability']} HP**\n\n")
                       )
                embed.set_footer(text="Better equipment = better catches!")
                return await ctx.reply(embed=embed, mention_author=False)
            
            elif item["type"] == "hook":
                inv["hook"] = item_key
                await self.save_fishing_inventory(user_id, guild_id, inv)
                embed = discord.Embed(
                    title="✅ Purchase Successful!",
                    description=(
                        f"**{item['emoji']} {item['name']}**\n\n"
                        f"💰 **Cost:** {cost:,} pts\n"
                        f"💵 **New Balance:** {new_bal:,} pts"
                    ),
                    color=discord.Color.green()
                )
                embed.set_footer(text="Longer catch windows = easier catches!")
                return await ctx.reply(embed=embed, mention_author=False)
        
        # Show shop with exact format requested
        embed = discord.Embed(
            title="🏪 Fishing Shop",
            description=(
                "Buy bait and upgrade your equipment!\n\n"
                f"**Usage:** `{ctx.prefix}fishshop buy [item] [amount]`\n"
                f"**Example:** `{ctx.prefix}fishshop buy worms 10`"
            ),
            color=0x3498db
        )
        
        # Bait section
        bait_lines = []
        for k, v in FISHING_SHOP.items():
            if v["type"] == "bait":
                bait_lines.append(f"{v['emoji']} **{v['name']}** - {v['price']} pts/ea\n*{v.get('description', '')}*")
        embed.add_field(
            name="Bait (Consumable)",
            value="\n\n".join(bait_lines),
            inline=False
        )
        
        # Rods section
        rod_lines = []
        for k, v in FISHING_SHOP.items():
            if v["type"] == "rod":
                rod_lines.append(f"🎣 **{v['name']}** - {v['price']:,} pts\n*{v.get('description', '')}*")
        embed.add_field(
            name="Fishing Rods (Permanent)",
            value="\n\n".join(rod_lines),
            inline=False
        )
        
        # Hooks section
        hook_lines = []
        for k, v in FISHING_SHOP.items():
            if v["type"] == "hook" and v["price"] > 0:
                hook_lines.append(f"🪝 **{v['name']}** - {v['price']:,} pts\n*{v.get('description', '')}*")
        embed.add_field(
            name="Hooks (Permanent)",
            value="\n\n".join(hook_lines),
            inline=False
        )
        
        embed.set_footer(text=f"Better equipment = better catches! • Use {ctx.prefix}fishshop inv to view your equipment")
        await ctx.reply(embed=embed, mention_author=False)

    async def show_fishing_inventory(self, ctx, user_id: str, guild_id: str):
        """Show detailed fishing inventory with equipment status"""
        inv = await self.get_fishing_inventory(user_id, guild_id)
        bal = await self.quest_data.get_balance(user_id, guild_id)
        
        # Get equipment data
        rod_key = inv.get("rod", "basic_rod")
        rod_data = FISHING_SHOP.get(rod_key, FISHING_SHOP["basic_rod"])
        rod_durability = inv.get("rod_durability", 100)
        rod_max = rod_data.get("max_durability", 100)
        
        hook_key = inv.get("hook", "rusty_hook")
        hook_data = FISHING_SHOP.get(hook_key, FISHING_SHOP["rusty_hook"])
        
        # Calculate durability percentage and status
        dur_pct = (rod_durability / rod_max) * 100 if rod_max > 0 else 0
        if dur_pct > 75:
            dur_status = "🟢 Excellent"
            dur_bar = "████████░░"
        elif dur_pct > 50:
            dur_status = "🟡 Good"
            dur_bar = "██████░░░░"
        elif dur_pct > 25:
            dur_status = "🟠 Worn"
            dur_bar = "████░░░░░░"
        elif dur_pct > 0:
            dur_status = "🔴 Critical"
            dur_bar = "██░░░░░░░░"
        else:
            dur_status = "💀 Broken"
            dur_bar = "░░░░░░░░░░"
        
        # Estimate casts remaining
        avg_damage = 5  # Average rod damage per fish
        casts_remaining = max(0, rod_durability // avg_damage) if rod_durability > 0 else 0
        
        embed = discord.Embed(
            title="Fishing Equipment",
            description=f"**Balance:** {bal:,} pts",
            color=0x2ecc71
        )
        
        # Rod section
        rod_status = "**BROKEN** - Buy a new rod!" if rod_durability <= 0 else ""
        embed.add_field(
            name="Fishing Rod",
            value=(
                f"**{rod_data['name']}**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"**Durability:** {rod_durability}/{rod_max} HP\n"
                f"`[{dur_bar}]` {dur_pct:.0f}%\n"
                f"**Status:** {dur_status}\n"
                f"**Est. Casts Left:** ~{casts_remaining}\n\n"
                f"**Bonuses:**\n"
                f"• Reward: +{rod_data.get('catch_bonus', 0)}%\n"
                f"• Weight: +{rod_data.get('weight_bonus', 0)}%\n"
                f"{rod_status}"
            ),
            inline=False
        )
        
        # Hook section
        embed.add_field(
            name="Hook",
            value=(
                f"**{hook_data['name']}**\n"
                f"• Catch Window: +{hook_data.get('window_bonus', 0)}s"
            ),
            inline=True
        )
        
        # Bait section
        bait_inv = inv.get("bait", {})
        if bait_inv:
            bait_lines = []
            for bait_key, amount in bait_inv.items():
                bait_data = FISHING_SHOP.get(bait_key, {})
                if amount > 0:
                    bait_lines.append(f"**{bait_data.get('name', bait_key)}**: {amount}x")
            bait_text = "\n".join(bait_lines) if bait_lines else "*No bait - buy some!*"
        else:
            bait_text = "*No bait - buy some!*"
        
        embed.add_field(
            name="Bait Supply",
            value=bait_text,
            inline=True
        )
        
        # Tips based on status
        tips = []
        if rod_durability <= 0:
            tips.append("Your rod is broken! Buy a new one with `.fishshop buy basic_rod`")
        elif dur_pct <= 25:
            tips.append(f"Rod nearly broken! Consider buying a replacement.")
        if not bait_inv or all(v <= 0 for v in bait_inv.values()):
            tips.append("You need bait to fish! Try `.fishshop buy worms 10`")
        
        if tips:
            embed.add_field(name="Tips", value="\n".join(tips), inline=False)
        
        embed.set_footer(text=f"Use {ctx.prefix}fish to start fishing! • {ctx.prefix}fishshop to buy gear")
        await ctx.reply(embed=embed, mention_author=False)

  
class FishingGameView(discord.ui.View):
    def __init__(self, cog, user, guild_id, bait_id, inventory):
        super().__init__(timeout=60)
        self.cog, self.user, self.guild_id, self.bait_id, self.inventory = cog, user, guild_id, bait_id, inventory
        self.message, self.fish_appeared, self.caught, self.current_fish, self.fish_id, self.catch_task = None, False, False, None, None, None
        self.fish_weight = 0

    @discord.ui.button(label="Cast Line", style=discord.ButtonStyle.primary)
    async def cast_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            if interaction.user.id != self.user.id:
                return await interaction.response.send_message("Not yours!", ephemeral=True)
            button.disabled = True
            
            # Waiting embed
            wait_embed = discord.Embed(
                title="🎣 Casting Line...",
                description="Waiting for a bite...",
                color=0x3498db
            )
            await interaction.response.edit_message(embed=wait_embed, view=self)
            await asyncio.sleep(random.uniform(2, 5))
            if self.caught: return
            
            # Select fish based on bait
            bait_data = FISHING_SHOP.get(self.bait_id, {})
            fish_list = [(fid, fd, fd["spawn_rate"] * bait_data.get("rarity_bonus", {}).get(fd["rarity"], 1.0)) for fid, fd in FISH_DATABASE.items()]
            total = sum(f[2] for f in fish_list)
            roll, cum = random.random() * total, 0
            for fid, fd, rate in fish_list:
                cum += rate
                if roll < cum:
                    self.fish_id, self.current_fish = fid, fd
                    break
            
            # Calculate fish weight
            weight_range = self.current_fish.get("weight_range", (1.0, 5.0))
            rod_key = self.inventory.get("rod", "basic_rod")
            rod_data = FISHING_SHOP.get(rod_key, FISHING_SHOP["basic_rod"])
            weight_bonus = 1 + (rod_data.get("weight_bonus", 0) / 100)
            self.fish_weight = round(random.uniform(weight_range[0], weight_range[1]) * weight_bonus, 2)
            
            # Get catch window with hook bonus
            hook_key = self.inventory.get("hook", "rusty_hook")
            hook_data = FISHING_SHOP.get(hook_key, FISHING_SHOP["rusty_hook"])
            catch_window = CATCH_STYLES.get(self.current_fish["catch_style"], {}).get("window", 3) + hook_data.get("window_bonus", 0)
            
            self.fish_appeared = True
            self.children[1].disabled = False
            
            # Don't reveal fish identity - just show status
            rarity = self.current_fish['rarity']
            
            embed = discord.Embed(
                description=f"Something's biting! Quick, reel it in!\n\n**Catch Window:** {catch_window:.1f}s",
                color=FISH_RARITY_COLORS.get(rarity)
            )
            await self.message.edit(embed=embed, view=self)
            self.catch_task = asyncio.create_task(self._timeout(catch_window))
        except Exception as e:
            logging.error(f"FishingGameView cast_btn error: {e}", exc_info=True)
            try:
                await interaction.response.send_message("❌ An error occurred!", ephemeral=True)
            except:
                pass

    async def _timeout(self, window: float = 3.0):
        await asyncio.sleep(window)
        if self.caught or not self.fish_appeared: return
        self.fish_appeared = False
        damage = self.current_fish.get("rod_damage", 5)
        new_dur, broken = await self.cog.damage_rod(str(self.user.id), self.guild_id, damage)
        
        rod_key = self.inventory.get("rod", "basic_rod")
        rod_data = FISHING_SHOP.get(rod_key, FISHING_SHOP["basic_rod"])
        rod_max = rod_data.get("max_durability", 100)
        rod_pct = (new_dur / rod_max * 100) if rod_max > 0 else 0
        
        embed = discord.Embed(
            description=(
                f"The fish escaped before you could reel it in!\n\n"
                f"**Rod Health:** {rod_pct:.1f}%\n"
                + (f"**ROD BROKEN!** Buy a new one: `.fishshop buy basic_rod`" if broken else "")
            ),
            color=discord.Color.red()
        )
        
        self.clear_items()
        await self.message.edit(embed=embed, view=self)
        self.stop()

    @discord.ui.button(label="Reel!", style=discord.ButtonStyle.success, disabled=True)
    async def reel_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id or not self.fish_appeared: return
        self.caught = True
        if self.catch_task: self.catch_task.cancel()
        self.clear_items()
        
        fish = self.current_fish
        rarity = fish['rarity']
        
        # Calculate reward with rod bonus
        rod_key = self.inventory.get("rod", "basic_rod")
        rod_data = FISHING_SHOP.get(rod_key, FISHING_SHOP["basic_rod"])
        catch_bonus = 1 + (rod_data.get("catch_bonus", 0) / 100)
        
        base_reward = random.randint(fish["min_value"], fish["max_value"])
        bonus_reward = int(base_reward * catch_bonus) - base_reward
        total_reward = base_reward + bonus_reward
        
        await self.cog.quest_data.add_balance(str(self.user.id), self.guild_id, total_reward)
        
        # Get new balance
        new_bal = await self.cog.quest_data.get_balance(str(self.user.id), self.guild_id)
        
        # Format weight nicely
        if self.fish_weight >= 1000:
            weight_str = f"{self.fish_weight/1000:.2f} kg"
        else:
            weight_str = f"{self.fish_weight:.2f} g"
        
        # Update fishing stats
        db = self.cog.quest_data.mongoConnect[self.cog.quest_data.DB_NAME]
        user_id = str(self.user.id)
        await db["Servers"].update_one(
            {"guild_id": self.guild_id},
            {
                "$inc": {f"members.{user_id}.fishing_stats.caught": 1},
                "$addToSet": {f"members.{user_id}.fishing_stats.species_caught": self.fish_id}
            },
            upsert=True
        )
        
        # Increment fish session uses (for cooldown tracking)
        await self.cog.increment_fish_session(user_id, self.guild_id)
        
        # Get updated species count
        result = await db["Servers"].find_one({"guild_id": self.guild_id}, {f"members.{user_id}.fishing_stats": 1})
        species_count = len(result.get("members", {}).get(user_id, {}).get("fishing_stats", {}).get("species_caught", [])) if result else 1
        
        # ANSI color codes based on rarity
        rarity_colors = {
            "common": "\u001b[0;37m",      # White
            "uncommon": "\u001b[0;32m",    # Green
            "rare": "\u001b[0;34m",        # Blue
            "epic": "\u001b[0;35m",        # Magenta
            "legendary": "\u001b[0;33m"    # Yellow/Gold
        }
        ansi_color = rarity_colors.get(rarity, "\u001b[0;37m")
        ansi_reset = "\u001b[0m"
        
        embed = discord.Embed(
            title=f"🎣  {fish['emoji']}  Caught!",
            description=f"**{fish['name']}** ({rarity.title()})\n```ansi\n{ansi_color}{fish.get('description', '')}{ansi_reset}\n```",
            color=FISH_RARITY_COLORS.get(rarity)
        )
        
        embed.add_field(
            name="Catch Info",
            value=f"**Weight:** {weight_str}\n**Value:** +{total_reward} pts" + (f" (+{bonus_reward} bonus)" if bonus_reward > 0 else ""),
            inline=True
        )
        
        embed.add_field(
            name="Your Progress",
            value=f"**Species:** {species_count}/22\n**Balance:** {new_bal:,} pts",
            inline=True
        )
        
        embed.set_footer(text="Keep fishing with .fish!")
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()


class ReactionTimeView(discord.ui.View):
    def __init__(self, cog, user, guild_id, bet):
        super().__init__(timeout=15)
        self.cog, self.user, self.guild_id, self.bet = cog, user, guild_id, bet
        self.message, self.ready, self.clicked_early, self.start_time = None, False, False, None

    @discord.ui.button(label="Wait...", style=discord.ButtonStyle.danger)
    async def click_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            if interaction.user.id != self.user.id:
                return await interaction.response.send_message("Not your game!", ephemeral=True)
            
            if not self.ready:
                self.clicked_early = True
                for c in self.children: c.disabled = True
                embed = discord.Embed(title="⚡ Too Early!", description=f"You clicked too soon!\n💸 Lost **{self.bet}** pts", color=discord.Color.red())
                await interaction.response.edit_message(embed=embed, view=self)
                self.stop()
                return
            
            reaction_time = (asyncio.get_event_loop().time() - self.start_time) * 1000
            for c in self.children: c.disabled = True
            
            if reaction_time < 200:
                multiplier, result = 3.0, "⚡ INSANE!"
            elif reaction_time < 300:
                multiplier, result = 2.0, "🔥 Fast!"
            elif reaction_time < 400:
                multiplier, result = 1.5, "✅ Good"
            elif reaction_time < 600:
                multiplier, result = 1.0, "😐 Average"
            else:
                multiplier, result = 0.5, "🐢 Slow"
            
            winnings = int(self.bet * multiplier)
            await self.cog.quest_data.add_balance(str(self.user.id), self.guild_id, winnings)
            profit = winnings - self.bet
            
            embed = discord.Embed(
                title=f"⚡ {result}",
                description=f"⏱️ **{reaction_time:.0f}ms**\n💰 {'Won' if profit >= 0 else 'Lost'} **{profit:+,}** pts",
                color=discord.Color.green() if profit >= 0 else discord.Color.red()
            )
            await interaction.response.edit_message(embed=embed, view=self)
            self.stop()
        except Exception as e:
            logging.error(f"ReactionTimeView button error: {e}", exc_info=True)
            try:
                await interaction.response.send_message("❌ An error occurred!", ephemeral=True)
            except:
                pass


class BlackjackView(discord.ui.View):
    def __init__(self, cog, ctx, bet, player_hand, dealer_hand, card_value, draw_card):
        super().__init__(timeout=60)
        self.cog = cog
        self.ctx = ctx
        self.bet = bet
        self.player_hand = player_hand
        self.dealer_hand = dealer_hand
        self.card_value = card_value
        self.draw_card = draw_card
        self.message = None
        self.game_over = False
    
    def build_embed(self, reveal_dealer=False):
        player_val = self.card_value(self.player_hand)
        dealer_val = self.card_value(self.dealer_hand) if reveal_dealer else self.card_value([self.dealer_hand[0]])
        
        player_cards = " ".join(self.player_hand)
        if reveal_dealer:
            dealer_cards = " ".join(self.dealer_hand)
        else:
            dealer_cards = f"{self.dealer_hand[0]} 🂠"
        
        embed = discord.Embed(title="🃏 Blackjack", color=primary_color())
        embed.add_field(
            name=f"Your Hand ({player_val})",
            value=player_cards,
            inline=False
        )
        embed.add_field(
            name=f"Dealer ({dealer_val if reveal_dealer else '?'})",
            value=dealer_cards,
            inline=False
        )
        embed.set_footer(text=f"Bet: {self.bet:,} pts")
        return embed
    
    async def end_game(self, interaction, result, multiplier):
        self.game_over = True
        for c in self.children:
            c.disabled = True
        
        user_id = str(self.ctx.author.id)
        guild_id = str(self.ctx.guild.id)
        
        if multiplier > 0:
            winnings = int(self.bet * multiplier)
            await self.cog.quest_data.add_balance(user_id, guild_id, winnings)
            profit = winnings - self.bet
            color = discord.Color.green()
        else:
            profit = -self.bet
            color = discord.Color.red()
        
        new_bal = await self.cog.quest_data.get_balance(user_id, guild_id)
        
        embed = self.build_embed(reveal_dealer=True)
        embed.color = color
        embed.add_field(
            name=result,
            value=f"**{'Won' if profit >= 0 else 'Lost'}:** {abs(profit):,} pts\n**Balance:** {new_bal:,} pts",
            inline=False
        )
        
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()
    
    @discord.ui.button(label="Hit", style=discord.ButtonStyle.primary)
    async def hit_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            if interaction.user.id != self.ctx.author.id:
                return await interaction.response.send_message("Not your game!", ephemeral=True)
            
            self.player_hand.append(self.draw_card())
            player_val = self.card_value(self.player_hand)
            
            if player_val > 21:
                await self.end_game(interaction, "💥 Bust!", 0)
            elif player_val == 21:
                await self.end_game(interaction, "🎉 Blackjack!", 2.5)
            else:
                embed = self.build_embed()
                await interaction.response.edit_message(embed=embed, view=self)
        except Exception as e:
            logging.error(f"BlackjackView hit_btn error: {e}", exc_info=True)
            try:
                await interaction.response.send_message(" An error occurred!", ephemeral=True)
            except:
                pass
    
    @discord.ui.button(label="Stand", style=discord.ButtonStyle.secondary)
    async def stand_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            if interaction.user.id != self.ctx.author.id:
                return await interaction.response.send_message("Not your game!", ephemeral=True)
            
            # Dealer draws until 17+
            while self.card_value(self.dealer_hand) < 17:
                self.dealer_hand.append(self.draw_card())
            
            player_val = self.card_value(self.player_hand)
            dealer_val = self.card_value(self.dealer_hand)
            
            if dealer_val > 21:
                await self.end_game(interaction, " Dealer Bust!", 2)
            elif player_val > dealer_val:
                await self.end_game(interaction, " You Win!", 2)
            elif player_val < dealer_val:
                await self.end_game(interaction, " Dealer Wins", 0)
            else:
                # Push - return bet
                await self.cog.quest_data.add_balance(str(self.ctx.author.id), str(self.ctx.guild.id), self.bet)
                await self.end_game(interaction, " Push (Tie)", 1)
        except Exception as e:
            logging.error(f"BlackjackView stand_btn error: {e}", exc_info=True)
            try:
                await interaction.response.send_message(" An error occurred!", ephemeral=True)
            except:
                pass


async def setup(bot):
    await bot.add_cog(Games(bot))